import tempfile
import importlib.util
import unittest
from datetime import date,timedelta
from pathlib import Path
from unittest.mock import patch
import numpy as np
from ml.forecast.core import grid
from ml.forecast.models import Boosting
from ml.forecast.route_specific import SeasonalProfile,choose_routes,combine,verify_inputs,candidate_factories


class RouteTests(unittest.TestCase):
    def test_unverified_inputs_rejected_before_training(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'fake.csv';p.write_text('synthetic')
            with self.assertRaisesRegex(ValueError,'does not match real DS-2'):
                verify_inputs({'train':p})
            self.assertIn('train',verify_inputs({'train':p},synthetic=True))

    def test_autumn_does_not_inherit_summer_weekday_slump(self):
        start,cutoff=date(2025,1,1),date(2025,8,31)
        hist={k: (20 if k[1].month in (7,8) and k[1].weekday()<5 else 100)
              for k in grid(['1'],start,cutoff)}
        model=SeasonalProfile(calendar=False).fit(hist,start,cutoff)
        k=('1',date(2025,9,1),12)
        self.assertEqual(model.predict([k])[k],100)
        self.assertEqual(model.predict([('5',date(2025,9,1),12)])[('5',date(2025,9,1),12)],0)
        hist['1',date(2025,9,1),12]=999
        with self.assertRaises(ValueError):model.fit(hist,start,cutoff)

    def test_route_choices_differ_and_single_month_overfit_rejected(self):
        keys=[(r,date(2025,m,1),12) for r in ('1','7') for m in (9,10)]
        truth={k:100 for k in keys}
        preds={'school_calendar':dict.fromkeys(keys,80),
               'a':{k:100 if k[0]=='1' else 70 for k in keys},
               'b':{k:100 if k[0]=='7' else 70 for k in keys},
               'overfit':{k:100 if k[1].month==9 else 10 for k in keys}}
        choices,_=choose_routes(keys,truth,preds,['1','7'])
        self.assertEqual(choices['1']['candidate'],'a')
        self.assertEqual(choices['7']['candidate'],'b')
        self.assertEqual(combine(keys,preds,choices),truth)

    def test_boosting_target_aggregates_are_strictly_past(self):
        start,cutoff=date(2025,1,1),date(2025,3,31)
        hist={k:(k[1]-start).days*100+k[2] for k in grid(['1'],start,cutoff)}
        observed=[]
        class Spy(Boosting):
            def _extract_profiles(self,history,start,cutoff):
                self.profile_end=cutoff
                return super()._extract_profiles(history,start,cutoff)
            def features(self,keys,context=None):
                observed.append((self.profile_end,min(k[1] for k in keys)))
                assert self.profile_end<min(k[1] for k in keys)
                return super().features(keys,context)
        Spy(kind='hgb').fit(hist,start,cutoff)
        self.assertGreaterEqual(len(observed),3)

    @unittest.skipUnless(importlib.util.find_spec('lightgbm'), 'optional LightGBM')
    def test_training_error_cannot_silently_change_library(self):
        hist={k:100 for k in grid(['1'],date(2025,1,1),date(2025,2,28))}
        with patch('lightgbm.LGBMRegressor.fit',side_effect=ValueError('broken fit')):
            with self.assertRaisesRegex(RuntimeError,'no silent fallback'):
                Boosting(kind='lgb').fit(hist,date(2025,1,1),date(2025,2,28))

    def test_candidates_have_no_future_route50_rule(self):
        for name,factory in candidate_factories().items():
            model=factory()
            self.assertFalse(getattr(model,'route50_rule',False),name)

if __name__=='__main__':unittest.main()

"""Human-readable PDF using the same calculations as the interactive planner."""
import io
import math
import hashlib
import json
from collections import defaultdict
from datetime import datetime,timezone,timedelta
from pathlib import Path
from xml.sax.saxutils import escape
from reportlab.pdfgen.canvas import Canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak,Flowable,KeepTogether
from .scenario_engine import horizon
from .quality_experiment import experiment
from .model_runtime import model_card

FONT_DIR=Path(__file__).parent/'fonts'
pdfmetrics.registerFont(TTFont('Tram',str(FONT_DIR/'DejaVuSans.ttf')))
pdfmetrics.registerFont(TTFont('TramBold',str(FONT_DIR/'DejaVuSans-Bold.ttf')))
pdfmetrics.registerFontFamily('Tram',normal='Tram',bold='TramBold',italic='Tram',boldItalic='TramBold')
INK=colors.HexColor('#201936');BLUE=colors.HexColor('#416fea');MUTED=colors.HexColor('#635f75');PALE=colors.HexColor('#f1f3fb');RED=colors.HexColor('#cb4668')
STYLES={
 'body':ParagraphStyle('body',fontName='Tram',fontSize=9,leading=14,textColor=INK,spaceAfter=8),
 'small':ParagraphStyle('small',fontName='Tram',fontSize=7.2,leading=10.3,textColor=MUTED,spaceAfter=5,splitLongWords=True),
 'h1':ParagraphStyle('h1',fontName='TramBold',fontSize=27,leading=33,textColor=INK,spaceAfter=14),
 'h2':ParagraphStyle('h2',fontName='TramBold',fontSize=16,leading=21,textColor=INK,spaceBefore=16,spaceAfter=10,keepWithNext=True),
 'h3':ParagraphStyle('h3',fontName='TramBold',fontSize=11,leading=16,textColor=BLUE,spaceBefore=8,spaceAfter=7,keepWithNext=True),
 'cell':ParagraphStyle('cell',fontName='Tram',fontSize=7.5,leading=11,textColor=INK),
 'head':ParagraphStyle('head',fontName='TramBold',fontSize=7.5,leading=11,textColor=colors.white),
}
def fmt(v):return f'{round(v):,}'.replace(',',' ')
def P(text,style='body'):return Paragraph(escape(str(text)).replace('\n','<br/>'),STYLES[style])
def table(headers,rows,widths):
 data=[[P(x,'head') for x in headers]]+[[P(x,'cell') for x in row] for row in rows]
 t=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT');t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),INK),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,PALE]),('LINEBELOW',(0,0),(-1,0),1,BLUE),('LINEBELOW',(0,1),(-1,-1),.3,colors.HexColor('#e1e4ef'))]));return t

class Trend(Flowable):
 def __init__(self,rows):Flowable.__init__(self);self.rows=rows;self.width=499;self.height=180
 def draw(self):
  c=self.canv;c.setFillColor(PALE);c.roundRect(0,0,499,180,7,fill=1,stroke=0)
  n=len(self.rows);maximum=max([1]+[r[k] for r in self.rows for k in ['demand','served']]);left=52;right=480;bottom=34;top=153
  c.setFont('Tram',7)
  for i in range(4):
   y=bottom+(top-bottom)*i/3;c.setStrokeColor(colors.HexColor('#dfe3ee'));c.line(left,y,right,y);c.setFillColor(MUTED);c.drawRightString(left-8,y-2,fmt(maximum*i/3))
  for key,color in [('demand',MUTED),('served',BLUE)]:
   c.setStrokeColor(color);c.setLineWidth(1.7);path=c.beginPath()
   for i,r in enumerate(self.rows):
    x=left+(right-left)*i/max(1,n-1);y=bottom+(top-bottom)*r[key]/maximum
    if i==0:path.moveTo(x,y)
    else:path.lineTo(x,y)
   c.drawPath(path)
  c.setFillColor(MUTED)
  for i in sorted(set([0,n//4,n//2,3*n//4,n-1])):
   if i>=0:c.drawCentredString(left+(right-left)*i/max(1,n-1),18,str(self.rows[i]['label']))
  c.setFillColor(BLUE);c.drawString(52,164,'Синий: обслуженный сценарный спрос');c.setFillColor(MUTED);c.drawString(287,164,'Серый: спрос до ограничений')

class Map(Flowable):
 def __init__(self,events,projects,geometry):Flowable.__init__(self);self.events=events;self.projects=projects;self.geometry=geometry;self.width=499;self.height=215
 def draw(self):
  c=self.canv;c.setFillColor(PALE);c.roundRect(0,0,499,215,7,fill=1,stroke=0)
  points=[s for g in self.geometry.values() for s in g.get('stops',[])];xs=[s['lon']*math.cos(.973) for s in points];ys=[s['lat'] for s in points]
  if not points:return
  xmin,xmax,ymin,ymax=min(xs),max(xs),min(ys),max(ys);scale=min(459/(xmax-xmin),175/(ymax-ymin))
  def xy(s):return (20+(s['lon']*math.cos(.973)-xmin)*scale,20+(s['lat']-ymin)*scale)
  for r,g in self.geometry.items():
   ss=g.get('stops',[]);c.setStrokeColor(colors.HexColor('#a9b4d0'));c.setLineWidth(.8);path=c.beginPath()
   for i,s in enumerate(ss):
    x,y=xy(s)
    if i==0:path.moveTo(x,y)
    else:path.lineTo(x,y)
   c.drawPath(path)
  for label,items,color in [('E',self.events,RED),('P',self.projects,BLUE)]:
   for i,item in enumerate(items):
    x,y=xy(item['stop']);c.setFillColor(color);c.circle(x,y,5,fill=1,stroke=0);c.setFont('TramBold',8);c.drawString(x+7,y+5,label+str(i+1))
  c.setFont('Tram',7);c.setFillColor(MUTED);c.drawString(15,201,'Геосхема · E — событие, P — остановка влияния застройки; не фактическая трасса рельсов')

def make_report(values,geometry,poi):
    request={**values,'events':values.get('events',[]),'developments':values.get('developments',[])}
    d=horizon(request,geometry,poi);card=model_card();p=d['parameters'];rows=d['records'];network=d['network'];story=[]
    title={'day':'План на день','week':'План на неделю','month':'План на месяц','year':'Годовой сценарий'}[d['period']]
    route='Вся сеть' if d['route_filter']=='all' else 'Маршрут №'+d['route_filter']
    scope=f"{route} · {d['from']} — {d['to']} · {d['hour_from']:02}:00–{d['hour_to']:02}:00 МСК"
    generated=datetime.now(timezone(timedelta(hours=3))).strftime('%d.%m.%Y %H:%M МСК');rid=hashlib.sha256(json.dumps(request,sort_keys=True,ensure_ascii=False).encode()).hexdigest()[:12]
    def h(text):story.append(P(text,'h2'))
    def body(text):story.append(KeepTogether([P(text)]))
    story += [P('ТРАМВАЙНЫЙ ПУЛЬС / ОТЧЁТ ДИСПЕТЧЕРА','h3'),P(title,'h1'),P(scope),P(f'Сформирован {generated} · сценарий {rid}','small'),Spacer(1,12)]
    base=sum(x['prediction'] for x in rows);demand=sum(x['adjusted'] for x in rows);served=sum(x['scenario'] for x in rows);growth=sum(x['development'] for x in rows);unmet=sum(x['unmet'] for x in network);moved=sum(x['redirected'] for x in network)
    story.append(table(['Выбранный объект: базовая модель','Выбранный объект: сценарный спрос','Сеть: без найденного обслуживания'],[[fmt(base),fmt(demand),fmt(unmet)]],[166,166,167]))
    body('Все количества ниже — валидации, то есть ожидаемые регистрации посадки. Это не число уникальных людей и не измеренная заполненность салона. Пересадки описаны как возможные дополнительные валидации: одного пассажира нельзя восстановить по этим агрегатам.')
    h('Что это значит для диспетчера')
    body(f'В выбранном объекте ожидается {fmt(demand)} валидаций до ограничений и {fmt(served)} после перераспределения. Допущения о новых зданиях добавляют {fmt(growth)} валидаций. По всей сети альтернативные маршруты условно принимают {fmt(moved)}, без найденного обслуживания остаётся {fmt(unmet)}. Общесетевой баланс отличается от показателей выбранного маршрута: часть потока уходит на соседние линии.')
    high=[a for a in d['advisories'] if a['ratio']>1]
    body(f'Повышенный индикатор спроса относительно расчётного выпуска обнаружен на {len(high)} выбранных маршрутах. Рекомендуемые действия приведены ниже; автоматических распоряжений о выпуске сервис не отправляет.')
    if d['granularity']!='route':body('Остановка/участок: график и итог — иллюстративная равномерная доля маршрута. Детальный сценарий аварий использует веса окружения. Эти две оценки нельзя выдавать за обученную остановочную модель; пересадки и баланс в отчёте показаны по сети.')
    by_time={}
    for r in rows:
        key=r['hour'] if d['period']=='day' else r['date'];q=by_time.setdefault(key,{'label':f'{key:02}:00' if isinstance(key,int) else key[5:],'demand':0,'served':0})
        q['demand']+=r['adjusted'];q['served']+=r['scenario']
    story.append(Trend(list(by_time.values())))
    story.append(P('Показатели выбранного объекта. Сценарий может превышать исходный спрос конкретного маршрута, когда он принимает пересадки с других линий.','small'))
    story.append(PageBreak());h('Почему получился такой прогноз')
    body('1. WeatherEnsemble получает маршрут, дату и час. Его обученные профили учитывают час, день недели, сезон и календарь 2025. Reference объединяет выбранные маршрутные профили; LightGBM корректирует остаточную ошибку на отдельных маршрутах. Это описание алгоритма, а не причинное доказательство того, почему конкретные пассажиры поедут.')
    body('2. В полном ансамбле погодная коррекция выбрана для №7 с весом 0.5 и №50 с весом 1.0; №25 использует календарную коррекцию. Для остальных сохраняется reference. До конца 2025 внутри артефакта есть реанализ ERA5; после него используется reference без будущей погоды и без обновлённых праздников. Годовой прогноз после 2025 не имеет подтверждённой точности.')
    body(f"3. Поправки диспетчера: погода ×{p['weather_factor']:.2f}, событие ×{p['event_factor']:.2f}, сезон ×{p['season_factor']:.2f}. Их произведение применяется к модели до добавления новых объектов. Режим погоды: {'пользовательский дождь '+str(p['rain_mm'])+' мм/ч для дат с погодными признаками' if p['weather']=='rain' else 'архивные признаки ERA5, где они доступны'}. За пределами архива дождь не подменяется выдуманной погодой; остаются явные коэффициенты.")
    body('4. Новый объект добавляет чистый сценарный прирост по формуле из раздела застройки. Затем ограничения убирают часть оценочного спроса у остановок. Доступные соседние маршруты принимают готовую пересесть долю; сначала используется условный свободный выпуск, затем общий резерв. Пересечение двух ограничений в одной точке учитывается по максимальной потере, не суммируется.')
    story.append(table(['Ступень расчёта выбранного объекта','Валидации'],[['Reference',fmt(sum(x['reference'] for x in rows))],['WeatherEnsemble',fmt(base)],['Погода / ручные поправки: изменение',fmt(demand-growth-base)],['Новая застройка: добавлено',fmt(growth)],['Перед ограничениями',fmt(demand)],['Удалено ограничениями',fmt(sum(x['displaced'] for x in rows))],['Принято с других маршрутов',fmt(sum(x['transferred'] for x in rows))],['После перераспределения',fmt(served)]],[370,129]))
    h('Параметры, от которых зависит решение')
    story.append(table(['Параметр','Значение','Смысл'],[['Интервал',f"{p['headway']} мин",'Расчётный, не загруженное расписание'],['Оборот',f"{p['cycle_minutes']} мин",'Время оборота вагона'],['Вместимость',fmt(p['capacity']),'Мест/вагон; целевая доля 80%'],['Резерв',fmt(p['reserve']),'Общий для всех событий в каждом часу'],['Готовность к пересадке',f"{p['transfer_percent']}%",'Доля затронутого спроса; пользовательское допущение'],['Радиус альтернатив','800 м','Расстояние по прямой, не проверенный пеший путь']],[120,95,284]))
    h('Где ограничения и куда может уйти поток')
    if d['events'] or d['developments']:story.append(Map(d['events'],d['developments'],geometry));story.append(Spacer(1,10))
    if not d['events']:body('Аварии и дорожные работы не заданы. Потери обслуживания и вынужденные пересадки от событий равны нулю.')
    for i,e in enumerate(d['events']):
        story.append(P(f"E{i+1}. {e['name']} / {e['stop']['name']}",'h3'))
        body(f"Период {e['start_date']} — {e['end_date']}; ежедневно {e['start_hour']:02}:00–{e['end_hour']:02}:00. Ограничение {e['capacity_loss']}%. Координаты остановки {e['stop']['lat']:.5f}, {e['stop']['lon']:.5f}. Затронуто {fmt(e['displaced'])}; найденные пересадки {fmt(e['redirected'])}; остаток {fmt(e['unmet'])} валидаций в выбранные часы отчёта.")
    if d['flows']:
        story.append(table(['Откуда / событие','Куда','Пешком*','Оценка'],[[f"E{f['event_id']} · №{f['from_route']}\n{f['from_stop']}",f"№{f['to_route']}\n{f['to_stop']}",f"{f['distance_m']} м",fmt(f['count'])] for f in d['flows']],[170,170,64,95]))
        body('* По прямой. Проверьте переходы, доступность для маломобильных пассажиров, путь до платформы и действующее движение. Оценка суммируется за период. Альтернативы на маршрутах с действующим ограничением исключаются консервативно целиком.')
    elif d['events']:body('Подходящих пересадок не найдено либо в выбранном периоде события не активны. Не направляйте пассажиров по несуществующей рекомендации; рассмотрите информирование, обход или согласованный автобусный подвоз.')
    h('Проверка общесетевого баланса')
    body(f"Спрос до ограничений {fmt(sum(x['weather'] for x in network))} = обслуженный сценарный спрос {fmt(sum(x['scenario'] for x in network))} + остаток без обслуживания {fmt(unmet)}. Пиковое использование общего резерва: {max(x['max_reserve'] for x in network)} из {p['reserve']} вагонов. Это максимум, а не сумма вагонов по дням.")
    story.append(PageBreak());h('Рекомендации и порядок действий')
    actions=['Подтвердить факт события, границы участка и доступность остановок; сверить расписание, журнал оборудования и ограничения депо.', 'Для найденных пересадок проверить пеший путь и реальную вместимость принимающего выпуска; разместить информацию на затронутых остановках.', 'В первую очередь использовать существующий доступный выпуск. Дополнительные вагоны выделять из общего резерва после проверки фактического спроса.', 'Остаток без найденного обслуживания передать диспетчеру для решения о подвозе, изменении схемы обслуживания и информировании. Не трактовать этот остаток как измеренное число людей на остановке.', 'Через следующий час сравнить фактические валидации с прогнозом; при неполных данных не сокращать выпуск только из-за нулей в выгрузке.']
    for i,a in enumerate(actions,1):body(f'{i}. {a}')
    if d['advisories']:story.append(table(['Маршрут / пик','Индикатор','Проверить','Решение'],[[f"№{a['route']}\n{a['date']} {a['hour']:02}:00\n{fmt(a['peak'])} вал./ч",f"{a['ratio']:.2f}×",f"До +{a['indicative_extra']} ваг.*",a['action']] for a in d['advisories']],[135,65,89,210]))
    body('* Расчётный ориентир: ceil(валидации/ч × оборот / (60 × вместимость × 0.8)) минус исходный выпуск ceil(оборот / интервал). Сравниваются валидации и пропускная способность, а не заполненность салона. Потребности разных маршрутов не складываются в автоматически выделенный резерв. Для принятия решения нужны посадки/выходы, направления и реальные обороты.')
    h('Новая застройка: от источника к сценарию')
    if not d['developments']:body('Объекты не включены в расчёт. Справочный реестр в сервисе не добавляет пассажиров автоматически: срок ввода, население/рабочие места и привязку к остановке необходимо задать и проверить.')
    for i,item in enumerate(d['developments']):
        story.append(P(f"P{i+1}. {item['name']}",'h3'))
        body(f"{'ЖК' if item['kind']=='residential' else 'Офисы'}; маршрут №{item['route']}, остановка {item['stop']['name']}. Сценарная дата ввода {item['opening_date']}. Прирост за выбранные часы периода: {fmt(item['total_added'])} валидаций.")
        body(f"Формула в день полного освоения: {fmt(item['people'])} жителей/работников × {item['occupancy']}% заселения × {item['tram_share']}% доли трамвая × {item['trips']} посадок у объекта/чел./день × {item['net_new_share']}% чистого прироста. Выходные: ×{'0.85' if item['kind']=='residential' else '0.20'}; освоение линейно за {item['ramp_months']} условных месяцев по 30 дней. До ввода прирост нулевой. Почасовой профиль ЖК усиливает утренние посадки; офисов — вечерние. Это экспертный профиль, не обученный на объекте.")
        body('Чистый прирост исключает долю переселившихся/переключившихся с уже учтённых поездок; неверное значение может привести к двойному счёту. Привязка показывает остановку влияния, а не точный контур стройплощадки.')
        story.append(P('Источник: '+item['source'],'small'));story.append(P(item['assumption_notice'],'small'))
    h('Качество данных: зачем эксперимент')
    qvalues={**values,'route':d['route_filter'],'quality_route':values.get('quality_route',7),'events':[]}
    if str(qvalues['quality_route']) in ('5','all'):qvalues['quality_route']=7
    q=experiment(qvalues)
    body(q['notice']);body(q['effect'])
    story.append(table(['Вариант эксперимента','Валидаций за день','Пик в час','Ориентир вагонов'],[['Исходный '+('факт' if q['mode']=='withheld_actual' else 'прогноз'),fmt(q['truth']['total']),fmt(q['truth']['peak']),fmt(q['truth']['indicative_vehicles'])],['Пропуск ошибочно заменён нулём',fmt(q['zero']['total']),fmt(q['zero']['peak']),fmt(q['zero']['indicative_vehicles'])],['В пропуске использована модель',fmt(q['restored']['total']),fmt(q['restored']['peak']),fmt(q['restored']['indicative_vehicles'])]],[218,96,85,100]))
    body(f"Эксперимент: №{q['route']}, {q['date']}, скрытые часы {q['gap'][0]}–{q['gap'][1]}. Он не меняет веса модели, рабочий прогноз и выделенный резерв. Показывает риск решения по неполной выгрузке. Для измерения точности восстановления загрузите 24 полных фактических часа: они скрываются только при оценке, не идут в обучение.")
    story.append(P(card['metrics_notice'],'small'))
    h('Как читать показатели')
    story.append(table(['Показатель','Объяснение'],[['База / reference','Прогноз обученных маршрутных профилей без выбранной LightGBM-коррекции.'],['Ансамбль','Прогноз нового файла model.local.pkl, до ручных поправок и событий.'],['Сценарный спрос','Ансамбль с погодным what-if, коэффициентами и чистым приростом застройки.'],['Затронуто','Часть оценочного спроса у остановок, снятая ограничениями; совпавшие события не удваивают её.'],['Перенаправлено','Условно принятый другими маршрутами спрос при доле готовых пересесть и доступном выпуске.'],['Не обслужено','Затронутый спрос минус найденные пересадки; это не измеренная очередь.'],['Коэффициент нагрузки','Валидации/ч / (60 / интервал × вместимость × 0.8). Только ориентир для проверки выпуска.'],['WAPE-score','max(0, 1 − сумма абсолютных ошибок / сумма факта). Не определяется без факта или при нулевой сумме факта.']],[130,369]))
    story.append(Spacer(1,12));body('Версия модели: '+d['model_version']);story.append(P('SHA-256: '+card['sha256'],'small'));body('Параметры сценария зафиксированы в этом отчёте; исходники и модель должны храниться вместе с выгрузкой. Период обучения заканчивается 31.10.2025. Геометрия — более поздний справочник. Объекты строительства могут быть опубликованы позднее даты прогноза, поэтому сценарий не является прогнозом as-of 2025.')
    story.append(P('Погода: '+card['weather_source']['url'],'small'));story.append(P('Интервал отчёта: '+scope+' · ID '+rid,'small'))
    story.append(PageBreak());h('Приложение: динамика и воспроизводимость')
    body('Таблица ниже относится ко всей сети и выбранным часам. Подробный CSV выбранного объекта доступен рядом с кнопкой PDF в интерфейсе.')
    if d['period']=='day':
        from .scenario_engine import simulate_multi
        sim=simulate_multi(request,geometry,poi)
        detail=[[f"{x['hour']:02}:00",fmt(x['weather']),fmt(x['scenario']),fmt(x['redirected']),fmt(x['unmet'])] for x in sim['hourly'] if d['hour_from']<=x['hour']<d['hour_to']]
    else:detail=[[x['date'],fmt(x['weather']),fmt(x['scenario']),fmt(x['redirected']),fmt(x['unmet'])] for x in network]
    story.append(table(['Интервал','До ограничений','Обслужено','Пересадки','Остаток'],detail,[100,107,107,92,93]))
    buffer=io.BytesIO();doc=SimpleDocTemplate(buffer,pagesize=(595.28,841.89),leftMargin=48,rightMargin=48,topMargin=48,bottomMargin=50,title='Трамвайный пульс — '+title,author='Трамвайный пульс')
    def page(c,doc):
        c.saveState();c.setFillColor(BLUE);c.rect(0,827,595.28,15,fill=1,stroke=0);c.setFont('Tram',7);c.setFillColor(MUTED);c.drawString(48,26,'Трамвайный пульс · интерпретируемый сценарий · '+rid);c.drawRightString(547,26,str(doc.page));c.restoreState()
    doc.build(story,onFirstPage=page,onLaterPages=page);return buffer.getvalue()

"""Benchmark deployed app, no credentials in output. Env BENCH_URL/USER/PASSWORD."""
import os,json,time,urllib.request,concurrent.futures,math,argparse,datetime
p=argparse.ArgumentParser();p.add_argument('--out',default='benchmark_target.json');p.add_argument('--seconds',type=int,default=60);a=p.parse_args()
base=os.environ.get('BENCH_URL','http://127.0.0.1:8080').rstrip('/');password=os.environ['BENCH_PASSWORD'];user=os.environ.get('BENCH_USER','jury')
r=urllib.request.Request(base+'/api/login',data=json.dumps({'username':user,'password':password}).encode(),headers={'Content-Type':'application/json'})
with urllib.request.urlopen(r,timeout=60) as response:cookie=response.headers['Set-Cookie'].split(';')[0]
paths=['/api/model','/api/forecast?route=7&date=2025-11-18&period=day','/api/analysis?route=7&date=2025-11-18&period=day','/api/simulation']
def call(i):
 path=paths[i%4];data=json.dumps({'date':'2025-11-18','route':'7'}).encode() if i%4==3 else None;t=time.perf_counter()
 try:
  with urllib.request.urlopen(urllib.request.Request(base+path,data=data,headers={'Cookie':cookie,'Content-Type':'application/json'}),timeout=60) as r:r.read();status=r.status
 except Exception as e:status=getattr(e,'code',0)
 return [(time.perf_counter()-t)*1000,status]
for i in range(20):call(i)
report={'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_url':base,'method':'closed-loop; warm authenticated mixed API, equal endpoint weights; TLS included only for https URL','phases':[]}
for concurrency in [1,8,24]:
 start=time.perf_counter()
 def worker(index):
  rows=[];i=index
  while time.perf_counter()-start<a.seconds:rows.append(call(i));i+=1
  return rows
 with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as pool:rows=[r for batch in pool.map(worker,range(concurrency)) for r in batch]
 elapsed=time.perf_counter()-start;lat=sorted(r[0] for r in rows);errors=sum(r[1]!=200 for r in rows)
 phase={'concurrency':concurrency,'requests':len(rows),'elapsed_seconds':elapsed,'rps':len(rows)/elapsed,'errors':errors,'p95_ms':lat[math.ceil(.95*len(lat))-1],'p99_ms':lat[math.ceil(.99*len(lat))-1],'requests_raw':rows};report['phases'].append(phase)
 print(json.dumps({k:v for k,v in phase.items() if k!='requests_raw'}),flush=True)
 with open(a.out,'w') as f:json.dump(report,f,indent=2)

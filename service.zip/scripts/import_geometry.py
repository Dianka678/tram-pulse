"""Import verified route LineStrings from GeoJSON, without inventing stops."""
import json
import sys
from pathlib import Path

MISSING = {17, 25, 26, 28, 50}


def convert(source, target):
    doc = json.loads(Path(source).read_text(encoding='utf-8'))
    if doc.get('type') != 'FeatureCollection':
        raise ValueError('Expected GeoJSON FeatureCollection')
    routes = {}
    for feature in doc.get('features', []):
        route = int(feature.get('properties', {}).get('route_id', -1))
        if route not in MISSING or str(route) in routes:
            raise ValueError('Expected one feature for each missing route')
        shape = feature.get('geometry', {})
        if shape.get('type') != 'LineString':
            raise ValueError('Expected one LineString per route')
        coordinates = shape.get('coordinates', [])
        if len(coordinates) < 2:
            raise ValueError('Route needs at least two coordinates')
        points = []
        for item in coordinates:
            if len(item) < 2:
                raise ValueError('Invalid coordinate')
            lon, lat = float(item[0]), float(item[1])
            if not 36 < lon < 39 or not 55 < lat < 56.5:
                raise ValueError('Geometry outside Moscow')
            points.append({'lat': lat, 'lon': lon})
        routes[str(route)] = {'points': points,
                              'source': feature['properties'].get('source', 'unspecified')}
    if set(map(int, routes)) != MISSING:
        raise ValueError(f'Expected routes {sorted(MISSING)}, got {sorted(map(int, routes))}')
    Path(target).write_text(json.dumps(routes, ensure_ascii=False), encoding='utf-8')
    print(f'Imported {len(routes)} lines; no stop-level predictions created')


if __name__ == '__main__':
    convert(sys.argv[1], sys.argv[2])

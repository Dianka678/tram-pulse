"""DS-2-informed route-specific selection for a fixed 61-day forecast.

No validation labels enter fitted candidates. Selection scores are exploratory:
Sep-Oct has already been examined repeatedly by DS-2.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.metadata
import importlib.util
import json
import pickle
import time
from collections import defaultdict
from datetime import date, timedelta
from pathlib import Path
import numpy as np
from .core import days, grid, load_labels, rounded, score, sha256, effective_weekday
from .models import Profile, Boosting
from .run import FIRST, FINAL_CUTOFF, FOLDS, dump
from ml.submit.adapter import read_sample, write_submission, export_api, validate

RESEARCH_COMMIT = 'b593ebb'
EXPECTED_HASHES = {
    'train': '20a61009b4ee00327784c6fa888109609fd3a1905ea3a8509b36964dd9baced7',
    'test': '37479acea3e319ac613d72df7217bbe57b66af49644e538139174fd534ce2347',
    'sample': '71c8126bb51068c936462a170da885bad860fc91a58b3d2ac731876d324d7ec3',
}


def verify_inputs(paths, synthetic=False):
    result = {role: {'name': p.name, 'sha256': sha256(p)} for role, p in paths.items()}
    if not synthetic:
        for role, item in result.items():
            if item['sha256'] != EXPECTED_HASHES[role]:
                raise ValueError(f'{role}: SHA256 does not match real DS-2 inputs. '
                                 'Do not train a submission on synthetic or unverified files. '
                                 f"Received {item['sha256']}; expected {EXPECTED_HASHES[role]}")
    return result


class SeasonalProfile:
    """Calendar regimes, robust hourly shapes, optional local history blend.

Summer weekdays are a separate regime, not deleted unconditionally: if a
forecast requests summer, use summer history when at least 3 dates exist.
For autumn this reproduces the DS-2 school-term exclusion candidate.
"""
    def __init__(self, statistic='median', shrink=.2, window=None,
                 seasonal=True, calendar=True, recent_weight=0., regime7=False):
        self.statistic, self.shrink, self.window = statistic, shrink, window
        self.seasonal, self.calendar = seasonal, calendar
        self.recent_weight, self.regime7 = recent_weight, regime7

    @staticmethod
    def summer(d):
        return d.month in (7, 8) and d.weekday() < 5

    def fit(self, history, start, cutoff):
        if not history or any(not start <= k[1] <= cutoff for k in history):
            raise ValueError('History empty or crosses cutoff')
        self.cutoff = cutoff
        self.routes = sorted({k[0] for k in history}, key=int)
        self.tables = {}
        # All keys are explicit, including absent training labels = zero assumption.
        for r in self.routes:
            for season in (None, False, True):
                ds = [d for d in days(start, cutoff)
                      if (not self.window or (cutoff-d).days < self.window)
                      and (season is None or self.summer(d) == season)]
                local, parent = defaultdict(list), defaultdict(list)
                recent = defaultdict(list)
                regime = defaultdict(list)
                for d in ds:
                    w = effective_weekday(d) if self.calendar else d.weekday()
                    for h in range(24):
                        y = history.get((r, d, h), 0)
                        local[w,h].append(y); parent[h].append(y)
                        if (cutoff-d).days < 56:
                            recent[w,h].append(y)
                        if r == '7' and cutoff >= date(2025,8,16) and d >= date(2025,8,16):
                            regime[w,h].append(y)
                fn = np.mean if self.statistic == 'mean' else np.median
                self.tables[r,season] = tuple({k: float(fn(v)) for k,v in t.items() if len(v) >= 3}
                                             for t in (local,parent,recent,regime))
        return self

    def predict(self, keys):
        if any(d <= self.cutoff for _,d,_ in keys):
            raise ValueError('Prediction dates must follow cutoff')
        out = {}
        for key in keys:
            r,d,h = key
            if r not in self.routes:
                out[key] = 0; continue
            season = self.summer(d) if self.seasonal else None
            loc,par,rec,reg = self.tables[r,season]
            fallback,fp,_,_ = self.tables[r,None]
            w = effective_weekday(d) if self.calendar else d.weekday()
            parent = par.get(h,fp.get(h,0))
            local = loc.get((w,h),fallback.get((w,h),parent))
            p = (1-self.shrink)*local + self.shrink*parent
            if (w,h) in rec:
                p = (1-self.recent_weight)*p + self.recent_weight*rec[w,h]
            if self.regime7 and r == '7' and d.weekday() >= 5 and (w,h) in reg:
                # DS-2 experiment 13: 25% sparse post-Aug16 profile, no future notice.
                p = .75*p + .25*reg[w,h]
            out[key] = rounded(p)
        return out


def candidate_factories(profiles_only=False):
    pool = {
        'median_zero': lambda: Profile('median'),
        'mean_zero': lambda: Profile('mean'),
        'school_ds2': lambda: SeasonalProfile(calendar=False),
        'school_calendar': lambda: SeasonalProfile(),
        'school_local': lambda: SeasonalProfile(shrink=0),
        'school_mean': lambda: SeasonalProfile(statistic='mean'),
        'school_recent25': lambda: SeasonalProfile(recent_weight=.25),
        'school_recent50': lambda: SeasonalProfile(recent_weight=.5),
        'school_route7': lambda: SeasonalProfile(regime7=True),
        'median_56d': lambda: SeasonalProfile(window=56, seasonal=False),
        'median_112d': lambda: SeasonalProfile(window=112, seasonal=False),
        'mean_56d': lambda: SeasonalProfile(statistic='mean',window=56,seasonal=False),
        'mean_112d': lambda: SeasonalProfile(statistic='mean',window=112,seasonal=False),
    }
    if not profiles_only:
        pool.update({
            'hgb_causal': lambda: Boosting(kind='hgb',route50_rule=False),
            'lgb_causal': lambda: Boosting(kind='lgb',route50_rule=False),
            'catboost_causal': lambda: Boosting(kind='catboost',route50_rule=False),
        })
    return pool


def choose_routes(keys, truth, predictions, routes, min_gain=.01):
    """Conservative route choice: beat school baseline in both calendar months.

A predeclared 50/50 blend is also considered. No continuous weight fitting.
Fall back to school baseline unless each month improves by >= 1% in MAE.
"""
    months = sorted({d.month for _,d,_ in keys})
    choices, diagnostics = {}, {}
    for r in routes:
        rk = [k for k in keys if k[0] == r]
        by_month = [[k for k in rk if k[1].month == m] for m in months]
        def losses(name, weight):
            return [sum(abs(rounded(weight*predictions[name][k] +
                                (1-weight)*predictions['school_calendar'][k])-truth.get(k,0))
                        for k in batch) for batch in by_month]
        base = losses('school_calendar',1.)
        options = [('school_calendar',1.,base)]
        diagnostics[r] = {'baseline_month_errors':base,'candidates':{}}
        for name in predictions:
            for weight in (0.5,1.):
                errs = losses(name,weight)
                diagnostics[r]['candidates'][f'{name}:{weight}'] = errs
                if all(e <= b*(1-min_gain) for e,b in zip(errs,base)) and sum(errs)<sum(base):
                    options.append((name,weight,errs))
        name,weight,errs = min(options,key=lambda item:(sum(item[2]),item[0],item[1]))
        choices[r] = {'candidate':name,'weight':weight,'month_errors':errs}
    return choices,diagnostics


def combine(keys, predictions, choices):
    result = {}
    for key in keys:
        choice = choices.get(key[0])
        if choice is None:
            result[key] = 0
        else:
            name,w = choice['candidate'],choice['weight']
            result[key] = rounded(w*predictions[name][key]+(1-w)*predictions['school_calendar'][key])
    return result


class RouteEnsemble:
    def __init__(self, models, choices, cutoff):
        self.models,self.choices,self.cutoff = models,choices,cutoff
    def predict(self,keys):
        return combine(keys,{name:m.predict(keys) for name,m in self.models.items()},self.choices)


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('train','test','sample','out'):p.add_argument('--'+name,type=Path,required=True)
    p.add_argument('--profiles-only',action='store_true')
    p.add_argument('--synthetic',action='store_true')
    args=p.parse_args(argv)
    inputs=verify_inputs({n:getattr(args,n) for n in ('train','test','sample')},args.synthetic)
    train,test=load_labels([args.train]),load_labels([args.test])
    if any(not FIRST<=k[1]<=date(2025,8,31) for k in train):raise ValueError('Invalid train period')
    if any(not date(2025,9,1)<=k[1]<=FINAL_CUTOFF for k in test):raise ValueError('Invalid test period')
    values=load_labels([args.train,args.test]); _,sample=read_sample(args.sample)
    routes=sorted({k[0] for k in values},key=int)
    if set(routes)-{k[0] for k in sample}:raise ValueError('Sample misses known routes')
    for lo,hi,part in [(FIRST,date(2025,8,31),train),(date(2025,9,1),FINAL_CUTOFF,test)]:
        if {k[1] for k in part} != set(days(lo,hi)):raise ValueError('Missing complete input dates')
    if not args.profiles_only:
        missing=[n for n in ('sklearn','lightgbm','catboost') if importlib.util.find_spec(n) is None]
        if missing:raise RuntimeError('Missing training packages: '+', '.join(missing)+'. Install them or use --profiles-only explicitly.')
    factories=candidate_factories(args.profiles_only)
    args.out.mkdir(parents=True,exist_ok=True)
    report={'schema_version':2,'research_commit':RESEARCH_COMMIT,'inputs':inputs,
            'data_kind':'synthetic_not_for_submission' if args.synthetic else 'verified_organizer_labels',
            'selection_warning':'Research validation repeatedly examined in DS-2; not an independent test or platform score.',
            'missing_label_policy':'zero-filled full grid for training and scoring; not proof of zero physical demand',
            'external_policy':'calendar only; no future network notices, weather or validation labels in features',
            'folds':{},'platform_score':None,'library_versions':{}}
    for pkg in ('numpy','scikit-learn','lightgbm','catboost'):
        try:report['library_versions'][pkg]=importlib.metadata.version(pkg)
        except importlib.metadata.PackageNotFoundError:pass
    for label,cutoff,start,end in FOLDS:
        history={k:v for k,v in values.items() if k[1]<=cutoff}
        keys=grid(routes,start,end); truth={k:v for k,v in values.items() if start<=k[1]<=end}
        forecasts={};report['folds'][label]={}
        for name,factory in factories.items():
            t=time.perf_counter();model=factory().fit(history,FIRST,cutoff)
            forecasts[name]=model.predict(keys)
            m=score(keys,truth,forecasts[name])
            report['folds'][label][name]={'metrics':m,'seconds':round(time.perf_counter()-t,3)}
            print(f'{label} {name}: score={m["all"]["wape_score"]:.6f}',flush=True)
        if label=='sep_oct':
            # Forward diagnostic: choose using September only, evaluate October
            # from the SAME Aug31 forecasts (no October/September refitting).
            sep=[k for k in keys if k[1].month==9];october=[k for k in keys if k[1].month==10]
            sept_choices,_=choose_routes(sep,truth,forecasts,routes)
            op=combine(october,forecasts,sept_choices)
            report['october_forward_diagnostic']={'selection':'September only; forecasts fixed at Aug31',
                'choices':sept_choices,'metrics':score(october,{k:truth[k] for k in october if k in truth},op)}
            choices,diagnostics=choose_routes(keys,truth,forecasts,routes)
            ensemble=combine(keys,forecasts,choices)
            report['folds'][label]['route_ensemble']={'metrics':score(keys,truth,ensemble)}
            report['selection']={'selected':'route_ensemble','by_route':choices,'diagnostics':diagnostics,
                'rule':'Per route: lower pooled Sep-Oct error AND >=1% reduction in each month vs school_calendar; weights 0.5 or 1.0.'}
        dump(args.out/'report.json',report)
    selected_names={'school_calendar'}|{c['candidate'] for c in choices.values()}
    fitted={n:factories[n]().fit(values,FIRST,FINAL_CUTOFF) for n in sorted(selected_names)}
    model=RouteEnsemble(fitted,choices,FINAL_CUTOFF);predictions=model.predict(sample)
    report['code_sha256']={q.name:sha256(q) for q in sorted(Path(__file__).parent.glob('*.py'))}
    identity=json.dumps({'inputs':inputs,'choices':choices,'code':report['code_sha256'],
                         'libraries':report['library_versions']},sort_keys=True).encode()
    version='ds1-route-'+hashlib.sha256(identity).hexdigest()[:12]
    if args.synthetic:version='synthetic-NOT-FOR-SUBMISSION-'+version
    report['model_version']=version
    report['cold_start']={'routes':sorted({k[0] for k in sample}-set(routes),key=int),
                          'policy':'zero placeholder; unvalidated, not a required true target'}
    report['submission']=write_submission(args.sample,predictions,args.out/'submission.csv')
    export_api(sample,predictions,args.out/'forecast_api.csv',version)
    (args.out/'model.local.pkl').write_bytes(pickle.dumps(model,protocol=5))
    validate(args.sample,args.out/'submission.csv')
    report['outputs_sha256']={n:sha256(args.out/n) for n in ('submission.csv','forecast_api.csv','model.local.pkl')}
    report['matches_previous_submission'] = report['outputs_sha256']['submission.csv'] == '371d05c44e20b63db110f5a5e27b8da8fafb785fdbc66374307b0ab7304a75ac'
    dump(args.out/'report.json',report)
    print('Selected route models:',json.dumps(choices,ensure_ascii=False),flush=True)
    print('Validated:',version, len(sample),'rows; platform score unknown.',flush=True)
    return report

if __name__=='__main__':
    from ml.forecast.route_specific import main as run_main
    run_main()

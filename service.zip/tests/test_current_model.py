import json
import unittest
from datetime import date,timedelta
from pathlib import Path
from app.model_runtime import artifact,day_predictions,model_card
from app.analytics import aggregate,frontier
from app.data_quality import evaluate_csv
from app.simulation import simulate,load_model
from app.planning import read_context
from app.external_effect import load_effect
ROOT=Path(__file__).resolve().parents[1]
class CurrentModelTest(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.geometry=json.loads((ROOT/'data/routes.json').read_text());_,cls.poi=read_context(ROOT)
  cls.model=load_model(str(ROOT/'model/model.local.pkl'));cls.effect=load_effect(ROOT/'data/weather_effect.json')
 def test_exact_original_artifact_full_competition_grid(self):
  model=artifact();keys=[(str(r),date(2025,11,1)+timedelta(days=n),h) for n in range(61) for r in (1,5,7,11,12,17,25,26,28,50) for h in range(24)]
  expected=model.predict(keys)
  for (r,d,h),y in expected.items(): self.assertEqual(y,day_predictions(d)[int(r),h]['prediction'])
 def test_aggregations_conserve_demand(self):
  values={'date':'2025-11-18','route':'1'};full=aggregate(values,self.geometry,self.poi);stops=self.geometry['1']['stops']
  section=aggregate({**values,'granularity':'section','stop_id':str(stops[0]['id']),'end_stop_id':str(stops[-1]['id'])},self.geometry,self.poi)
  self.assertEqual(full['total'],section['total']);month=aggregate({**values,'period':'month'},self.geometry,self.poi)
  self.assertEqual(len(month['records']),30);day=next(r for r in month['records'] if r['date']=='2025-11-18');self.assertEqual(day['prediction'],full['total'])
 def test_year_has_365_days_explicit_fallback(self):
  result=aggregate({'route':'7','period':'year'},self.geometry,self.poi);self.assertEqual(len(result['records']),365)
  self.assertTrue(any(not x['weather_available'] for x in result['records']));self.assertIn('экстраполяция',result['notice'])
 def test_scenario_conservation_and_frontier(self):
  values={'event':'accident','stop_id':'10463','hour':8,'start_hour':8,'end_hour':10,'reserve':3,'weather':'rain','weather_factor':1.1}
  result=simulate(values,self.geometry,self.poi,self.effect,self.model)
  for row in result['hourly']:
   self.assertEqual(row['weather'],row['scenario']+row['unmet']);self.assertLessEqual(row['added_vehicles'],3)
  f=frontier(values,self.geometry,self.poi,self.effect,self.model);self.assertTrue(all(b['unmet']<=a['unmet'] for a,b in zip(f['points'],f['points'][1:])))
 def test_metric_integrity(self):
  y=day_predictions(date(2025,11,18))[7,8]['prediction'];csv=f'route;date;hour;actual;status\n7;2025-11-18;8;{y};complete\n7;2025-11-18;9;0;partial\n'
  result=evaluate_csv(csv);self.assertEqual(result['selected']['wape_score'],1);self.assertEqual(result['excluded_partial'],1)
  with self.assertRaises(ValueError):evaluate_csv(csv+'7;2025-11-18;8;0;complete\n')
  with self.assertRaises(ValueError):evaluate_csv(csv.replace('2025-11-18','2025-10-18'))
  self.assertIsNone(evaluate_csv('route;date;hour;actual\n7;2025-11-18;8;0\n')['selected']['wape_score'])
 def test_unknown_metrics_and_invalid_scope(self):
  self.assertIsNone(model_card()['metrics']['selected_wape_score'])
  for params in ({'weather_factor':'nan'},{'hour_from':20,'hour_to':10},{'route':'all','granularity':'stop'},{'route':'1','stop_id':'bad','granularity':'stop'}):
   with self.assertRaises(ValueError):aggregate(params,self.geometry,self.poi)
if __name__=='__main__':unittest.main()

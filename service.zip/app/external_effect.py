"""Inference for the explicitly experimental weather association artifact."""
import json
import math
import re
from pathlib import Path


def load_effect(path: Path):
    if not path.is_file():
        return None
    data = json.loads(path.read_text(encoding='utf-8'))
    if data.get('model') != 'ridge-log1p' or not isinstance(data.get('coefficients'), dict):
        raise ValueError('Invalid weather association artifact')
    return data


def rain_mm(text):
    match = re.search(r'(?<!\d)(\d+(?:[.,]\d+)?)\s*мм\b', text, re.I)
    value = float(match.group(1).replace(',', '.')) if match else 1.0
    if not .1 <= value <= 20:
        raise ValueError('Укажите интенсивность дождя от 0,1 до 20 мм/ч')
    return value


def rain_factor(artifact, route, hour, amount):
    """Contrast wet versus dry at fixed route and hour in a log-link model."""
    coef = artifact['coefficients']
    intensity = min(amount, 3) / 3
    log_effect = (coef.get('precip_mm_capped', 0) * min(amount, 10)
                  + intensity * (coef.get('rain_intensity_0_3', 0)
                                 + coef.get(f'route_rain={route}', 0)
                                 + coef.get(f'hour_rain={hour}', 0)))
    if not math.isfinite(log_effect):
        raise ValueError('Invalid weather coefficient')
    # Guardrail against unobserved intensity or unstable route-hour estimates.
    return round(max(.7, min(1.3, math.exp(log_effect))), 4)

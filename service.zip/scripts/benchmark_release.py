"""Repeatable local-process benchmark; never claims Docker/resource-limit compliance."""
import os,sys,json,time,urllib.request,concurrent.futures,hashlib,tempfile,subprocess,socket,resource,platform,threading,argparse,math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if '--serve' in sys.argv:
 os.sched_setaffinity(0,set(map(int,os.environ['BENCH_CPUS'].split(','))))
 sys.path.insert(0,str(ROOT))
 from app.server import Handler,load_state,ThreadingHTTPServer
 class BenchHandler(Handler):
  def do_GET(self):
   if self.path=='/__bench_metrics':
    return self.respond(200,{'cpu_seconds':time.process_time(),'peak_rss_mb':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024})
   return super().do_GET()
 (BenchHandler.auth,BenchHandler.forecast,BenchHandler.geometry,BenchHandler.quality,BenchHandler.actual,BenchHandler.events,BenchHandler.weather,BenchHandler.context_weather,BenchHandler.poi,BenchHandler.weather_effect,BenchHandler.backtest)=load_state()
 server=ThreadingHTTPServer(('127.0.0.1',int(os.environ['BENCH_PORT'])),BenchHandler);server.daemon_threads=True;server.serve_forever();sys.exit()
p=argparse.ArgumentParser();p.add_argument('--out',required=True);args=p.parse_args();out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
report={'environment':platform.platform(),'python':platform.python_version(),'model_sha256':hashlib.sha256((ROOT/'model/model.local.pkl').read_bytes()).hexdigest(),'limitations':['Local process, not Docker','CPU affinity is not CPU quota or exclusive CPU','No memory limit enforced','Only high-water RSS available; current RSS and swap unavailable','Client runs on same host','Closed-loop workload; no internet/TLS latency'], 'runs':[]}
available=sorted(os.sched_getaffinity(0))
for cores in [2,4]:
 with tempfile.TemporaryDirectory() as td:
  salt=os.urandom(16);password=os.urandom(24).hex();auth=Path(td)/'auth.json';auth.write_text(json.dumps({'username':'benchmark','salt':salt.hex(),'password_hash':hashlib.pbkdf2_hmac('sha256',password.encode(),salt,260000).hex(),'session_key':os.urandom(32).hex()}));auth.chmod(0o600)
  sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close();base=f'http://127.0.0.1:{port}';cookie=''
  env=dict(os.environ,AUTH_FILE=str(auth),BENCH_CPUS=','.join(map(str,available[:cores])),BENCH_PORT=str(port),COOKIE_SECURE='false',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2')
  log=(out/f'server_{cores}cpu.log').open('w');start=time.perf_counter();proc=subprocess.Popen([sys.executable,__file__,'--serve'],cwd=ROOT,env=env,stdout=log,stderr=log)
  def req(path,data=None):
   request=urllib.request.Request(base+path,data=json.dumps(data).encode() if data is not None else None,headers={'Content-Type':'application/json','Cookie':cookie})
   with urllib.request.urlopen(request,timeout=90) as r:return r.status,r.read(),dict(r.headers)
  def metrics():return json.loads(req('/__bench_metrics')[1])
  try:
   for _ in range(1200):
    try:req('/health');break
    except Exception:
     if proc.poll() is not None:raise RuntimeError('Server exited; inspect log')
     time.sleep(.1)
   startup=time.perf_counter()-start
   _,_,headers=req('/api/login',{'username':'benchmark','password':password});cookie=next(v for k,v in headers.items() if k.lower()=='set-cookie').split(';')[0]
   run={'affinity_cpus':available[:cores],'startup_seconds':startup,'phases':[]};report['runs'].append(run)
   def payload(profile,i):
    day=f'2025-11-{1+i%28:02d}';route=[1,7,11,12,17,25,26,28,50][i%9]
    if profile in ('warm_mix','soak'):
     return [('/api/model',None),('/api/forecast?route=7&date=2025-11-18&period=day',None),('/api/analysis?route=7&date=2025-11-18&period=day',None),('/api/simulation',{'route':'7','date':'2025-11-18'})][i%4]
    if profile=='varied':
     return [(f'/api/forecast?route={route}&date={day}&period=day',None),(f'/api/analysis?route={route}&date={day}&period=week',None),('/api/simulation',{'route':str(route),'date':day,'weather':'rain','rain_mm':1+i%3})][i%3]
    if profile=='pdf':return '/api/report.pdf',{'route':'7','date':'2025-11-18','period':'day'}
    return '/api/analysis',{'route':'all','date':'2025-11-18','period':'week','events':[{'type':'accident','stop_id':'3698','start_date':'2025-11-18','end_date':'2025-11-20','start_hour':8,'end_hour':12},{'type':'works','stop_id':'10463','start_date':'2025-11-18','end_date':'2025-11-19','start_hour':8,'end_hour':18}]}
   def call(profile,i):
    t=time.perf_counter()
    try:
     status,body,_=req(*payload(profile,i));error=None
     if profile=='pdf' and not body.startswith(b'%PDF'):error='Invalid PDF'
    except Exception as e:status=getattr(e,'code',0);body=b'';error=str(e)
    return {'latency_ms':(time.perf_counter()-t)*1000,'status':status,'bytes':len(body),'error':error}
   for i in range(20):call('warm_mix',i)
   phases=[('warm_mix',400,1,0),('warm_mix',400,8,0),('warm_mix',400,24,0),('varied',240,8,0),('multi_event',24,4,0),('pdf',30,1,0)]
   if cores==2:phases.append(('soak',0,8,60))
   for profile,count,concurrency,duration in phases:
    before=metrics();t=time.perf_counter();rows=[];samples=[];stop=threading.Event();lock=threading.Lock();counter=[0]
    def sample():
     while not stop.wait(.5):
      try:samples.append({'seconds':time.perf_counter()-t,**metrics()})
      except Exception:pass
    sampler=threading.Thread(target=sample);sampler.start()
    def worker():
     local=[]
     while True:
      with lock:
       i=counter[0];counter[0]+=1
      if (duration and time.perf_counter()-t>=duration) or (not duration and i>=count):break
      local.append(call(profile,i))
     return local
    with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as pool:
     for result in pool.map(lambda _:worker(),range(concurrency)):rows.extend(result)
    elapsed=time.perf_counter()-t;stop.set();sampler.join();after=metrics();lat=sorted(r['latency_ms'] for r in rows);errors=sum(r['status']!=200 or r['error'] is not None for r in rows)
    phase={'profile':profile,'concurrency':concurrency,'requests':len(rows),'seconds':elapsed,'rps':len(rows)/elapsed,'successful_rps':(len(rows)-errors)/elapsed,'errors':errors,'p50_ms':lat[math.ceil(len(lat)*.5)-1],'p95_ms':lat[math.ceil(len(lat)*.95)-1],'p99_ms':lat[math.ceil(len(lat)*.99)-1],'cpu_percent_of_affinity_capacity':(after['cpu_seconds']-before['cpu_seconds'])/elapsed/cores*100,'peak_rss_before_mb':before['peak_rss_mb'],'peak_rss_after_mb':after['peak_rss_mb'],'samples':samples}
    name=f'{cores}cpu_{profile}_{concurrency}';(out/f'{name}_requests.json').write_text(json.dumps(rows));run['phases'].append(phase);(out/'benchmark_release.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in phase.items() if k!='samples'}),flush=True)
   t=time.perf_counter();status,body,_=req('/api/analysis/jobs',{'route':'7','date':'2026-01-01','period':'year'});job=json.loads(body);initial=time.perf_counter()-t
   while time.perf_counter()-t<120:
    status,body,_=req('/api/analysis/jobs/'+job['id']);job=json.loads(body)
    if job.get('status') in ('complete','failed'):break
    time.sleep(.2)
   run['annual_job']={'initial_latency_ms':initial*1000,'total_seconds':time.perf_counter()-t,'status':job.get('status'),'record_count':len(job.get('result',{}).get('records',[]))};(out/'benchmark_release.json').write_text(json.dumps(report,indent=2))
  finally:
   proc.terminate()
   try:proc.wait(timeout=10)
   except subprocess.TimeoutExpired:proc.kill();proc.wait()
   log.close()
print(str(out/'benchmark_release.json'))

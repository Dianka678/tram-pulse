#!/usr/bin/env python3
"""Non-destructive acceptance runner. Python stdlib; no fabricated performance claims."""
import argparse,concurrent.futures,csv,datetime,getpass,hashlib,http.client,json,math,os,platform,shutil,ssl,subprocess,tarfile,threading,time,urllib.error,urllib.parse,urllib.request
from pathlib import Path

def main():
 p=argparse.ArgumentParser();p.add_argument('--base',default='https://89.169.144.242');p.add_argument('--container',default='service-tram-1');p.add_argument('--app',default='/home/kuko/app/submission_package_2026-09-27/service');p.add_argument('--soak',type=int,default=600);p.add_argument('--quick',action='store_true',help='Harness smoke check only, not acceptance');p.add_argument('--no-docker',action='store_true');p.add_argument('--update-readme',action='store_true');p.add_argument('--out-root',type=Path,default=Path.home());args=p.parse_args()
 base=args.base.rstrip('/');app=Path(args.app);stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');out=args.out_root/('tram-acceptance-'+stamp);out.mkdir(mode=0o700)
 tls_context=ssl.create_default_context()
 report={'started_utc':stamp,'base_url':base,'python_client':platform.python_version(),'quick_smoke_only':args.quick,'phases':[],'checks':[],'limitations':['Load generator on same VM unless explicitly run elsewhere','Closed-loop phases measure service time; open-loop also includes scheduling delay','No automatic WAPE improvement claims','Batch ingestion is not streaming ingestion','No browser visual error-message audit','No replica failover or destructive restart during this test']};cookie='';monitor_stop=threading.Event();monitor=None;sample_lock=threading.Lock();samples=[]
 def save(name,obj): (out/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2))
 def docker(*cmd):
  r=subprocess.run(['sudo','-n','docker',*cmd],capture_output=True,text=True,timeout=20)
  if r.returncode:raise RuntimeError(r.stderr.strip()[:300])
  return r.stdout
 def call(path,body=None,auth=True,headers=None,raw=None,method=None):
  t=time.perf_counter();data=raw if raw is not None else json.dumps(body).encode() if body is not None else None;h={'Content-Type':'application/json'}
  if auth:h['Cookie']=cookie
  h.update(headers or {})
  try:
   request=urllib.request.Request(base+path,data=data,headers=h,method=method)
   with urllib.request.urlopen(request,timeout=30,context=tls_context) as r:code=r.status;content=r.read();response_headers=dict(r.headers)
  except urllib.error.HTTPError as e:code=e.code;content=e.read();response_headers=dict(e.headers)
  except Exception as e:return {'ms':(time.perf_counter()-t)*1000,'status':0,'bytes':0,'error':str(e)[:250]},None,{}
  try:value=json.loads(content)
  except (ValueError,UnicodeDecodeError):value=None
  return {'ms':(time.perf_counter()-t)*1000,'status':code,'bytes':len(content),'error':None,'pdf_valid':content.startswith(b'%PDF') if path.endswith('.pdf') else None},value,response_headers
 def check(name,path,body=None,expect=(200,),message=False,**kw):
  r,v,h=call(path,body,**kw);msg=v.get('error',{}).get('message') if isinstance(v,dict) and isinstance(v.get('error'),dict) else None
  ok=r['status'] in expect and (not message or bool(msg))
  report['checks'].append({'name':name,'status':r['status'],'expected':list(expect),'passed':ok,'error_message':str(msg)[:300] if msg else None,'transport_error':r['error']});save('report.json',report)
  return r,v,h
 def metrics():
  code="import json,time; from pathlib import Path; keys=['memory.current','memory.max','memory.swap.current','memory.swap.max','memory.events','cpu.stat','cpu.max']; print(json.dumps({'timestamp':time.time(),**{k:Path('/sys/fs/cgroup',k).read_text() if Path('/sys/fs/cgroup',k).exists() else None for k in keys}}))"
  return json.loads(docker('exec',args.container,'python','-c',code))
 def monitor_fn():
  with (out/'resources.jsonl').open('w') as f:
   while not monitor_stop.is_set():
    try:x=metrics()
    except Exception as e:x={'timestamp':time.time(),'monitor_error':str(e)}
    with sample_lock:samples.append(x)
    f.write(json.dumps(x)+'\n');f.flush();monitor_stop.wait(2)
 def summarize(name,rows,elapsed,start,**extra):
  lat=sorted(x['ms'] for x in rows);n=len(rows);bad=sum(x['status']!=200 or x.get('pdf_valid') is False for x in rows)
  q=lambda f:lat[max(0,math.ceil(n*f)-1)] if n else None
  phase={'name':name,'started_epoch':start,'elapsed_seconds':elapsed,'requests':n,'errors':bad,'successful_rps':(n-bad)/elapsed,'p50_ms':q(.5),'p95_ms':q(.95),'p99_ms':q(.99),**extra};save(name+'_requests.json',rows);report['phases'].append(phase);save('report.json',report);print(json.dumps(phase,ensure_ascii=False),flush=True)
 def payload(name,i):
  day=f'2025-11-{1+i%28:02d}';route=[1,7,11,12,17,25,26,28,50][i%9]
  if name=='forecast':return f'/api/forecast?route={route}&date={day}&period=day',None
  if name=='varied':return f'/api/analysis?route={route}&date={day}&period=week',None
  if name=='heavy':return '/api/analysis',{'route':'all','date':'2025-11-18','period':'week','events':[{'type':'accident','stop_id':'3698','start_date':'2025-11-18','end_date':'2025-11-20','start_hour':8,'end_hour':12},{'type':'works','stop_id':'10463','start_date':'2025-11-18','end_date':'2025-11-19','start_hour':8,'end_hour':18}]}
  if name=='pdf':return '/api/report.pdf',{'route':'7','date':'2025-11-18','period':'day'}
  if name=='upload' and i%2==0:return '/api/evaluate',{'csv':'route;date;hour;actual;status\n'+'\n'.join(f'7;2025-11-18;{h};100;complete' for h in range(24))}
  return [('/api/model',None),('/api/forecast?route=7&date=2025-11-18&period=day',None),('/api/analysis?route=7&date=2025-11-18&period=day',None),('/api/simulation',{'route':'7','date':'2025-11-18'})][i%4]
 def phase(name,profile,clients,seconds):
  start=time.time();t=time.perf_counter()
  def worker(k):
   rows=[];i=k
   while time.perf_counter()-t<seconds:
    r,_,_=call(*payload(profile,i));rows.append(r);i+=1
   return rows
  with concurrent.futures.ThreadPoolExecutor(max_workers=clients) as pool:rows=[r for batch in pool.map(worker,range(clients)) for r in batch]
  summarize(name,rows,time.perf_counter()-t,start,clients=clients,profile=profile,method='closed-loop')
 def arrival(rate,seconds):
  # Bounded queue; missed arrivals explicitly counted rather than hidden.
  start=time.time();t=time.perf_counter();gate=threading.BoundedSemaphore(64);futures=[];dropped=0;late=0;n=int(rate*seconds)
  def worker(i,due):
   try:
    r,_,_=call(*payload('mix',i));r['service_ms']=r['ms'];r['ms']=(time.perf_counter()-due)*1000;return r
   finally:gate.release()
  with concurrent.futures.ThreadPoolExecutor(max_workers=32) as pool:
   for i in range(n):
    due=t+i/rate;delay=due-time.perf_counter()
    if delay>0:time.sleep(delay)
    if time.perf_counter()-due>.1:late+=1
    if gate.acquire(blocking=False):futures.append(pool.submit(worker,i,due))
    else:dropped+=1
   rows=[f.result() for f in futures]
  summarize(f'offered_{rate}rps',rows,time.perf_counter()-t,start,offered_rps=rate,scheduled=n,dropped=dropped,scheduler_late_over_100ms=late,method='open-loop bounded64 workers32; latency includes queue/scheduler; dropped arrivals have no latency and are reported separately')
 def ingestion():
  target=out/'synthetic_ingest';target.mkdir();script=app/'scripts/ingest.py'
  if not script.exists():return {'status':'unavailable','streaming_http':'not implemented in supplied code'}
  geo=json.loads((app/'data/routes.json').read_text());sid=str(geo['7']['stops'][0]['id']);count=1000 if args.quick else 100000
  (target/'schedule.csv').write_text('route;hour\n7;8\n')
  with (target/'events.csv').open('w') as f:
   f.write('transaction_id;route;timestamp;status;stop_id\n')
   for i in range(count):f.write(f'{i};7;2025-11-18T08:00:00+03:00;success;{sid}\n')
   f.write(f'0;7;2025-11-18T08:00:00+03:00;success;{sid}\nfail;7;2025-11-18T08:00:00+03:00;failed;{sid}\nlate;7;2025-11-18T23:00:00+03:00;success;{sid}\n')
  t=time.perf_counter();r=subprocess.run(['python3',str(script),str(target/'events.csv'),'--schedule',str(target/'schedule.csv'),'--output',str(target/'normalized.csv')],capture_output=True,text=True,timeout=90);elapsed=time.perf_counter()-t
  audit=json.loads((target/'normalized.audit.json').read_text()) if r.returncode==0 else {};ok=audit.get('accepted')==count and audit.get('duplicates')==1 and audit.get('outside_schedule')==1 and audit.get('unsuccessful')==1
  result={'passed':ok,'exit_code':r.returncode,'seconds':elapsed,'input_rows':count+3,'rows_per_second':(count+3)/elapsed,'audit':audit,'stderr':r.stderr[:500],'scope':'Synthetic batch CLI on host; NOT streaming HTTP or container ingestion throughput'};save('ingestion.json',result);return result
 try:
  r,_,_=check('health TLS validation','/health')
  if r['status']!=200:raise RuntimeError('Health/TLS check failed. Certificate verification is never disabled.')
  username=os.environ.get('BENCH_USER') or input('Логин сайта: ');password=os.environ.pop('BENCH_PASSWORD',None) or getpass.getpass('Пароль сайта: ')
  r,_,h=call('/api/login',{'username':username,'password':password},auth=False);password=None
  if r['status']!=200:raise RuntimeError('Login failed: '+str(r['status']))
  sc=next((v for k,v in h.items() if k.lower()=='set-cookie'),'');cookie=sc.split(';')[0]
  report['https']={'certificate_verified':base.startswith('https://'),'secure_cookie':'; secure' in sc.lower(),'httponly':'; httponly' in sc.lower(),'transport':urllib.parse.urlsplit(base).scheme}
  if not args.no_docker:
   fmt='{"image":{{json .Image}},"cpu":{{.HostConfig.NanoCpus}},"memory":{{.HostConfig.Memory}},"memory_swap":{{.HostConfig.MemorySwap}},"restart_count":{{.RestartCount}},"started":{{json .State.StartedAt}}}'
   report['container']=json.loads(docker('inspect','--format',fmt,args.container));save('docker_version.json',json.loads(docker('version','--format','{{json .}}')))
   fingerprint="import json,hashlib,platform; from pathlib import Path; names=['app/server.py','app/analytics.py','app/scenario_engine.py','model/model.local.pkl']; print(json.dumps({'python':platform.python_version(),'sha256':{n:hashlib.sha256(Path('/srv',n).read_bytes()).hexdigest() for n in names if Path('/srv',n).exists()}}))"
   save('runtime_fingerprint.json',json.loads(docker('exec',args.container,'python','-c',fingerprint)));monitor=threading.Thread(target=monitor_fn,daemon=True);monitor.start()
  for name,path in [('model','/api/model'),('sources','/api/sources'),('developments','/api/developments/catalog')]:
   r,v,_=check(name,path);save(name+'.json',v)
  # Expected failures are separated from performance errors.
  check('requires login','/api/model',auth=False,expect=(401,),message=True)
  check('bad route','/api/analysis?route=999',expect=(400,),message=True)
  check('bad date','/api/analysis?date=not-a-date',expect=(400,),message=True)
  check('reversed hours','/api/analysis?hour_from=20&hour_to=10',expect=(400,),message=True)
  check('unknown stop','/api/analysis?route=7&granularity=stop&stop_id=not-a-stop',expect=(400,),message=True)
  check('unknown endpoint','/api/not-a-real-endpoint',expect=(404,),message=True)
  check('unknown job','/api/analysis/jobs/not-a-job',expect=(404,),message=True)
  check('malformed JSON','/api/analysis',raw=b'{',expect=(400,),message=True)
  check('wrong JSON type','/api/analysis',raw=b'[]',expect=(400,),message=True)
  check('wrong origin','/api/simulation',body={},headers={'Origin':'https://other.invalid'},expect=(403,),message=True)
  check('oversized body','/api/analysis',raw=b' '*70000,expect=(400,413),message=True)
  check('bad uploaded CSV','/api/evaluate',body={'csv':'bad;columns\n1;2'},expect=(400,),message=True)
  check('duplicate CSV keys','/api/evaluate',body={'csv':'route;date;hour;actual\n7;2025-11-18;8;100\n7;2025-11-18;8;100'},expect=(400,),message=True)
  check('negative CSV count','/api/evaluate',body={'csv':'route;date;hour;actual\n7;2025-11-18;8;-1'},expect=(400,),message=True)
  check('invalid event','/api/analysis',body={'events':[{'stop_id':'not-a-stop'}]},expect=(400,),message=True)
  check('health after bad requests','/health')
  for horizon,n in [('day',24),('week',7),('month',30)]:
   r,v,_=check(horizon,'/api/analysis?route=7&date=2025-11-18&period='+horizon)
   report['checks'].append({'name':horizon+' record count','passed':isinstance(v,dict) and len(v.get('records',[]))==n,'expected_rows':n})
  # Inputs exercise extension interfaces; do not imply forecast accuracy.
  for weather in ['dry','rain']:check('weather '+weather,'/api/simulation',{'route':'7','date':'2025-11-18','weather':weather,'rain_mm':2})
  check('construction scenario','/api/analysis',{'route':'7','date':'2025-11-18','period':'week','developments':[{'route':7,'stop_id':'3698','kind':'office','opening_date':'2025-11-01','source':'https://example.org/synthetic-test-only','people':1000}]})
  for i in range(20):call(*payload('mix',i))
  duration=1 if args.quick else 30
  phase('forecast_only','forecast',8,duration)
  phase('https_mix_8','mix',8,duration);phase('https_mix_24','mix',24,duration)
  arrival(200,1 if args.quick else 30);arrival(300,1 if args.quick else 30)
  phase('weekly_varied','varied',8,duration)
  phase('upload_and_forecast','upload',4,duration)
  phase('weekly_events','heavy',4,duration)
  phase('pdf','pdf',1,1 if args.quick else 15)
  # One annual job only; no production queue flood or destructive failover.
  t=time.perf_counter();r,v,_=check('create annual job','/api/analysis/jobs',{'route':'7','date':'2026-01-01','period':'year'},expect=(202,));year={'accepted_ms':r['ms']}
  if r['status']==202 and isinstance(v,dict):
   job_id=v.get('id');foreground=[]
   while time.perf_counter()-t<120:
    rr,_,_=call(*payload('forecast',0));foreground.append(rr)
    _,j,_=call('/api/analysis/jobs/'+str(job_id))
    if isinstance(j,dict) and j.get('status') in ('complete','failed'):
     year.update(status=j.get('status'),rows=len((j.get('result') or {}).get('records',[])),error=j.get('error'));break
    time.sleep(.2)
   else:year['status']='timeout'
   year['seconds']=time.perf_counter()-t;year['passed']=year.get('status')=='complete' and year.get('rows')==365;save('foreground_during_year.json',foreground)
  report['annual_job']=year
  report['ingestion']=ingestion()
  # Audit actual deployed source, without exposing credentials/environment.
  if not args.no_docker:
   audit="import json; from pathlib import Path; s=Path('/srv/app/server.py').read_text(); a=Path('/srv/app/analytics.py').read_text(); print(json.dumps({'jobs_in_process': 'JOBS = {}' in a,'one_job_worker':'max_workers=1' in a,'http_ingest_route_literal_present':'/api/ingest' in s,'note':'Limited source audit, not replica traffic/failover test'}))"
   report['scaling_audit']=json.loads(docker('exec',args.container,'python','-c',audit))
  phase('soak_10min','mix',8,2 if args.quick else args.soak)
  check('health after load','/health')
 except KeyboardInterrupt:report['interrupted']=True
 except Exception as e:report['fatal_error']=str(e);print('Остановлено:',e,flush=True)
 finally:
  monitor_stop.set()
  if monitor:monitor.join(timeout=25)
  def kv(x):return dict((k,int(v)) for k,v in (line.split() for line in x.splitlines()))
  usable=[x for x in samples if x.get('memory.current') and x.get('cpu.stat')]
  def resource_summary(ss):
   if len(ss)<2:return None
   mem=[int(x['memory.current']) for x in ss];first,last=ss[0],ss[-1];quota,period=last['cpu.max'].split();cores=int(quota)/int(period) if quota!='max' else None;dt=last['timestamp']-first['timestamp'];cpu=(kv(last['cpu.stat'])['usage_usec']-kv(first['cpu.stat'])['usage_usec'])/1e6/dt
   return {'samples':len(ss),'seconds':dt,'cpu_percent_capacity':cpu/cores*100 if cores else None,'ram_min_mib':min(mem)/2**20,'ram_max_mib':max(mem)/2**20,'ram_start_mib':mem[0]/2**20,'ram_end_mib':mem[-1]/2**20,'swap_max_bytes':max(int(x.get('memory.swap.current') or 0) for x in ss),'swap_limit':last.get('memory.swap.max'),'oom_events_end':kv(last['memory.events'])}
  report['resources']=resource_summary(usable)
  for q in report['phases']:q['resources']=resource_summary([s for s in usable if q['started_epoch']<=s['timestamp']<=q['started_epoch']+q['elapsed_seconds']])
  save('report.json',report)
  lines=['# Производительность и приёмочные проверки', '',f'Дата UTC: {stamp}. URL: {base}. Контейнер: {args.container}.', '', '**Это smoke-прогон, не доказательство производительности.**' if args.quick else 'Фактические результаты этого запуска; не заменять ими метрики другой среды.','', '| Профиль | Запросы | Успешных RPS | p95 мс | p99 мс | Ошибки |','|---|---:|---:|---:|---:|---:|']
  arrival_notes=[]
  for q in report['phases']:
   lines.append(f"| {q['name']} | {q['requests']} | {q['successful_rps']:.2f} | {q['p95_ms']:.2f} | {q['p99_ms']:.2f} | {q['errors']} |")
   if q.get('offered_rps'):arrival_notes.append(f"\nОткрытая нагрузка {q['offered_rps']} RPS: dropped={q['dropped']}; опоздания генератора >100 мс={q['scheduler_late_over_100ms']}. Задержка включает ожидание в очереди; dropped учитываются отдельно.\n")
  lines+=arrival_notes
  lines+=['','## Ресурсы контейнера','', '```json',json.dumps({'limits':report.get('container'),'resources':report.get('resources')},ensure_ascii=False,indent=2),'```','','CPU нормирован на реальную квоту cpu.max, а не на одно ядро. Клиент работает на той же ВМ и конкурирует за ресурсы; для внешней задержки нужен отдельный генератор. RAM — memory.current cgroup, не docker stats. Стабильность RAM оценивается по временному ряду; нулевой swap в отсчётах не означает, что swap запрещён. Подробные ресурсы каждого профиля — report.json.','','## Надёжность','',f"Проверок: {len(report['checks'])}; не прошли: {sum(not x['passed'] for x in report['checks'])}.",'','```json',json.dumps([x for x in report['checks'] if not x['passed']],ensure_ascii=False,indent=2),'```','', 'Ожидаемые 400/401/403/404 проверяются отдельно и не смешиваются с ошибками нагрузочного теста. Наличие непустого сообщения API проверяется автоматически; понятность сообщения в браузере проверяется вручную.','', '## Годовой расчёт','', '```json',json.dumps(report.get('annual_job'),ensure_ascii=False,indent=2),'```','','## Приём данных и масштабирование','','/api/evaluate принимает синтетический CSV только для проверки API; его значения WAPE не являются качеством модели. Пакетный scripts/ingest.py проверяет нормализацию, дубликаты, статусы и расписание. Измерение CLI — на хосте и не доказывает потоковую запись в контейнере. Потоковый durable ingestion API в поставке не реализован.','','Аудит jobs: '+json.dumps(report.get('scaling_audit'),ensure_ascii=False)+'. In-memory задания требуют общей очереди/результатов или sticky routing; горизонтальная отказоустойчивость не подтверждена. Два контейнера в этом тесте не запускаются.','','## Внешние данные','','Проверены доступность паспорта/источников, переключение дождя и сценарий застройки. ERA5 — ретроспективные данные, не будущий прогноз. Трафик, реестр новых маршрутов и причинный эффект строительства не подтверждены. Работоспособность интерфейса признака не доказывает улучшение WAPE. Для него нужен отдельный парный backtest и отчёт автора модели.','','## Ограничения и ручная приёмка','','Проверить в браузере вход, понятность ошибок, выгрузку CSV/PDF, дождь и события, годовой статус; отдельно зафиксировать доступ из России без VPN. HTTPS-проверка использует стандартную проверку сертификата без insecure-флагов. Closed-loop не является гарантией SLA; 200/300 RPS — отдельные попытки с учётом пропусков генератора. Дорогие запросы измерены отдельно, не скрыты быстрым /health.']
  lines+=['','## TLS и синтетический ingestion','', '```json',json.dumps({'https':report.get('https'),'ingestion':report.get('ingestion')},ensure_ascii=False,indent=2),'```']
  if report.get('fatal_error'):lines+=['','**Прогон прерван:** '+report['fatal_error']]
  text='\n'.join(lines)+'\n';(out/'README_PERFORMANCE.md').write_text(text)
  if args.update_readme and not args.quick and report['phases'] and app.is_dir():
   readme=app/'README.md';old=readme.read_text() if readme.exists() else '';start='<!-- ACCEPTANCE_RESULTS_START -->';end='<!-- ACCEPTANCE_RESULTS_END -->'
   if start in old and end in old:old=old.split(start)[0]+old.split(end,1)[1]
   shutil.copy2(readme,app/('README.before-acceptance-'+stamp+'.md')) if readme.exists() else None
   readme.write_text(start+'\n'+text+end+'\n\n'+old);report['readme_updated']=str(readme);save('report.json',report)
  archive=args.out_root/('tram-acceptance-'+stamp+'.tar.gz')
  with tarfile.open(archive,'w:gz') as tf:tf.add(out,arcname=out.name)
  print('\nРезультаты:',archive,flush=True)
  if report.get('fatal_error'):raise SystemExit(1)
if __name__=='__main__':main()

"""Transparent dispatch calculations built on a route-hour forecast.

Stop values are an explicitly uniform illustration until observed stop counts
or independently validated weights become available.
"""
import csv
import math
import re
from datetime import date
from pathlib import Path


def read_context(root: Path):
    weather = {}
    path = root / 'data' / 'weather_hourly.csv'
    if path.exists():
        with path.open(newline='', encoding='utf-8-sig') as stream:
            reader = csv.DictReader(stream, delimiter=';')
            if reader.fieldnames != ['date', 'hour', 'temperature_2m', 'precipitation', 'snowfall']:
                raise ValueError('weather_hourly.csv: неверные столбцы')
            for row in reader:
                key = (row['date'], int(row['hour']))
                if key in weather or not 0 <= key[1] < 24:
                    raise ValueError('weather_hourly.csv: повтор или неверный час')
                values = {name: float(row[name]) for name in reader.fieldnames[2:]}
                if any(not math.isfinite(value) for value in values.values()):
                    raise ValueError('weather_hourly.csv: неверное значение')
                weather[key] = values
    poi = {}
    path = root / 'data' / 'stop_poi.csv'
    if path.exists():
        with path.open(newline='', encoding='utf-8-sig') as stream:
            reader = csv.DictReader(stream, delimiter=';')
            if reader.fieldnames not in ([ 'stop_id', 'schools_400m', 'hospitals_400m', 'offices_400m'],
                                         [ 'stop_id', 'metro_400m', 'schools_400m', 'hospitals_400m', 'offices_400m']):
                raise ValueError('stop_poi.csv: неверные столбцы')
            for row in reader:
                stop_id = row['stop_id']
                if stop_id in poi:
                    raise ValueError('stop_poi.csv: повтор остановки')
                values = {name: int(row[name]) if row[name] != '' else None for name in reader.fieldnames[1:]}
                if any(value is not None and value < 0 for value in values.values()):
                    raise ValueError('stop_poi.csv: отрицательное количество')
                if any(value is not None for value in values.values()):
                    poi[stop_id] = values
    return weather, poi


def parameters(params):
    def number(name, default, low, high):
        value = float(params.get(name, [str(default)])[0])
        if not math.isfinite(value) or not low <= value <= high:
            raise ValueError(f'{name}: допустимо {low}–{high}')
        return value

    return {name: number(name, *spec) for name, spec in {
        'headway': (10, 2, 60), 'proposed_headway': (8, 2, 60),
        'cycle_minutes': (90, 15, 300), 'capacity': (120, 1, 500),
        'cost_per_vehicle_hour': (0, 0, 100000),
    }.items()}


def calculate(demand, headway, proposed_headway, cycle_minutes, capacity, cost_per_vehicle_hour):
    def variant(minutes):
        departures = 60 / minutes
        vehicles = math.ceil(cycle_minutes / minutes)
        boardings = demand / departures
        return {'headway_minutes': minutes, 'departures_per_hour': round(departures, 2),
                'vehicles_required': vehicles, 'vehicle_hours_for_one_hour': vehicles,
                'validations_per_departure': round(boardings, 1),
                'validation_to_capacity_ratio': round(boardings / capacity, 3),
                'illustrative_hour_cost': round(vehicles * cost_per_vehicle_hour, 2)}

    base, proposed = variant(headway), variant(proposed_headway)
    return {'base': base, 'proposed': proposed,
            'delta_vehicles': proposed['vehicles_required'] - base['vehicles_required'],
            'delta_hour_cost': round(proposed['illustrative_hour_cost'] - base['illustrative_hour_cost'], 2)}


def stop_estimates(stops, demand, poi, day=None, hour=8):
    if not stops:
        return []
    # Only the activity index changes with time and POIs. Passenger counts
    # remain uniform because stop-level target labels are unavailable.
    share, remainder = divmod(demand, len(stops))
    day = day or date(2025, 11, 1)
    weekday = day.weekday() < 5
    school_open = weekday and day.month not in (6, 7, 8) and 7 <= hour < 18
    office_open = weekday and 8 <= hour < 20
    metro_open = hour >= 5 or hour <= 1
    result = []
    for index, stop in enumerate(stops):
        info = poi.get(str(stop['id']))
        if info:
            metro = info.get('metro_400m')
            schools = info['schools_400m']
            offices = info['offices_400m']
            source = 'osm_partial_400m' if any(v is None for v in (metro, schools, offices)) else 'osm_current_400m'
        else:
            metro = int(bool(re.search('метро', stop['name'], re.I)))
            schools = int(bool(re.search('школ', stop['name'], re.I)))
            offices = None
            source = 'stop_name_proxy'
        # Descriptive POI activity, not a fitted boarding multiplier.
        index_value = 1 + .4 * (metro or 0) * (1 if metro_open else .15) + .6 * (schools or 0) * (1 if school_open else .08)
        if offices is not None:
            index_value += .35 * offices * (1 if office_open else .12)
        result.append({'stop_id': str(stop['id']), 'name': stop['name'],
             'lat': stop['lat'], 'lon': stop['lon'], 'estimate': share + (index < remainder),
             'activity_index': round(index_value, 2), 'context_source': source,
             'poi': {'metro_400m': metro, 'schools_400m': schools,
                     'offices_400m': offices, 'hospitals_400m': info.get('hospitals_400m') if info else None}})
    return result

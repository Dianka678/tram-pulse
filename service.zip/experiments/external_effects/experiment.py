"""Reproducible retrospective association study: weather and tram validations.

Run: python experiments/external_effects/experiment.py
Uses private labels outside the Docker image; exports a small, dependency-free
weather sensitivity artifact for the API, plus fold metrics and provenance.
"""
import csv
import hashlib
import json
import math
import os
import sys
from datetime import date
from pathlib import Path

import numpy as np
from sklearn.feature_extraction import DictVectorizer
from sklearn.linear_model import Ridge

ROOT = Path(__file__).resolve().parents[2]
LABELS = Path(os.environ.get('TRAM_LABELS_DIR', ROOT.parent / 'upload'))
OUT = ROOT / 'data' / 'weather_effect.json'
RESULT = Path(__file__).with_name('results.json')
WEATHER = ROOT / 'data' / 'weather_hourly.csv'


def load():
    weather = {}
    with WEATHER.open(newline='', encoding='utf-8-sig') as stream:
        for row in csv.DictReader(stream, delimiter=';'):
            weather[(row['date'], int(row['hour']))] = (
                float(row['temperature_2m']), float(row['precipitation']), float(row['snowfall']))
    records = []
    for name in ('labels_day_train(1).csv', 'labels_day_test(1).csv'):
        with (LABELS / name).open(newline='', encoding='utf-8-sig') as stream:
            for row in csv.DictReader(stream, delimiter=';'):
                d, h = row['date'], int(row['hour'])
                route = int(row['route'])
                # Official changes of route/service; do not identify their
                # passenger-count shifts as a weather response.
                if route in (7, 50) and (('2025-07-10' <= d <= '2025-08-10')
                                         or ('2025-09-20' <= d <= '2025-09-21')):
                    continue
                if (d, h) in weather:
                    records.append((route, d, h, int(row['boardings']), weather[(d, h)]))
    return records


def features(row, external):
    route, day, hour, _, (temp, precip, snow) = row
    d = date.fromisoformat(day)
    dow = d.weekday()
    x = {f'route={route}': 1, f'hour={hour}': 1, f'dow={dow}': 1,
         f'route_hour={route}_{hour}': 1, f'route_dow={route}_{dow}': 1,
         f'hour_dow={hour}_{dow}': 1,
         'season_sin': math.sin(2 * math.pi * d.timetuple().tm_yday / 365),
         'season_cos': math.cos(2 * math.pi * d.timetuple().tm_yday / 365)}
    if external:
        p = min(precip, 10)
        rain = min(p, 3) / 3
        x.update({'precip_mm_capped': p, 'rain_intensity_0_3': rain,
                  'temperature_c': temp / 20, 'temperature_sq': (temp / 20) ** 2,
                  'snow_cm': min(snow, 5), f'route_rain={route}': rain,
                  f'hour_rain={hour}': rain})
    return x


def fit_predict(train, val, external, alpha=100):
    v = DictVectorizer()
    X = v.fit_transform(features(row, external) for row in train)
    model = Ridge(alpha=alpha, solver='lsqr')
    model.fit(X, np.log1p([r[3] for r in train]))
    pred = np.expm1(model.predict(v.transform(features(row, external) for row in val))).clip(0)
    return model, v, pred


def score(rows, pred):
    truth = np.array([r[3] for r in rows])
    return round(1 - np.abs(truth - pred).sum() / max(truth.sum(), 1), 6)


def main():
    records = load()
    folds = []
    for month in (7, 8, 9, 10):
        cutoff = f'2025-{month:02d}-01'
        stop = f'2025-{month+1:02d}-01'
        train = [r for r in records if r[1] < cutoff]
        val = [r for r in records if cutoff <= r[1] < stop]
        base = fit_predict(train, val, False)[2]
        with_weather = fit_predict(train, val, True)[2]
        folds.append({'month': month, 'train_rows': len(train), 'val_rows': len(val),
                      'calendar_score': score(val, base), 'weather_score': score(val, with_weather),
                      'delta': round(score(val, with_weather) - score(val, base), 6),
                      'rain_hours': len({(r[1], r[2]) for r in val if r[4][1] >= .1})})
        print(folds[-1], flush=True)
    train = [r for r in records if r[1] < '2025-11-01']
    model, vectorizer, _ = fit_predict(train, train[:1], True)
    coefficients = dict(zip(vectorizer.get_feature_names_out(), model.coef_.tolist()))
    effects = {k: coefficients.get(k, 0) for k in coefficients if
               k in ('precip_mm_capped', 'rain_intensity_0_3', 'temperature_c',
                     'temperature_sq', 'snow_cm') or k.startswith(('route_rain=', 'hour_rain='))}
    artifact = {'version': 'weather-association-2025-09-26', 'model': 'ridge-log1p',
                'training_end': '2025-10-31', 'training_rows': len(train),
                'rain_definition': '>=0.1 mm/h', 'rain_counterfactual_mm': 1.0,
                'coefficients': effects, 'folds': folds,
                'interpretation': 'Retrospective conditional association, not causal repair/rain effect',
                'weather_source': 'Open-Meteo ERA5 hourly Moscow 55.75,37.62',
                'source_url': 'https://open-meteo.com/en/docs/historical-weather-api'}
    OUT.write_text(json.dumps(artifact,ensure_ascii=False,indent=2),encoding='utf-8')
    summary = {k: artifact[k] for k in ('version','training_end','training_rows','folds','interpretation')}
    summary['input_sha256'] = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in
                               [LABELS/'labels_day_train(1).csv', LABELS/'labels_day_test(1).csv', WEATHER]}
    summary['excluded_route_changes'] = 'route 7/50: July 10-August 10 and September 20-21 2025'
    RESULT.write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print('artifact:', OUT, 'results:',RESULT)


if __name__ == '__main__':
    main()

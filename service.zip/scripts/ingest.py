"""Reproducible local normalization of validation events; no fabricated stops.
Usage: python scripts/ingest.py events.csv --schedule schedule.csv --output normalized.csv
Events: transaction_id;route;timestamp;status;stop_id
Schedule: route;hour (one row per working hour). timestamp must contain +03:00.
"""
import argparse,csv,json
from collections import Counter
from datetime import datetime,timedelta
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('input',type=Path);p.add_argument('--schedule',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
with a.schedule.open(encoding='utf-8-sig') as f: operating={(int(r['route']),int(r['hour'])) for r in csv.DictReader(f,delimiter=';')}
if not operating or any(not 0<=h<24 for _,h in operating):raise ValueError('Empty/invalid operating schedule')
geometry=json.loads((Path(__file__).resolve().parents[1]/'data/routes.json').read_text());stops={(int(r),str(s['id'])):s for r,g in geometry.items() for s in g.get('stops',[])}
seen=set();counts=Counter();audit=Counter();mapped={}
with a.input.open(encoding='utf-8-sig') as f:
 reader=csv.DictReader(f,delimiter=';')
 for row in reader:
  audit['input']+=1
  if row['transaction_id'] in seen:audit['duplicates']+=1;continue
  seen.add(row['transaction_id'])
  if row['status']!='success':audit['unsuccessful']+=1;continue
  t=datetime.fromisoformat(row['timestamp']);r=int(row['route'])
  if t.utcoffset()!=timedelta(hours=3):raise ValueError('Timestamp must have Moscow +03:00 offset')
  if (r,t.hour) not in operating:audit['outside_schedule']+=1;continue
  s=stops.get((r,row.get('stop_id','')))
  if s is None:audit['unmapped']+=1
  key=(r,str(t.date()),t.hour,str(s['id']) if s else '')
  counts[key]+=1;mapped[key]=s;audit['accepted']+=1
with a.output.open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f,delimiter=';');w.writerow(['route','date','hour','stop_id','validations','lat','lon'])
 for key,total in sorted(counts.items()):
  s=mapped[key] or {};w.writerow([*key,total,s.get('lat',''),s.get('lon','')])
a.output.with_suffix('.audit.json').write_text(json.dumps(dict(audit),ensure_ascii=False,indent=2))
print(dict(audit))

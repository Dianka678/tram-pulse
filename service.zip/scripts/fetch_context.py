"""Fetch optional external context; run on a host with access to public APIs.

Examples:
  python scripts/fetch_context.py weather --start 2025-01-01 --end 2025-12-31
  python scripts/fetch_context.py poi
"""
import argparse
import csv
import json
import math
import os
import re
import ssl
import subprocess
from datetime import date, datetime, timezone
from pathlib import Path
from urllib.error import URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'data'
TLS_CONTEXT = None


def verified_context(ca_bundle=None):
    """Prefer the Windows trust store; keep certificate verification enabled."""
    if ca_bundle:
        path = Path(ca_bundle)
        if not path.is_file():
            raise ValueError(f'Файл корневого сертификата не найден: {path}')
        return ssl.create_default_context(cafile=str(path))
    try:
        import truststore
    except ImportError:
        return ssl.create_default_context()
    return truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT)


def windows_curl_json(url, body=None):
    """Use Microsoft's Schannel curl when the MSYS Python CA store is broken."""
    system_root = os.environ.get('SystemRoot') or os.environ.get('WINDIR')
    if not system_root:
        raise RuntimeError('Windows curl недоступен: SystemRoot не задан')
    executable = Path(system_root) / 'System32' / 'curl.exe'
    if not executable.is_file():
        raise RuntimeError(f'Windows curl не найден: {executable}')
    command = [str(executable), '--fail', '--silent', '--show-error',
               '--max-time', '120', '--connect-timeout', '20']
    if body is not None:
        command += ['--header', 'Content-Type: application/x-www-form-urlencoded',
                    '--data-binary', '@-']
    command += ['--url', url]
    try:
        result = subprocess.run(command, input=body, capture_output=True, timeout=130, check=False)
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError('Windows curl: время ожидания истекло') from exc
    if result.returncode:
        detail = result.stderr.decode('utf-8', errors='replace').strip()[-400:]
        raise RuntimeError(f'Windows curl: {detail or "ошибка соединения"}')
    if len(result.stdout) > 20 * 1024 * 1024:
        raise RuntimeError('Ответ POI слишком большой')
    return json.loads(result.stdout)


def fetch_json(url, body=None):
    request = Request(url, data=body, headers={'User-Agent': 'tram-service/1.0 (research context)'})
    try:
        with urlopen(request, timeout=120, context=TLS_CONTEXT or verified_context()) as response:
            return json.load(response)
    except URLError as exc:
        if 'CERTIFICATE_VERIFY_FAILED' in str(exc) and (os.name == 'nt' or os.environ.get('SystemRoot')):
            return windows_curl_json(url, body)
        raise


def weather(start, end):
    date.fromisoformat(start)
    date.fromisoformat(end)
    if start > end:
        raise ValueError('start должен быть не позже end')
    params = {'latitude': 55.75, 'longitude': 37.62, 'start_date': start, 'end_date': end,
              'hourly': 'temperature_2m,precipitation,snowfall',
              'timezone': 'Europe/Moscow', 'models': 'era5'}
    url = 'https://archive-api.open-meteo.com/v1/archive?' + urlencode(params)
    data = fetch_json(url)['hourly']
    fields = ['date', 'hour', 'temperature_2m', 'precipitation', 'snowfall']
    rows = []
    for stamp, temp, precip, snow in zip(data['time'], data['temperature_2m'],
                                          data['precipitation'], data['snowfall']):
        if any(value is None for value in (temp, precip, snow)):
            continue
        timestamp = datetime.fromisoformat(stamp)
        rows.append({'date': timestamp.date().isoformat(), 'hour': timestamp.hour,
                     'temperature_2m': temp, 'precipitation': precip, 'snowfall': snow})
    write_csv(OUT / 'weather_hourly.csv', fields, rows)
    metadata('weather_hourly.csv', url, 'Ретроспективный реанализ ERA5; не прогноз на дату отсечки')
    print(f'weather_hourly.csv: {len(rows)} часов')


def distance_m(a, b, c, d):
    x = math.radians(d - b) * math.cos(math.radians((a + c) / 2))
    y = math.radians(c - a)
    return math.hypot(x, y) * 6371000


def poi_queries(routes):
    fragments = {}
    small = {}
    for route_id, route in routes.items():
        route_stops = route.get('stops', [])
        if not route_stops:
            continue
        south, north = min(s['lat'] for s in route_stops) - .005, max(s['lat'] for s in route_stops) + .005
        west, east = min(s['lon'] for s in route_stops) - .01, max(s['lon'] for s in route_stops) + .01
        bbox = f'{south},{west},{north},{east}'
        parts = {'metro': f'node["railway"="subway_entrance"]({bbox});',
                 'schools_hospitals': f'nwr["amenity"~"^(school|hospital)$"]({bbox});',
                 'offices': f'nwr["office"]({bbox});'}
        fragments[route_id] = ''.join(parts.values())
        for category, fragment in parts.items():
            small[f'route_{route_id}_{category}'] = f'[out:json][timeout:45];({fragment});out center;'
    return {route_id: f'[out:json][timeout:90];({fragment});out center;'
            for route_id, fragment in fragments.items()}, \
           '[out:json][timeout:180];(' + ''.join(fragments.values()) + ');out center;', small


def raw_elements(path, allow_empty=False):
    path = Path(path)
    if not path.is_file() or path.stat().st_size > 20 * 1024 * 1024:
        raise ValueError(f'Нет JSON или файл больше 20 МБ: {path}')
    try:
        data = json.loads(path.read_text(encoding='utf-8-sig'))
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise ValueError(f'Нужен raw data JSON из Overpass: {path}') from exc
    if not isinstance(data, dict) or not isinstance(data.get('elements'), list) or (not allow_empty and not data['elements']):
        raise ValueError(f'Нужен raw data JSON из Overpass, не GeoJSON или HTML: {path}')
    if 'remark' in data and ('error' in str(data['remark']).lower() or 'timeout' in str(data['remark']).lower()):
        raise ValueError(f'Ответ Overpass содержит ошибку: {path}: {str(data["remark"])[:180]}')
    return data['elements']


def poi(input_json=None, input_dir=None, make_queries=False, allow_partial=False):
    routes = json.loads((OUT / 'routes.json').read_text(encoding='utf-8'))
    stops = {str(s['id']): s for route in routes.values() for s in route.get('stops', [])}
    if not stops:
        raise ValueError('Сначала создайте data/routes.json из справочника')
    queries, combined, small = poi_queries(routes)
    if make_queries:
        target = OUT / 'poi_queries'
        target.mkdir(exist_ok=True)
        (target / 'all_routes.overpassql').write_text(combined + '\n', encoding='utf-8')
        for route_id, query in queries.items():
            (target / f'route_{route_id}.overpassql').write_text(query + '\n', encoding='utf-8')
        for name, query in small.items():
            (target / f'{name}.overpassql').write_text(query + '\n', encoding='utf-8')
        print(f'Созданы {target / "all_routes.overpassql"}, {len(queries)} запросов по маршрутам и {len(small)} по категориям')
        return
    endpoints = ('https://overpass.private.coffee/api/interpreter',
                 'https://overpass-api.de/api/interpreter')
    elements = {}
    fields = ['stop_id', 'metro_400m', 'schools_400m', 'hospitals_400m', 'offices_400m']
    categories = set(fields[1:])
    coverage = {stop_id: set() for stop_id in stops}
    if input_json or input_dir:
        if input_json:
            paths = [Path(input_json)]
            for names in coverage.values():
                names.update(categories)
        else:
            folder = Path(input_dir)
            if allow_partial:
                paths = sorted(folder.glob('route_*.json'))
                if not paths:
                    raise ValueError(f'В {folder} нет route_*.json')
            else:
                route_paths = [folder / f'route_{route_id}.json' for route_id in queries]
                paths = route_paths if all(p.is_file() for p in route_paths) else [folder / f'{name}.json' for name in small]
                missing = [str(p.name) for p in paths if not p.is_file()]
                if missing:
                    raise ValueError('Для импорта нужны все файлы одного набора. Нет: ' + ', '.join(missing))
        for path in paths:
            if input_dir:
                match = re.fullmatch(r'route_(\d+)(?:_(metro|schools_hospitals|offices))?\.json', path.name)
                if not match or match.group(1) not in queries:
                    raise ValueError(f'Неожиданное имя JSON: {path.name}')
                available = ({'metro': {'metro_400m'},
                              'schools_hospitals': {'schools_400m', 'hospitals_400m'},
                              'offices': {'offices_400m'}}.get(match.group(2), categories))
                for stop in routes[match.group(1)]['stops']:
                    coverage[str(stop['id'])].update(available)
            for item in raw_elements(path, allow_empty=bool(input_dir)):
                elements[(item['type'], item['id'])] = item
        if not elements:
            raise ValueError('В скачанных JSON нет объектов POI; CSV не записан')
        source = 'https://overpass-turbo.eu/ (manual raw data JSON: ' + ', '.join(str(p) for p in paths) + ')'
    else:
        for route_id, query in queries.items():
            errors = []
            for url in endpoints:
                try:
                    data = fetch_json(url, urlencode({'data': query}).encode())
                    for item in data['elements']:
                        elements[(item['type'], item['id'])] = item
                    break
                except Exception as exc:
                    errors.append(f'{url}: {exc}')
            else:
                if all('CERTIFICATE_VERIFY_FAILED' in error or 'Windows curl:' in error for error in errors):
                    raise RuntimeError('POI не загружены через HTTPS. Можно скачать JSON браузером: '
                        'python scripts/fetch_context.py poi --make-queries; затем '
                        'python scripts/fetch_context.py poi --input-json data\\poi_downloads\\all_routes.json. '
                        'Подробности: ' + '; '.join(errors)) from None
                raise RuntimeError('POI не загружены; старый файл сохранён. ' + '; '.join(errors))
        source = 'https://wiki.openstreetmap.org/wiki/Overpass_API'
        for names in coverage.values():
            names.update(categories)
    objects = []
    for item in elements.values():
        lat, lon = item.get('lat', item.get('center', {}).get('lat')), item.get('lon', item.get('center', {}).get('lon'))
        if lat is None or lon is None:
            continue
        tags = item.get('tags', {})
        category = ('metro_400m' if tags.get('railway') == 'subway_entrance' else
                    'schools_400m' if tags.get('amenity') == 'school' else
                    'hospitals_400m' if tags.get('amenity') == 'hospital' else 'offices_400m')
        objects.append((lat, lon, category))
    rows = []
    for stop_id, stop in stops.items():
        record = {key: 0 if key in coverage[stop_id] else '' for key in fields[1:]}
        for lat, lon, category in objects:
            if category in coverage[stop_id] and distance_m(stop['lat'], stop['lon'], lat, lon) <= 400:
                record[category] += 1
        rows.append({'stop_id': stop_id, **record})
    write_csv(OUT / 'stop_poi.csv', fields, rows)
    covered = {key: sum(key in names for names in coverage.values()) for key in fields[1:]}
    metadata('stop_poi.csv', source,
             'Текущее OSM в 400 м по прямой; пустая ячейка = категория не загружена, 0 = объект не найден. '
             f'Покрытие по категориям из {len(stops)} остановок: {covered}. Историческое состояние и часы работы не подтверждены')
    print(f'stop_poi.csv: {len(rows)} остановок; покрытие: {covered}')


def write_csv(path, fields, rows):
    with path.open('w', newline='', encoding='utf-8-sig') as stream:
        writer = csv.DictWriter(stream, fields, delimiter=';')
        writer.writeheader()
        writer.writerows(rows)


def metadata(name, source, caveat):
    path = OUT / 'context_sources.json'
    sources = json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}
    sources[name] = {'source': source, 'retrieved_at_utc': datetime.now(timezone.utc).isoformat(), 'note': caveat}
    path.write_text(json.dumps(sources, ensure_ascii=False, indent=2), encoding='utf-8')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('dataset', choices=['weather', 'poi'])
    parser.add_argument('--start', default='2025-01-01')
    parser.add_argument('--end', default='2025-12-31')
    parser.add_argument('--ca-bundle', type=Path, help='PEM-файл доверенного корневого сертификата сети')
    sources = parser.add_mutually_exclusive_group()
    sources.add_argument('--make-queries', action='store_true', help='создать запросы для Overpass Turbo без сети')
    sources.add_argument('--input-json', type=Path, help='импортировать один raw data JSON из браузера')
    sources.add_argument('--input-dir', type=Path, help='импортировать route_N.json для всех маршрутов')
    parser.add_argument('--allow-partial', action='store_true', help='импортировать имеющиеся route_*.json; неизвестные категории оставить пустыми')
    args = parser.parse_args()
    if args.dataset != 'poi' and (args.make_queries or args.input_json or args.input_dir):
        parser.error('Эти параметры доступны только для poi')
    if args.allow_partial and not args.input_dir:
        parser.error('--allow-partial допустим только вместе с --input-dir')
    if not (args.make_queries or args.input_json or args.input_dir):
        TLS_CONTEXT = verified_context(args.ca_bundle)
    try:
        weather(args.start, args.end) if args.dataset == 'weather' else poi(args.input_json, args.input_dir, args.make_queries, args.allow_partial)
    except (RuntimeError, ValueError, URLError) as exc:
        parser.exit(1, f'Ошибка: {exc}\n')

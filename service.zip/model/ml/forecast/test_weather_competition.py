"""Small in-memory software tests; no persistent generated datasets."""
import unittest
from datetime import date,timedelta
from unittest.mock import patch
import numpy as np
from ml.forecast.weather_competition import weather_rows,VARIABLES,corrected,select,join,causal_residual_training

class WeatherTests(unittest.TestCase):
    def payload(self):
        return {'timezone':'Europe/Moscow','utc_offset_seconds':10800,'hourly':{
            'time':['2025-01-01T00:00','2025-01-01T01:00'],
            **{v:[1.,2.] for v in VARIABLES}}}

    def test_missing_weather_is_not_silently_imputed(self):
        p=self.payload();p['hourly']['temperature_2m'][1]=None
        with self.assertRaisesRegex(ValueError,'Missing'):weather_rows(p)

    def test_weather_time_alignment_and_rolling_values(self):
        p=self.payload();r=weather_rows(p)
        self.assertEqual(r[date(2025,1,1),1][-3:],[1.5,3.,0.])
        p['hourly']['time'][1]='2025-01-01T02:00'
        with self.assertRaisesRegex(ValueError,'contiguous'):weather_rows(p)

    def test_weather_must_beat_matched_control_in_both_months(self):
        keys=[('1',date(2025,m,1),12) for m in (9,10)]
        truth=dict.fromkeys(keys,100)
        preds={'reference':dict.fromkeys(keys,80)}
        for w in (.25,.5,1.):
            preds[f'calendar_{w}']=dict.fromkeys(keys,95)
            preds[f'weather_{w}']={keys[0]:100,keys[1]:90}
        chosen,control,_=select(keys,truth,preds,['1'])
        self.assertTrue(chosen['1'].startswith('calendar'))
        preds['weather_0.5']=dict.fromkeys(keys,99)
        chosen,_,_=select(keys,truth,preds,['1'])
        self.assertEqual(chosen['1'],'weather_0.5')

    def test_corrections_are_bounded_and_route5_stays_zero(self):
        keys=[('1',date(2025,11,1),12),('5',date(2025,11,1),12)]
        base={keys[0]:100,keys[1]:0}
        self.assertEqual(corrected(keys,base,[99,99],1),{keys[0]:135,keys[1]:0})
        self.assertEqual(corrected(keys,base,[-99,-99],1),{keys[0]:65,keys[1]:0})

    def test_residual_training_has_no_current_block_labels(self):
        start=date(2025,1,1);end=date(2025,3,31)
        history={('1',start+timedelta(days=i),12):i+1 for i in range((end-start).days+1)}
        seen=[]
        def factory(prefix,cutoff,choices):
            self.assertLessEqual(max(k[1] for k in prefix),cutoff)
            class Reference:
                def predict(_,keys):
                    self.assertGreater(min(k[1] for k in keys),cutoff)
                    seen.append((cutoff,min(k[1] for k in keys)))
                    return dict.fromkeys(keys,10)
            return Reference()
        with patch('ml.forecast.weather_competition.fit_reference',side_effect=factory):
            keys,base,scale,target,blocks=causal_residual_training(history,end,{})
        self.assertEqual(len(seen),2)
        self.assertEqual(blocks[0]['train_through'],'2025-01-31')
        self.assertEqual(keys[0][1],date(2025,2,1))

if __name__=='__main__':unittest.main()

"""Stage the bind-mounted 0600 credential into tmpfs, then drop privileges."""
import os
import sys
import json
from pathlib import Path

source = os.environ.get('AUTH_FILE', '/run/tram-secrets/auth.json')
raw = os.environ.pop('AUTH_JSON', None)
if raw is None:
    if not Path(source).is_file():
        raise SystemExit('Set secret AUTH_JSON or mount AUTH_FILE; run scripts/create_auth.py locally to create credentials.')
    raw = Path(source).read_text(encoding='utf-8')
record = json.loads(raw)
for key in ('username', 'salt', 'password_hash', 'session_key'):
    if not isinstance(record.get(key), str) or not record[key]:
        raise SystemExit('Invalid authentication configuration')
target = '/tmp/tram-auth.json'
fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
with os.fdopen(fd, 'w', encoding='utf-8') as staged:
    json.dump(record, staged)
os.chown(target, 10001, 10001)
os.chmod(target, 0o600)
os.environ['AUTH_FILE'] = target
os.setgroups([])
os.setgid(10001)
os.setuid(10001)
os.execv(sys.executable, [sys.executable, '-m', 'app.server'])

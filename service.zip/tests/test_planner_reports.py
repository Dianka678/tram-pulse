import json,unittest,math
from datetime import date
from pathlib import Path
from unittest.mock import patch
from app.scenario_engine import simulate_multi,horizon,project_demand,validate
from app.quality_experiment import experiment
from app.planning import read_context
ROOT=Path(__file__).resolve().parents[1]
class PlannerTest(unittest.TestCase):
 def setUp(self):
  self.g={'1':{'stops':[{'id':'a','name':'Источник A','lat':55.75,'lon':37.6}]},'7':{'stops':[{'id':'b','name':'Пересадка B','lat':55.751,'lon':37.6}]},'11':{'stops':[{'id':'c','name':'Источник C','lat':55.752,'lon':37.6}]}}
  self.events=[{'type':'accident','stop_id':s,'start_date':'2025-11-18','end_date':'2025-11-20','start_hour':8,'end_hour':12} for s in ['a','c']]
  def predictions(day):return {(r,h):{'prediction':500 if r in [1,11] else 200 if r==7 else 0,'reference':500 if r in [1,11] else 200 if r==7 else 0,'calendar':500 if r in [1,11] else 200 if r==7 else 0,'weather_available':True} for r in [1,5,7,11,12,17,25,26,28,50] for h in range(24)}
  self.predictions=predictions
 def test_shared_reserve_and_no_destination_overbooking(self):
  with patch('app.scenario_engine.day_predictions',self.predictions):d=simulate_multi({'date':'2025-11-18','events':self.events,'reserve':3},self.g,{})
  for h in d['hourly']:
   self.assertEqual(h['scenario']+h['unmet'],h['weather']);self.assertLessEqual(h['added_vehicles'],3)
  row=next(x for x in d['records'] if x['route']==7 and x['hour']==8)
  self.assertLessEqual(row['scenario'],576+math.floor(row['added_vehicles']*64));self.assertGreater(row['transferred'],0)
  self.assertEqual(sum(f['count'] for f in d['flows'] if f['hour']==8),d['current']['redirected'])
 def test_overlapping_events_do_not_double_count(self):
  with patch('app.scenario_engine.day_predictions',self.predictions):
   one=simulate_multi({'events':self.events[:1]},self.g,{})
   two=simulate_multi({'events':[self.events[0],self.events[0]]},self.g,{})
  self.assertEqual(one['current']['displaced'],two['current']['displaced'])
 def test_multiday_and_hour_filter(self):
  with patch('app.scenario_engine.day_predictions',self.predictions):d=horizon({'date':'2025-11-18','period':'week','events':self.events,'hour_from':9,'hour_to':10},self.g,{})
  self.assertEqual(sum(n['displaced']>0 for n in d['network']),3)
  self.assertEqual(sum(e['displaced'] for e in d['events']),sum(n['displaced'] for n in d['network']))
  self.assertEqual(sum(e['redirected'] for e in d['events']),sum(n['redirected'] for n in d['network']))
 def test_development_ramp_and_net_growth(self):
  project={'kind':'residential','opening_date':'2026-01-01','people':1000,'occupancy':80,'tram_share':10,'trips':1,'net_new_share':50,'ramp_months':1}
  self.assertEqual(sum(project_demand(project,date(2025,12,31))),0)
  self.assertLess(sum(project_demand(project,date(2026,1,1))),sum(project_demand(project,date(2026,1,30))))
  self.assertEqual(sum(project_demand(project,date(2026,1,30))),40)
  project['net_new_share']=0;self.assertEqual(sum(project_demand(project,date(2026,1,30))),0)
 def test_invalid_events_rejected(self):
  for e in [{**self.events[0],'end_date':'2025-01-01'},{**self.events[0],'stop_id':'bad'},{**self.events[0],'start_hour':12,'end_hour':8}]:
   with self.assertRaises(ValueError):validate({'events':[e]},self.g)
 def test_quality_demo_never_claims_score(self):
  with patch('app.quality_experiment.day_predictions',self.predictions):q=experiment({'route':7,'date':'2025-11-18','gap_start':8,'gap_end':12})
  self.assertIsNone(q['masked_wape']['restored']);self.assertLess(q['zero']['total'],q['restored']['total'])
 def test_withheld_fact_uses_truth_only_for_scoring(self):
  text='route;date;hour;actual;status\n'+'\n'.join(f'7;2025-11-18;{h};300;complete' for h in range(24))
  with patch('app.quality_experiment.day_predictions',self.predictions):q=experiment({'route':7,'csv':text})
  self.assertAlmostEqual(q['masked_wape']['restored'],2/3);self.assertEqual(q['masked_wape']['zero'],0)
  with self.assertRaises(ValueError):experiment({'route':7,'csv':text.replace(';23;', ';22;')})
if __name__=='__main__':unittest.main()

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [ ! -f secrets/auth.json ]; then python3 scripts/create_auth.py; fi
if [ ! -f deploy/.env ]; then
  cp deploy/.env.example deploy/.env
  echo 'Edit deploy/.env: SITE_DOMAIN and ACME_EMAIL, then rerun deploy/start.sh.'
  exit 1
fi
docker compose --env-file deploy/.env -f deploy/compose.production.yaml config --quiet
docker compose --env-file deploy/.env -f deploy/compose.production.yaml up -d --build
docker compose --env-file deploy/.env -f deploy/compose.production.yaml ps

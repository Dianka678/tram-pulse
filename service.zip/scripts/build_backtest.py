"""Aggregate observed Sep-Oct holdout hours without shipping original labels.

python scripts/build_backtest.py --model-source ../competition/model.py \
    --train '.../labels_day_train(1).csv' --test '.../labels_day_test(1).csv'
"""
import argparse
import hashlib
import importlib.util
import json
from collections import defaultdict
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def build(model_path, train_path, test_path, output):
    spec = importlib.util.spec_from_file_location('competition_model', model_path)
    model = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(model)
    history = model.read_labels((train_path, test_path))
    fitted = model.fit(history, date(2025, 8, 31))
    days = defaultdict(lambda: {'actual': 0, 'prediction': 0, 'hours': 0})
    routes = defaultdict(lambda: {'actual': 0, 'prediction': 0, 'absolute_error': 0, 'hours': 0})
    deviations = []
    for (route, day, hour), actual in sorted(history.items()):
        if not date(2025, 9, 1) <= day <= date(2025, 10, 31):
            continue
        prediction = model.forecast((route, day, hour), fitted, calendar=False)
        daily = days[(route, day.isoformat())]
        daily['actual'] += actual
        daily['prediction'] += prediction
        daily['hours'] += 1
        entry = routes[route]
        entry['actual'] += actual
        entry['prediction'] += prediction
        entry['absolute_error'] += abs(actual - prediction)
        entry['hours'] += 1
        if abs(actual - prediction) >= max(50, .3 * max(prediction, 1)):
            deviations.append({'route': route, 'date': day.isoformat(), 'hour': hour,
                               'actual': actual, 'prediction': prediction,
                               'delta': actual - prediction})
    total_actual = sum(x['actual'] for x in routes.values())
    total_error = sum(x['absolute_error'] for x in routes.values())
    top_per_route = [alert for route in model.ROUTES for alert in
                     sorted((x for x in deviations if x['route'] == route),
                            key=lambda x: abs(x['delta']), reverse=True)[:12]]
    result = {
        'period': ['2025-09-01', '2025-10-31'], 'training_end': '2025-08-31',
        'method': 'competition/model.py; observed hours only, no missing-to-zero imputation',
        'caveat': 'Правило для маршрута 7 выбиралось с просмотром этого периода: score исследовательский, не независимый.',
        'paired_score': round(1 - total_error / total_actual, 6),
        'observed_hours': sum(x['hours'] for x in routes.values()),
        'expected_hours': len(model.ROUTES) * 61 * 24,
        'routes': [{'route': route, **value,
                    'score': round(1 - value['absolute_error'] / value['actual'], 6) if value['actual'] else None}
                   for route, value in sorted(routes.items())],
        'days': [{'route': route, 'date': day, **values}
                 for (route, day), values in sorted(days.items())],
        'alerts': sorted(top_per_route, key=lambda x: abs(x['delta']), reverse=True),
        'alert_count': len(deviations),
        'source_sha256': {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                          for path in (model_path, train_path, test_path)}
    }
    output.write_text(json.dumps(result, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
    print(f'{result["observed_hours"]} paired hours; score {result["paired_score"]}; {result["alert_count"]} signals')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model-source', type=Path, default=ROOT.parent / 'competition' / 'model.py')
    parser.add_argument('--train', type=Path, default=ROOT.parent / 'upload' / 'labels_day_train(1).csv')
    parser.add_argument('--test', type=Path, default=ROOT.parent / 'upload' / 'labels_day_test(1).csv')
    parser.add_argument('--out', type=Path, default=ROOT / 'data' / 'backtest_summary.json')
    args = parser.parse_args()
    build(args.model_source, args.train, args.test, args.out)

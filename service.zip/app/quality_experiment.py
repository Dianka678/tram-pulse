"""Mask known values and compare zero-fill with independent model inference."""
import csv,io,math
from datetime import date
from .model_runtime import day_predictions,ROUTES
from .simulation import number

def experiment(values):
    r=int(values.get('quality_route',values.get('route',7))) if str(values.get('quality_route',values.get('route',7)))!='all' else 7
    if r not in ROUTES or r==5:raise ValueError('Для эксперимента выберите маршрут с историей, кроме №5')
    d=date.fromisoformat(values.get('date','2025-11-18'));lo=number(values,'gap_start',8,0,23,True);hi=number(values,'gap_end',12,1,24,True)
    if lo>=hi:raise ValueError('Начало пропуска должно быть меньше конца')
    headway=number(values,'headway',10,2,60);cycle=number(values,'cycle_minutes',90,15,300);capacity=number(values,'capacity',120,1,500)
    forecast=day_predictions(d);truth={h:forecast[r,h]['prediction'] for h in range(24)}
    mode='forecast_demo';text=values.get('csv','')
    if text:
        if not isinstance(text,str) or len(text)>2000000:raise ValueError('CSV до 2 МБ')
        mode='withheld_actual';reader=csv.DictReader(io.StringIO(text.lstrip('\ufeff')),delimiter=';' if ';' in text.splitlines()[0] else ',');truth={};seen=set()
        if not {'route','date','hour','actual'}.issubset(reader.fieldnames or []):raise ValueError('CSV: route;date;hour;actual;status')
        for row in reader:
            if int(row['route'])!=r or row['date']!=str(d):continue
            h=int(row['hour']);v=float(row['actual'])
            if h in seen or not 0<=h<24 or not math.isfinite(v) or v<0 or not v.is_integer():raise ValueError('Дубликат или неверное наблюдение')
            seen.add(h)
            status=row.get('status','complete') or 'complete'
            if status not in ('complete','partial'):raise ValueError('Неизвестный статус наблюдения')
            if status=='complete':truth[h]=int(v)
        if set(truth)!=set(range(24)):raise ValueError('Для эксперимента нужны 24 полных часа выбранного маршрута и даты')
        if not date(2025,11,1)<=d<=date(2025,12,31):raise ValueError('Фактическая проверка только в ноябре–декабре 2025, после обучения')
    rows=[{'hour':h,'truth':truth[h],'zero':0 if lo<=h<hi else truth[h],'restored':forecast[r,h]['prediction'] if lo<=h<hi else truth[h]} for h in range(24)]
    def variant(key):
        total=sum(x[key] for x in rows);peak=max(rows,key=lambda x:x[key]);vehicles=math.ceil(peak[key]*cycle/(60*capacity*.8))
        return {'total':total,'peak':peak[key],'peak_hour':peak['hour'],'indicative_vehicles':vehicles,'indicative_extra':max(0,vehicles-math.ceil(cycle/headway))}
    masked=[x for x in rows if lo<=x['hour']<hi];den=sum(x['truth'] for x in masked)
    def score(key):return max(0,1-sum(abs(x[key]-x['truth']) for x in masked)/den) if den else None
    return {'mode':mode,'route':r,'date':str(d),'gap':[lo,hi],'records':rows,'truth':variant('truth'),'zero':variant('zero'),'restored':variant('restored'),'masked_wape':{'zero':score('zero') if mode=='withheld_actual' else None,'restored':score('restored') if mode=='withheld_actual' else None},'notice':('Проверка на скрытых полных фактических часах. Модель не обучалась на них; это локальная проверка выбранного интервала, не официальный score.' if mode=='withheld_actual' else 'Демонстрация на прогнозе: истинные пассажирские значения неизвестны. Восстановление совпадает с моделью по построению, поэтому WAPE не рассчитывается.'),'effect':'Эксперимент показывает ошибку решения при замене пропуска нулём. Рабочий прогноз уже использует модель и не меняется от этой проверки. При реальном пропуске проверяют связь/расписание, помечают оценку как восстановленную и сверяют с прибывшим фактом. Расчёт вагонов — индикатор, не измеренная заполненность.'}

"""Exploratory route-hour POI interaction; no stop-level ground truth.

The geometry supplied with the challenge starts on 2025-10-20. The historical
experiment below is descriptive and must never be sold as an as-of backtest.
"""
import argparse
import csv
import hashlib
import importlib.util
import json
import math
import re
from datetime import date
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
ROUTES = ROOT / 'data/routes.json'
OUTPUT = ROOT / 'data/stop_activity_model.json'


def proxy(stops):
    return [{'stop_id': str(s['id']), 'metro': int(bool(re.search(r'метро', s['name'], re.I))),
             'schools': int(bool(re.search(r'школ', s['name'], re.I))), 'offices': None,
             'source': 'stop_name_proxy'} for s in stops]


def read_poi(path):
    if not path.exists():
        return {}
    with path.open(encoding='utf-8-sig', newline='') as f:
        reader = csv.DictReader(f, delimiter=';')
        required = {'stop_id', 'metro_400m', 'schools_400m', 'offices_400m'}
        if not required.issubset(reader.fieldnames or []):
            raise ValueError('POI requires stop_id;metro_400m;schools_400m;offices_400m')
        rows = list(reader)
        if any(row.get(key, '') == '' for row in rows for key in required - {'stop_id'}):
            raise ValueError('Для ML-опыта требуется полное покрытие POI; частичный CSV допустим только для интерфейса')
        return {row['stop_id']: {'stop_id': row['stop_id'],
                'metro': int(row['metro_400m']), 'schools': int(row['schools_400m']),
                'offices': int(row['offices_400m']), 'source': 'osm_current_400m'} for row in rows}


def context(routes, poi):
    by_route, density = {}, {}
    for route, item in routes.items():
        stops = item['stops']
        values = [poi.get(str(s['id']), p) for s, p in zip(stops, proxy(stops))]
        by_route[int(route)] = values
        density[int(route)] = [sum((v[k] or 0) for v in values) / max(1, len(values)) * 10
                               for k in ('metro', 'schools', 'offices')]
    return by_route, density


def activity(day, hour):
    # Category schedules are assumptions, not verified hours of individual POIs.
    school_term = day.month not in (6, 7, 8) and day.weekday() < 5
    return np.array([1.0 if hour >= 5 or hour <= 1 else .15,
                     1.0 if school_term and 7 <= hour < 18 else .08,
                     1.0 if day.weekday() < 5 and 8 <= hour < 20 else .12])


def features(density, route, day, hour):
    return np.array(density[route]) * activity(day, hour)


def paired(history, base, density, start, end):
    return [(key, y, max(0, base(key)), features(density, key[0], key[1], key[2]))
            for key, y in sorted(history.items()) if key[0] in density and start <= key[1] <= end]


def fit(rows, alpha=5000):
    x = np.array([r[3] for r in rows]); y = np.array([max(-.6, min(.6, r[1] / max(100, r[2]) - 1)) for r in rows])
    weights = np.sqrt(np.array([max(1, r[2]) for r in rows]))
    # Center on zero residual; ridge stabilizes the four-route geography.
    return np.linalg.solve((x * weights[:, None]).T @ (x * weights[:, None]) + alpha * np.eye(3),
                           (x * weights[:, None]).T @ (y * weights)).tolist()


def compare(rows, coef):
    total = sum(r[1] for r in rows)
    base_error = sum(abs(r[1] - r[2]) for r in rows)
    adjusted_error = sum(abs(r[1] - max(0, round(r[2] * max(.75, min(1.25, 1 + np.dot(coef, r[3])))))) for r in rows)
    return {'hours': len(rows), 'base_score': round(1 - base_error / total, 6),
            'context_score': round(1 - adjusted_error / total, 6),
            'delta': round((base_error - adjusted_error) / total, 6)}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--train', type=Path, required=True)
    p.add_argument('--test', type=Path, required=True)
    p.add_argument('--model-source', type=Path, required=True)
    p.add_argument('--poi', type=Path, default=ROOT / 'data/stop_poi.csv')
    p.add_argument('--output', type=Path, default=OUTPUT)
    args = p.parse_args()
    spec = importlib.util.spec_from_file_location('contest_model', args.model_source)
    contest = importlib.util.module_from_spec(spec); spec.loader.exec_module(contest)
    history = contest.read_labels((args.train, args.test))
    routes = json.loads(ROUTES.read_text(encoding='utf-8'))
    poi = read_poi(args.poi)
    by_route, density = context(routes, poi)
    baseline = contest.fit(history, date(2025, 8, 31))
    base = lambda key: contest.forecast(key, baseline, calendar=False)
    calibration = paired(history, base, density, date(2025, 1, 1), date(2025, 8, 31))
    holdout = paired(history, base, density, date(2025, 9, 1), date(2025, 10, 31))
    coef = fit(calibration)
    result = {'name': 'route_poi_activity_proxy_v1', 'as_of': '2025-10-31',
              'feature_source': 'osm_current_400m' if poi else 'stop_name_proxy',
              'available_categories': ['metro', 'schools', 'offices'] if poi else ['metro', 'schools'],
              'coefficients': dict(zip(('metro', 'schools', 'offices'), [round(c, 6) for c in coef])),
              'calibration': compare(calibration, coef), 'holdout': compare(holdout, coef),
              'routes_with_geometry_and_labels': sorted(set(by_route) & set(contest.ROUTES)),
              'geometry_earliest_asof': '2025-10-20',
              'caveat': 'Descriptive route-hour association; geometry is later than training cutoff. No stop labels or validated stop-level score. Category hours are assumptions.',
              'sha256': {k: hashlib.sha256(v.read_bytes()).hexdigest() for k, v in
                         {'train': args.train, 'test': args.test, 'routes': ROUTES}.items()}}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({k: result[k] for k in ('feature_source', 'coefficients', 'calibration', 'holdout')}, ensure_ascii=False))


if __name__ == '__main__':
    main()

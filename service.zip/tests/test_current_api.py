import json,threading,unittest,time,os,tempfile,secrets,hashlib
from http.cookiejar import CookieJar
from urllib.request import Request,build_opener,HTTPCookieProcessor,urlopen
from urllib.error import HTTPError
from app.server import Handler,load_state,ThreadingHTTPServer,ROOT
class ApiTest(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.temp=tempfile.TemporaryDirectory(dir=ROOT)
  cls.previous_auth=os.environ.get('AUTH_FILE')
  password=secrets.token_urlsafe(20);salt=secrets.token_bytes(16)
  auth={'username':'test-user','salt':salt.hex(),'password_hash':hashlib.pbkdf2_hmac('sha256',password.encode(),salt,260000).hex(),'session_key':secrets.token_hex(32)}
  from pathlib import Path
  auth_path=Path(cls.temp.name)/'auth.json';auth_path.write_text(json.dumps(auth));os.environ['AUTH_FILE']=str(auth_path)
  (Handler.auth,Handler.forecast,Handler.geometry,Handler.quality,Handler.actual,Handler.events,Handler.weather,Handler.context_weather,Handler.poi,Handler.weather_effect,Handler.backtest)=load_state()
  Handler.log_message=lambda *a:None
  cls.server=ThreadingHTTPServer(('127.0.0.1',0),Handler);threading.Thread(target=cls.server.serve_forever,daemon=True).start();cls.base='http://127.0.0.1:'+str(cls.server.server_address[1])
  cls.client=build_opener(HTTPCookieProcessor(CookieJar()))
  cls.client.open(Request(cls.base+'/api/login',data=json.dumps({'username':'test-user','password':password}).encode(),headers={'Content-Type':'application/json'})).read()
 @classmethod
 def tearDownClass(cls):
  cls.server.shutdown();cls.server.server_close();cls.temp.cleanup()
  if cls.previous_auth is None:os.environ.pop('AUTH_FILE',None)
  else:os.environ['AUTH_FILE']=cls.previous_auth
 def get(self,path):return json.load(self.client.open(self.base+path))
 def post(self,path,value):return json.load(self.client.open(Request(self.base+path,data=json.dumps(value).encode(),headers={'Content-Type':'application/json'})))
 def test_requires_auth_and_origin(self):
  with self.assertRaises(HTTPError) as ctx:urlopen(self.base+'/api/model')
  self.assertEqual(ctx.exception.code,401)
  with self.assertRaises(HTTPError) as ctx:self.client.open(Request(self.base+'/api/simulation',data=b'{}',headers={'Origin':'https://other.invalid'}))
  self.assertEqual(ctx.exception.code,403)
 def test_routes_forecast_model_consistent(self):
  card=self.get('/api/model');self.assertEqual(card['name'],'WeatherEnsemble')
  a=self.get('/api/analysis?route=7&date=2025-11-18');b=self.get('/api/forecast?route=7&date=2025-11-18');c=self.post('/api/simulation',{'date':'2025-11-18'})
  self.assertEqual([x['prediction'] for x in a['records']],[x['prediction'] for x in b['records']]);self.assertEqual([x['prediction'] for x in a['records']],[x['base'] for x in c['records'] if x['route']==7])
 def test_async_and_errors(self):
  j=self.post('/api/analysis/jobs',{'period':'year','route':'7'})
  for _ in range(100):
   d=self.get('/api/analysis/jobs/'+j['id'])
   if d['status']!='running':break
   time.sleep(.05)
  self.assertEqual(d['status'],'complete');self.assertEqual(len(d['result']['records']),365)
  with self.assertRaises(HTTPError) as ctx:self.get('/api/analysis?route=13')
  self.assertEqual(ctx.exception.code,400)
  with self.assertRaises(HTTPError) as ctx:self.post('/api/scenario/model',{})
  self.assertEqual(ctx.exception.code,410)
if __name__=='__main__':unittest.main()

import pickle
from pathlib import Path
from datetime import date

MODEL_PATH = Path(__file__).parent / "model.local.pkl"

with open(MODEL_PATH, "rb") as f:
    model = pickle.load(f)


def predict(keys):
    return model.predict(keys)


if __name__ == "__main__":
    result = predict([
        ("1", date(2025, 11, 10), 8),
    ])

    print(result)
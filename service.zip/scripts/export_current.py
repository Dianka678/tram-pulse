"""Materialize the current model, never reuse an old forecast CSV."""
import csv,json,sys
from datetime import date,timedelta
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from app.model_runtime import day_predictions,model_card
with (ROOT/'data/forecast.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f,delimiter=';');w.writerow(['route','date','hour','prediction'])
 for n in range(61):
  d=date(2025,11,1)+timedelta(days=n)
  for (r,h),v in day_predictions(d).items():w.writerow([r,str(d),h,v['prediction']])
(ROOT/'data/model_card.json').write_text(json.dumps(model_card(),ensure_ascii=False,indent=2))
print('Exported 14640 route-hour predictions from',model_card()['version'])

from ml.submit.adapter import read_sample, write_submission
_, keys = read_sample(ROOT/'data/submission_template.csv')
predictions = {k: day_predictions(k[1])[int(k[0]),k[2]]['prediction'] for k in keys}
result = write_submission(ROOT/'data/submission_template.csv', predictions, ROOT/'data/submission_competition.csv')
(ROOT/'docs/submission_check.json').write_text(json.dumps(result,indent=2))
print('Submission checked:',result)

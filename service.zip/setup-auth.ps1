param([switch]$StartService)

$ErrorActionPreference = 'Stop'
$project = $PSScriptRoot
$credentials = Join-Path $project 'secrets\auth.json'
$generator = Join-Path $project 'scripts\create_auth.py'

if (-not (Test-Path -LiteralPath $generator -PathType Leaf)) {
    throw 'Put setup-auth.ps1 in the tram-service directory, next to compose.yaml.'
}
if (Test-Path -LiteralPath $credentials -PathType Container) {
    throw 'secrets\auth.json is a directory. Rename it manually before creating credentials.'
}
if (Test-Path -LiteralPath $credentials -PathType Leaf) {
    Write-Host 'The credentials file already exists; it was not changed.'
} else {
    $pythonCommand = Get-Command python3 -ErrorAction SilentlyContinue
    if ($pythonCommand) {
        & python3 $generator
    } else {
        $pythonCommand = Get-Command python -ErrorAction SilentlyContinue
        if (-not $pythonCommand) { throw 'Python 3 is required to create the first login. Install Python 3, then rerun start.ps1.' }
        & python $generator
    }
    if ($LASTEXITCODE -ne 0) {
        throw 'Credential generation failed; see the message above.'
    }
    if (-not (Test-Path -LiteralPath $credentials -PathType Leaf)) {
        throw 'Credential generation did not produce a regular auth.json file.'
    }
    Write-Host 'Created secrets\auth.json. Keep it private; do not send or commit it.'
}

if ($StartService) {
    Push-Location $project
    try {
        & docker compose up --build --force-recreate -d
        if ($LASTEXITCODE -ne 0) { throw 'Docker Compose failed.' }
        & docker compose ps
        Write-Host 'Check http://127.0.0.1:8080/health and then open http://127.0.0.1:8080/'
    } finally {
        Pop-Location
    }
}

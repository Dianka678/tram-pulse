"""Shared aggregation, experiment views, reserve frontier and async year jobs."""
import calendar
import csv
import io
import math
import secrets
import threading
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from datetime import date, timedelta
from .model_runtime import day_predictions, model_card, ROUTES
from .planning import stop_estimates
from .simulation import simulate, number

POOL = ThreadPoolExecutor(max_workers=1)
JOBS = {}
JOB_LOCK = threading.Lock()

def query_values(params):
    return {k:v[0] for k,v in params.items()}

def aggregate(values, geometry, poi):
    if 'events' in values or 'developments' in values or values.get('date', '2025') > '2025-12-31':
        from .scenario_engine import horizon
        return horizon(values, geometry, poi)
    day = date.fromisoformat(values.get('date','2025-11-18'))
    if not date(2025,11,1) <= day <= date(2025,12,31):
        raise ValueError('Начало прогноза: 01.11–31.12.2025')
    period = values.get('period','day')
    if period not in ('day','week','month','year'): raise ValueError('Неизвестный горизонт')
    n = {'day':1,'week':7,'month':calendar.monthrange(day.year,day.month)[1], 'year':365}[period]
    start = day.replace(day=1) if period=='month' else day
    routes = ROUTES if str(values.get('route','all'))=='all' else (int(values['route']),)
    if any(r not in ROUTES for r in routes): raise ValueError('Неизвестный маршрут')
    granularity = values.get('granularity','route')
    if granularity not in ('route','stop','section'): raise ValueError('Неизвестная агрегация')
    if granularity != 'route' and len(routes)!=1: raise ValueError('Выберите один маршрут для остановки / участка')
    lo = number(values,'hour_from',0,0,23,True); hi = number(values,'hour_to',24,1,24,True)
    if lo>=hi: raise ValueError('Начальный час должен быть меньше конечного')
    factors = {k:number(values,k,1,.5,1.5) for k in ('weather_factor','event_factor','season_factor')}
    factor = math.prod(factors.values())
    rows=[]
    for offset in range(n):
        d = start+timedelta(days=offset)
        predictions = day_predictions(d)
        for r in routes:
            shape = geometry.get(str(r),{}).get('stops',[])
            chosen=[]
            if granularity!='route':
                ids=[str(s['id']) for s in shape]
                first=str(values.get('stop_id','')); last=str(values.get('end_stop_id',first)) if granularity=='section' else first
                if first not in ids or last not in ids: raise ValueError('Остановка не принадлежит маршруту или отсутствует геометрия')
                a,b=sorted([ids.index(first),ids.index(last)]); chosen=ids[a:b+1]
            bins=defaultdict(lambda: {'prediction':0,'reference':0,'calendar':0,'adjusted':0,'weather_available':True})
            for h in range(lo,hi):
                p=predictions[r,h]; key=h if period=='day' else None
                vals={name:p[name] for name in ('prediction','reference','calendar')}
                if chosen:
                    # Exact conservation of integer route totals with explicit unvalidated allocation.
                    for name,value in vals.items():
                        allocations=stop_estimates(shape,value,poi,d,h)
                        vals[name]=sum(s['estimate'] for s in allocations if s['stop_id'] in chosen)
                for name,value in vals.items(): bins[key][name]+=value
                bins[key]['adjusted']+=round(vals['prediction']*factor)
                bins[key]['weather_available'] &= p['weather_available']
            rows.extend({'route':r,'date':str(d),'hour':h,'stop_id':values.get('stop_id','') if chosen else '',
                         'end_stop_id':values.get('end_stop_id','') if granularity=='section' else '',**v} for h,v in bins.items())
    return {'records':rows,'period':period,'granularity':granularity,'factors':factors,
        'from':str(start),'to':str(start+timedelta(days=n-1)), 'timezone':'Europe/Moscow',
        'unit':'валидации','model_version':model_card()['version'],
        'total':sum(x['adjusted'] for x in rows),
        'notice': ('Остановки/участки: равномерное распределение, не обученный прогноз посадок. ' if granularity!='route' else '')+
                  ('За пределами 2025 года — сезонная экстраполяция reference без погоды и праздников 2026. ' if start+timedelta(days=n-1)>date(2025,12,31) else '')+
                  'Поправки — сценарные коэффициенты диспетчера; WAPE для них не измерен.'}

def export_csv(result):
    buf=io.StringIO(); fields=['route','date','hour','stop_id','end_stop_id','prediction','reference','calendar','adjusted','weather_available']
    w=csv.DictWriter(buf,fields,delimiter=';',lineterminator='\n');w.writeheader();w.writerows(result['records'])
    return buf.getvalue().encode('utf-8-sig')

def create_job(values, geometry, poi):
    with JOB_LOCK:
        now=time.time()
        for k in list(JOBS):
            if now-JOBS[k]['created']>1800 and JOBS[k]['status']!='running': del JOBS[k]
        if sum(j['status']=='running' for j in JOBS.values())>=2: raise ValueError('Очередь занята: дождитесь текущего расчёта')
        if len(JOBS)>=12: raise ValueError('Лимит задач: повторите позже')
        key=secrets.token_urlsafe(16); JOBS[key]={'id':key,'created':now,'status':'running'}
    def work():
        try: result=aggregate(values,geometry,poi)
        except Exception as exc:
            with JOB_LOCK: JOBS[key].update(status='failed',error=str(exc))
        else:
            with JOB_LOCK: JOBS[key].update(status='complete',result=result)
    POOL.submit(work)
    return {'id':key,'status':'running'}

def frontier(values, geometry, poi, effect, model):
    limit=number(values,'reserve',4,0,30,True)
    points=[]
    for n in range(limit+1):
        result=simulate({**values,'reserve':n},geometry,poi,effect,model)
        cur=result['current'];points.append({'reserve':n,'used':cur['added_vehicles'],'unmet':cur['unmet'],'redirected':cur['redirected']})
    baseline=points[0]['unmet']
    for p in points: p['avoided']=baseline-p['unmet']
    best=min(points,key=lambda p:(p['unmet'],p['reserve']))
    return {'points':points,'best':best,'notice':'Минимальный резерв, достигающий лучшего результата среди 0…N. Условная оценка в выбранный час, не оптимизация сети и не приказ выпуска.'}

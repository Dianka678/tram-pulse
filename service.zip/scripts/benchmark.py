"""Authenticated mixed HTTP benchmark against a running instance."""
import concurrent.futures,json,statistics,time,urllib.request,os,platform
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];base=os.environ.get('BENCH_URL','http://127.0.0.1:8080')
password=os.environ.get('BENCH_PASSWORD')
if not password: raise SystemExit('Set BENCH_USER and BENCH_PASSWORD for a test account')
req=urllib.request.Request(base+'/api/login',data=json.dumps({'username':os.environ.get('BENCH_USER','jury'),'password':password}).encode(),headers={'Content-Type':'application/json'})
with urllib.request.urlopen(req) as r:cookie=r.headers['Set-Cookie'].split(';')[0]
paths=['/api/model','/api/forecast?route=7&date=2025-11-18&period=day','/api/analysis?route=7&date=2025-11-18&period=day','/api/simulation']
def call(i):
 p=paths[i%len(paths)];data=json.dumps({'route':'7','date':'2025-11-18'}).encode() if p.endswith('simulation') else None
 req=urllib.request.Request(base+p,data=data,headers={'Cookie':cookie,'Content-Type':'application/json'});start=time.perf_counter()
 try:
  with urllib.request.urlopen(req,timeout=10) as r:r.read();status=r.status
 except Exception:status=0
 return (time.perf_counter()-start)*1000,status
for i in range(20):call(i)
results=[]
for concurrency in [1,8,24]:
 start=time.perf_counter()
 with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as pool:rows=list(pool.map(call,range(400)))
 elapsed=time.perf_counter()-start;lat=sorted(x[0] for x in rows)
 results.append({'concurrency':concurrency,'requests':len(rows),'rps':round(len(rows)/elapsed,2),'p50_ms':round(statistics.median(lat),2),'p95_ms':round(lat[int(len(lat)*.95)-1],2),'errors':sum(s!=200 for _,s in rows)})
report={'environment':platform.platform(),'python':platform.python_version(),'logical_cpus_visible':os.cpu_count(),'container_limits':'not pinned; local process, not Docker; client on same host','mix':paths,'warmup':20,'results':results}
(ROOT/'docs/benchmark.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2))

$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot 'setup-auth.ps1') -StartService
if ($LASTEXITCODE -and $LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

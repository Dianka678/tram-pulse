"""Paired weather ablation. Competition mode uses allowed retrospective weather.

Never consumes future passenger counts. The frozen reference was selected in
prior Sep-Oct research, so those scores are exploratory, not independent tests.
"""
from __future__ import annotations
import argparse
import calendar
import hashlib
import importlib.metadata
import json
import math
import pickle
from datetime import date,datetime,timedelta,timezone
from pathlib import Path
import numpy as np
from .core import grid,load_labels,rounded,score,sha256,effective_weekday,calendar_day_type
from .route_specific import verify_inputs,candidate_factories,RouteEnsemble
from .run import FIRST,FINAL_CUTOFF,FOLDS,dump
from ml.submit.adapter import read_sample,write_submission

VARIABLES=('temperature_2m','relative_humidity_2m','precipitation','rain',
           'snowfall','wind_speed_10m','cloud_cover')
WEIGHTS=(.25,.5,1.)


def weather_rows(payload):
    if payload.get('timezone')!='Europe/Moscow' or payload.get('utc_offset_seconds')!=10800:
        raise ValueError('Weather must use Europe/Moscow (+03:00)')
    h=payload['hourly'];times=h['time']
    if len(set(times))!=len(times):raise ValueError('Duplicate weather timestamp')
    if any(len(h[v])!=len(times) for v in VARIABLES):raise ValueError('Weather lengths differ')
    result={};previous=None
    for i,stamp in enumerate(times):
        t=datetime.fromisoformat(stamp)
        if t.minute or t.second or (previous and t-previous!=timedelta(hours=1)):
            raise ValueError('Weather hours are not contiguous')
        previous=t
        raw=[h[v][i] for v in VARIABLES]
        if any(v is None or not math.isfinite(float(v)) for v in raw):
            raise ValueError(f'Missing/nonfinite weather at {stamp}; do not silently impute')
        raw=list(map(float,raw))
        # Only preceding/current weather hours in rolling summaries.
        j=max(0,i-23)
        raw.extend([float(np.mean(h['temperature_2m'][j:i+1])),
                    float(np.sum(h['precipitation'][j:i+1])),float(raw[0]<0)])
        result[t.date(),t.hour]=raw
    return result


def fit_reference(history,cutoff,choices):
    factories=candidate_factories(profiles_only=True)
    names={'school_calendar'}|{c['candidate'] for c in choices.values()}
    models={n:factories[n]().fit(history,FIRST,cutoff) for n in names}
    return RouteEnsemble(models,choices,cutoff)


def matrix(keys,base,weather,use_weather):
    rows=[]
    for k in keys:
        r,d,h=k
        row=[int(r),h,d.weekday(),effective_weekday(d),calendar_day_type(d),
             int(d.month in (7,8)),base[k],math.sin(2*math.pi*h/24),math.cos(2*math.pi*h/24)]
        if use_weather:
            if (d,h) not in weather:raise ValueError(f'Weather missing for {d} {h}')
            row.extend(weather[d,h])
        rows.append(row)
    return np.asarray(rows,dtype=float)


def causal_residual_training(history,cutoff,choices):
    """Monthly out-of-time reference predictions; no same-row target encoding."""
    routes=sorted({k[0] for k in history},key=int)
    keys=[];base={};blocks=[]
    lo=date(2025,2,1)
    while lo<=cutoff:
        hi=min(cutoff,date(lo.year,lo.month,calendar.monthrange(lo.year,lo.month)[1]))
        training_cutoff=lo-timedelta(days=1)
        prefix={k:y for k,y in history.items() if k[1]<=training_cutoff}
        model=fit_reference(prefix,training_cutoff,choices)
        batch=grid(routes,lo,hi)
        base.update(model.predict(batch));keys.extend(batch)
        blocks.append({'train_through':str(training_cutoff),'predict_from':str(lo),'predict_to':str(hi)})
        lo=hi+timedelta(days=1)
    if not keys:raise ValueError('At least two months of history required')
    scale=np.asarray([max(50,base[k]) for k in keys],dtype=float)
    target=np.asarray([(history.get(k,0)-base[k])/s for k,s in zip(keys,scale)],dtype=float)
    return keys,base,scale,target,blocks


def fit_pair(history,cutoff,choices,weather):
    import lightgbm as lgb
    keys,base,scale,y,blocks=causal_residual_training(history,cutoff,choices)
    models={}
    for name,use_weather in [('calendar',False),('weather',True)]:
        reg=lgb.LGBMRegressor(objective='regression_l1',n_estimators=220,
            learning_rate=.025,num_leaves=12,min_child_samples=120,
            reg_lambda=10.,max_depth=5,n_jobs=2,verbosity=-1,random_state=2025)
        reg.fit(matrix(keys,base,weather,use_weather),y,sample_weight=scale,
                categorical_feature=[0,1,2,3,4,5])
        models[name]=reg
    return models,blocks


def corrected(keys,base,raw,weight):
    """Bound changes to 35% of nonzero reference; do not invent service at zero."""
    out={}
    for k,v in zip(keys,raw):
        b=base[k]
        delta=float(np.clip(float(v)*max(50,b),-.35*b,.35*b))
        out[k]=rounded(b+weight*delta)
    return out


def predictions_pair(keys,base,models,weather):
    preds={'reference':base}
    for name,use_weather in [('calendar',False),('weather',True)]:
        raw=models[name].predict(matrix(keys,base,weather,use_weather))
        for weight in WEIGHTS:preds[f'{name}_{weight}']=corrected(keys,base,raw,weight)
    return preds


def select(keys,truth,preds,routes):
    """Require >=0.5% gain in every validation month, with matched weather control."""
    months=sorted({k[1].month for k in keys})
    chosen={};control_chosen={};diagnostics={}
    for r in routes:
        groups=[[k for k in keys if k[0]==r and k[1].month==m] for m in months]
        errors={name:[sum(abs(p[k]-truth.get(k,0)) for k in g) for g in groups]
                for name,p in preds.items()}
        wins=lambda name,ref: all(a<=.995*b for a,b in zip(errors[name],errors[ref])) and sum(errors[name])<sum(errors[ref])
        controls=['reference']+[f'calendar_{w}' for w in WEIGHTS if wins(f'calendar_{w}','reference')]
        control=min(controls,key=lambda n:(sum(errors[n]),n));control_chosen[r]=control
        candidates=list(controls)
        for w in WEIGHTS:
            name=f'weather_{w}'
            if wins(name,'reference') and wins(name,f'calendar_{w}') and wins(name,control):
                candidates.append(name)
        chosen[r]=min(candidates,key=lambda n:(sum(errors[n]),n))
        diagnostics[r]={'errors_by_month':errors,'months':months,'calendar_control':control,'selected':chosen[r]}
    return chosen,control_chosen,diagnostics


def join(keys,preds,choice):
    return {k:preds[choice.get(k[0],'reference')][k] if k[0] in choice else 0 for k in keys}


class WeatherEnsemble:
    def __init__(self,reference,models,weather,choices):
        self.reference,self.models,self.weather,self.choices=reference,models,weather,choices
    def predict(self,keys):
        base=self.reference.predict(keys)
        return join(keys,predictions_pair(keys,base,self.models,self.weather),self.choices)


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    for n in ['train','test','sample','weather','reference','out']:p.add_argument('--'+n,type=Path,required=True)
    args=p.parse_args(argv)
    inputs=verify_inputs({n:getattr(args,n) for n in ['train','test','sample']})
    train,test=load_labels([args.train]),load_labels([args.test])
    if any(not FIRST<=k[1]<=date(2025,8,31) for k in train):raise ValueError('Bad train dates')
    if any(not date(2025,9,1)<=k[1]<=FINAL_CUTOFF for k in test):raise ValueError('Bad test dates')
    values=load_labels([args.train,args.test]);_,sample=read_sample(args.sample)
    ref=json.loads(args.reference.read_text());choices=ref['choices']
    routes=sorted({k[0] for k in values},key=int)
    if set(routes)!=set(choices):raise ValueError('Reference route set differs from real labels')
    weather=weather_rows(json.loads(args.weather.read_text()))
    for _,d,h in grid(['weather'],FIRST,date(2025,12,31)):
        if (d,h) not in weather:raise ValueError('Weather must cover the entire 2025 calendar year')
    args.out.mkdir(parents=True,exist_ok=True)
    report={'source_mode':'competition','external_information':'Retrospective ERA5 weather, allowed by organizer Q&A; not an as-of Oct31 weather forecast.',
            'weather_source':'https://open-meteo.com/en/docs/historical-weather-api',
            'weather_source_metadata':json.loads(Path(__file__).with_name('weather_source.json').read_text()),
            'weather_sha256':sha256(args.weather),'reference_sha256':sha256(args.reference),
            'reference':ref,'inputs':inputs,'data_kind':'verified_organizer_labels',
            'selection_warning':ref['selection_warning'],'folds':{},'platform_score':None,
            'weather_features':list(VARIABLES)+['temperature_24h_mean','precipitation_24h_sum','below_freezing'],
            'excluded_variable':'snow_depth is all null in downloaded ERA5 response; not used',
            'correction_limit':.35,'weights':list(WEIGHTS),
            'fitted_at':datetime.now(timezone.utc).isoformat(),
            'libraries':{n:importlib.metadata.version(n) for n in ['numpy','lightgbm','scikit-learn']},
            'code_sha256':{p.name:sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))}}
    for label,cutoff,lo,hi in FOLDS:
        history={k:y for k,y in values.items() if k[1]<=cutoff}
        keys=grid(routes,lo,hi);truth={k:y for k,y in values.items() if lo<=k[1]<=hi}
        base=fit_reference(history,cutoff,choices).predict(keys)
        models,blocks=fit_pair(history,cutoff,choices,weather)
        preds=predictions_pair(keys,base,models,weather)
        report['folds'][label]={'training_blocks':blocks,'variants':{}}
        for name,pred in preds.items():
            m=score(keys,truth,pred);report['folds'][label]['variants'][name]=m
            print(f'{label} {name}: WAPE-score={m["all"]["wape_score"]:.6f}',flush=True)
        if label=='sep_oct':
            sep=[k for k in keys if k[1].month==9];october=[k for k in keys if k[1].month==10]
            sept,_,_=select(sep,truth,preds,routes)
            report['october_forward_diagnostic']={'choices_from_september':sept,
                'metrics':score(october,{k:truth[k] for k in october if k in truth},join(october,preds,sept))}
            final_choice,calendar_choice,diag=select(keys,truth,preds,routes)
            report['selection']={'by_route':final_choice,'calendar_control_by_route':calendar_choice,
                'diagnostics':diag,'weather_accepted_routes':[r for r,n in final_choice.items() if n.startswith('weather_')]}
            for name,ch in [('selected',final_choice),('selected_calendar_control',calendar_choice)]:
                report['folds'][label]['variants'][name]=score(keys,truth,join(keys,preds,ch))
        dump(args.out/'weather_report.json',report)
    reference=fit_reference(values,FINAL_CUTOFF,choices)
    models,_=fit_pair(values,FINAL_CUTOFF,choices,weather)
    model=WeatherEnsemble(reference,models,weather,final_choice)
    base=reference.predict(sample);all_final=predictions_pair(sample,base,models,weather)
    for name,ch in [('submission_competition.csv',final_choice),('submission_calendar_control.csv',calendar_choice)]:
        report[name]=write_submission(args.sample,join(sample,all_final,ch),args.out/name)
    # This must reproduce the protected 0.877 baseline byte-for-byte.
    write_submission(args.sample,base,args.out/'submission_reference.csv')
    if sha256(args.out/'submission_reference.csv')!=ref['submission_sha256']:
        raise RuntimeError('Frozen reference does not reproduce original CSV; stop and investigate')
    (args.out/'model.local.pkl').write_bytes(pickle.dumps(model,protocol=5))
    report['outputs_sha256']={n:sha256(args.out/n) for n in ['submission_competition.csv','submission_calendar_control.csv','submission_reference.csv','model.local.pkl']}
    final_predictions=join(sample,all_final,final_choice)
    report['changed_rows_vs_reference']=sum(final_predictions[k]!=base[k] for k in sample)
    dump(args.out/'weather_report.json',report)
    print('Weather accepted on routes:',report['selection']['weather_accepted_routes'],flush=True)
    print('Reference reproduced; 14640 rows exported. Competition score unknown.',flush=True)
    return report

if __name__=='__main__':
    from ml.forecast.weather_competition import main as run_main
    run_main()

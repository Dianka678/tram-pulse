"""Strict validation audit; missing rows are unknown, never silently zero."""
import csv
import io
import math
from datetime import date
from .model_runtime import day_predictions, ROUTES

def evaluate_csv(text):
    if not isinstance(text,str) or len(text)>2_000_000: raise ValueError('CSV до 2 МБ')
    reader=csv.DictReader(io.StringIO(text.lstrip('\ufeff')),delimiter=';' if ';' in text.splitlines()[0] else ',')
    if not {'route','date','hour','actual'}.issubset(reader.fieldnames or []):
        raise ValueError('Нужны столбцы route;date;hour;actual;status (status необязателен)')
    rows=[];seen=set();partial=0
    for index,row in enumerate(reader,2):
        r=int(row['route']);d=date.fromisoformat(row['date']);h=int(row['hour']);v=float(row['actual'])
        if r not in ROUTES or not 0<=h<24 or not math.isfinite(v) or v<0 or not v.is_integer(): raise ValueError(f'Строка {index}: неверный маршрут/час/actual')
        if not date(2025,11,1)<=d<=date(2025,12,31): raise ValueError('Оценка допустима только на будущем для артефакта периоде: ноябрь–декабрь 2025')
        key=(r,d,h)
        if key in seen: raise ValueError(f'Дубликат ключа в строке {index}')
        seen.add(key)
        status=row.get('status','complete') or 'complete'
        if status not in ('complete','partial'): raise ValueError('status: complete или partial')
        if status=='partial': partial+=1;continue
        p=day_predictions(d)[r,h]
        rows.append({'route':r,'date':str(d),'hour':h,'actual':int(v),**p})
    if not rows: raise ValueError('Нет полных наблюдений для оценки')
    actual=sum(r['actual'] for r in rows)
    def metric(key):
        ae=sum(abs(r[key]-r['actual']) for r in rows)
        return {'wape_score':max(0,1-ae/actual) if actual else None,'wape':ae/actual if actual else None,'mae':ae/len(rows),'absolute_error':ae}
    route_metrics=[]
    for route in sorted({x['route'] for x in rows}):
        rr=[x for x in rows if x['route']==route];total=sum(x['actual'] for x in rr)
        route_metrics.append({'route':route,'hours':len(rr),'actual':total,'wape_score':max(0,1-sum(abs(x['prediction']-x['actual']) for x in rr)/total) if total else None})
    return {'source':'user_uploaded_actuals','hours':len(rows),'excluded_partial':partial,'actual':actual,
        'selected':metric('prediction'),'reference':metric('reference'),'calendar':metric('calendar'),
        'routes':route_metrics,'notice':'Парная оценка только полных загруженных часов. Это не официальный score и не оценка отсутствующих часов; нулевая сумма actual даёт неопределённый WAPE.'}

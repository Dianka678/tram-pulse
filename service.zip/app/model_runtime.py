"""The supplied WeatherEnsemble is the sole production demand model."""
import hashlib
import json
import os
import pickle
import sys
import threading
from datetime import date, timedelta
from functools import lru_cache
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'model'))
os.environ.setdefault('OMP_NUM_THREADS', '2')
os.environ.setdefault('OPENBLAS_NUM_THREADS', '2')
from ml.forecast.weather_competition import predictions_pair

ROUTES = (1, 5, 7, 11, 12, 17, 25, 26, 28, 50)
LOCK = threading.RLock()

@lru_cache(maxsize=1)
def artifact():
    path = ROOT / 'model/model.local.pkl'
    # Only this packaged, trusted artifact is accepted. No uploaded pickles.
    with path.open('rb') as f:
        model = pickle.load(f)
    for estimator in model.models.values():
        estimator.set_params(n_jobs=2)
    return model

@lru_cache(maxsize=70)
def day_predictions(day):
    m = artifact()
    keys = [(str(r), day, h) for r in ROUTES for h in range(24)]
    with LOCK:
        base = m.reference.predict(keys)
        weather_available = all((day, h) in m.weather for h in range(24))
        if weather_available:
            variants = predictions_pair(keys, base, m.models, m.weather)
            selected = {k: variants[m.choices.get(k[0], 'reference')][k] if k[0] in m.choices else 0 for k in keys}
            calendar = variants['calendar_1.0']
        else:
            selected, calendar = base, base
    return { (int(r), h): {'prediction': int(selected[k]), 'reference': int(base[k]),
                 'calendar': int(calendar[k]) if r != '5' else 0,
                 'weather_available': weather_available}
             for k in keys for r, _, h in [k] }

def predict_one(route, day, hour):
    return day_predictions(day)[route, hour]['prediction']

@lru_cache(maxsize=1)
def model_card():
    m = artifact()
    reference = json.loads((ROOT/'model/ml/forecast/reference_route_model.json').read_text())
    digest = hashlib.sha256((ROOT/'model/model.local.pkl').read_bytes()).hexdigest()
    return {'name': 'WeatherEnsemble', 'version': 'weather-'+digest[:12], 'sha256': digest,
        'training_end': str(m.reference.cutoff), 'forecast_period': ['2025-11-01','2025-12-31'],
        'choices': m.choices, 'weather_routes': [r for r,v in m.choices.items() if v.startswith('weather')],
        'metrics': {'selected_wape_score': None, 'platform_score': None,
                    'reference_research_wape_score': reference['validation_score']},
        'metrics_notice': 'В архиве нет weather_report.json и исходной почасовой разметки. WAPE итогового ансамбля не подтверждён. 0,893744 — исследовательская оценка reference, выбранного на сентябре–октябре; это не независимый тест.',
        'weather_source': json.loads((ROOT/'model/ml/forecast/weather_source.json').read_text()),
        'scope': '9 маршрутов с историей + нулевой placeholder №5. Почасовые валидации; не число людей в салоне. ERA5 — ретроспективная погода, разрешённая для конкурса.',
        'year_notice': 'После 31.12.2025 используется reference-компонент этого же артефакта. Погодных данных и календаря праздников 2026 в модели нет: это непроверенная сезонная экстраполяция.',
        'adaptation': 'Новый маршрут: история маршрут×дата×час, расписание, геометрия, внешние признаки; повторное обучение и rolling-origin проверка. Остановочные доли требуют фактических посадок.'}

@lru_cache(maxsize=128)
def rain_predictions(day, rain):
    """Counterfactual weather inputs to the supplied model, not legacy ridge."""
    m=artifact();keys=[(str(r),day,h) for r in ROUTES for h in range(24)]
    weather=dict(m.weather)
    for h in range(24):
        raw=list(weather[day,h]);raw[2]=rain;raw[3]=rain
        raw[8]=24*rain  # rolling precipitation: a full-day constant-rain scenario
        weather[day,h]=raw
    with LOCK:
        base=m.reference.predict(keys)
        variants=predictions_pair(keys,base,m.models,weather)
    return {(int(r),h):int(variants[m.choices[r]][k]) if r in m.choices else 0 for k in keys for r,_,h in [k]}

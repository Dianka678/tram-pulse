"""Live fitted-model inference plus an explicitly unvalidated network scenario.

No incident coefficients are presented as learned. Demand is conserved between
served routes and unmet demand; additional vehicles are a shared hourly budget.
"""
import json
import math
from datetime import date
from functools import lru_cache
from pathlib import Path
from .external_effect import rain_factor
from .dispatch import _distance
from .planning import stop_estimates

ROUTES = (1, 5, 7, 11, 12, 17, 25, 26, 28, 50)


@lru_cache(maxsize=4)
def load_model(path):
    from .model_runtime import artifact, model_card
    if Path(path).name == 'model.local.pkl':
        artifact()
        card = model_card()
        return {'name': card['name'], 'as_of': card['training_end'], 'runtime': True}
    data = json.loads(Path(path).read_text(encoding='utf-8'))
    if data.get('name') != 'ds2_school_regime_20260926' or data.get('as_of') != '2025-10-31':
        raise ValueError('Несовместимый артефакт модели')
    data = dict(data)
    data['lookup'] = {name: {tuple(row[:-1]): row[-1] for row in rows}
                      for name, rows in data['profiles'].items()}
    return data


def predict(model, route, day, hour):
    if model.get('runtime'):
        from .model_runtime import predict_one
        return predict_one(route, day, hour)
    if route == 5:
        return 0
    dow = 0 if day == date(2025, 11, 1) else 6 if day in (
        date(2025, 11, 3), date(2025, 11, 4), date(2025, 12, 31)) else day.weekday()
    p = model['lookup']
    parent = p['hour'].get((route, hour), 0)
    weight = model['local_weight']
    value = weight * p['local'].get((route, dow, hour), parent) + round(1-weight, 10)*parent
    anchor = date.fromisoformat(model['regime_anchor'])
    if route == 7 and day.weekday() >= 5 and day >= anchor:
        blend = max(0, 1-(day-anchor).days/model['decay_days'])
        value = (1-blend)*value + blend*p['regime'].get((day.weekday(), hour), value)
    return max(0, round(value))


def number(values, key, default, lo, hi, integer=False):
    value = values.get(key, default)
    if isinstance(value, bool):
        raise ValueError(f'{key}: требуется число')
    value = float(value)
    if not math.isfinite(value) or not lo <= value <= hi or (integer and not value.is_integer()):
        raise ValueError(f'{key}: допустимо {lo}–{hi}')
    return int(value) if integer else value


def simulate(values, geometry, poi, weather_effect, model):
    if isinstance(values, dict) and ('events' in values or 'developments' in values or values.get('date', '2025') > '2025-12-31'):
        from .scenario_engine import simulate_multi
        return simulate_multi(values, geometry, poi)
    if not isinstance(values, dict):
        raise ValueError('Ожидается объект параметров')
    day = date.fromisoformat(values.get('date', '2025-11-18'))
    if not date(2025, 11, 1) <= day <= date(2025, 12, 31):
        raise ValueError('Модель проверена для архивного периода 01.11–31.12.2025')
    hour = number(values, 'hour', 8, 0, 23, True)
    start = number(values, 'start_hour', hour, 0, 23, True)
    end = number(values, 'end_hour', min(24, start+2), 1, 24, True)
    if end <= start:
        raise ValueError('Конец события должен быть позже начала')
    event = values.get('event', 'none')
    if event not in ('none', 'accident', 'works'):
        raise ValueError('Неизвестный тип события')
    weather = values.get('weather', 'dry')
    if weather not in ('dry', 'rain'):
        raise ValueError('Неизвестная погода')
    rain = number(values, 'rain_mm', 1, .1, 20)
    if weather == 'rain' and weather_effect is None:
        raise ValueError('Погодная модель отсутствует; дождь рассчитать нельзя')
    headway = number(values, 'headway', 10, 2, 60)
    cycle = number(values, 'cycle_minutes', 90, 15, 300)
    capacity = number(values, 'capacity', 120, 1, 500)
    reserve = number(values, 'reserve', 4, 0, 30, True)
    loss = number(values, 'capacity_loss', 100 if event == 'accident' else 50, 0, 100)/100
    transfer = number(values, 'transfer_percent', 60, 0, 100)/100
    route_filter = values.get('route', 'all')
    if str(route_filter) not in [str(r) for r in ROUTES]+['all']:
        raise ValueError('Неизвестный маршрут')
    selected = None
    stop_id = str(values.get('stop_id', ''))
    for r, shape in geometry.items():
        if route_filter != 'all' and str(route_filter) != r:
            continue
        selected = next((s for s in shape.get('stops', []) if str(s['id']) == stop_id), None)
        if selected:
            break
    if event != 'none' and selected is None:
        raise ValueError('Выберите конкретную остановку с геометрией для события')
    affected = {}
    alternatives = []
    if event != 'none':
        for r, shape in geometry.items():
            stops = shape.get('stops', [])
            local = [str(s['id']) for s in stops if _distance(s, selected) <= .08]
            if local:
                affected[int(r)] = set(local)
            elif stops and int(r) != 5:
                nearest = min(stops, key=lambda s: _distance(s, selected))
                km = _distance(nearest, selected)
                if km <= .8:
                    alternatives.append({'route': int(r), 'stop': nearest['name'],
                                         'stop_id': str(nearest['id']), 'distance_m': round(km*1000)})
        alternatives.sort(key=lambda a: (a['distance_m'], a['route']))
    factors = {k: number(values, k, 1, .5, 1.5) for k in ('weather_factor', 'event_factor', 'season_factor')}
    scenario_factor = math.prod(factors.values())
    records, hourly, plans = [], [], []
    snapshot = []
    counterfactual = None
    if model.get('runtime') and weather == 'rain':
        from .model_runtime import rain_predictions
        counterfactual = rain_predictions(day, rain)
    for h in range(24):
        base = {r: predict(model, r, day, h) for r in ROUTES}
        wet = ({r: counterfactual[r,h] for r in ROUTES} if counterfactual is not None else {r: (round(base[r]*rain_factor(weather_effect, r, h, rain))
                   if weather == 'rain' and r != 5 and weather_effect else base[r]) for r in ROUTES})
        wet = {r: round(v*scenario_factor) for r,v in wet.items()}
        scenario = dict(wet)
        displaced = {}
        active = event != 'none' and start <= h < end
        stop_rows = {}
        for r, shape in geometry.items():
            estimates = stop_estimates(shape.get('stops', []), wet[int(r)], poi, day, h)
            # Normalize context weights only for the hypothetical stop split.
            # This is not a trained stop boarding model.
            total_weight = sum(s['activity_index'] for s in estimates) or 1
            for s in estimates:
                s['scenario_share'] = s['activity_index']/total_weight
                s['context_estimate'] = round(wet[int(r)]*s['scenario_share'], 1)
                s['affected'] = active and s['stop_id'] in affected.get(int(r), set())
            stop_rows[int(r)] = estimates
            if active and int(r) in affected:
                share = sum(s['scenario_share'] for s in estimates if s['affected'])
                removed = round(wet[int(r)]*share*loss)
                scenario[int(r)] -= removed
                displaced[int(r)] = removed
        removed = sum(displaced.values())
        willing = round(removed*transfer)
        remaining, spare_vehicles, redirected, existing_redirected = willing, reserve, 0, 0
        additions, transfers = {}, {}
        available = alternatives if active else []
        # First use existing estimated capacity across all alternatives. Only
        # then spend the common reserve, in order of walking distance.
        for candidate in available:
            r = candidate['route']
            spare = max(0, math.floor(60/headway*capacity*.8-wet[r]))
            accepted = min(remaining, spare)
            if accepted:
                scenario[r] += accepted
                remaining -= accepted
                existing_redirected += accepted
                redirected += accepted
                transfers[r] = accepted
        per_vehicle = 60/cycle*capacity*.8
        for candidate in available:
            r = candidate['route']
            max_extra = max(0, math.floor(cycle/2)-math.ceil(cycle/headway))
            extra = min(spare_vehicles, max_extra, math.ceil(remaining/per_vehicle))
            accepted = min(remaining, math.floor(extra*per_vehicle))
            if accepted:
                scenario[r] += accepted
                remaining -= accepted
                redirected += accepted
                spare_vehicles -= extra
                additions[r] = extra
                transfers[r] = transfers.get(r, 0)+accepted
        if h == hour:
            for candidate in available:
                r = candidate['route']
                if not transfers.get(r):
                    continue
                extra = additions.get(r, 0)
                current_vehicles = math.ceil(cycle/headway)
                plans.append({**candidate, 'added_vehicles': extra,
                    'transferred': transfers[r], 'current_headway': headway,
                    'proposed_headway': round(cycle/(current_vehicles+extra), 1) if extra else headway,
                    'status': 'conditional', 'operationally_verified': False})
        unmet = removed-redirected
        assert sum(scenario.values())+unmet == sum(wet.values())
        assert sum(additions.values()) <= reserve
        for r in ROUTES:
            records.append({'route': r, 'date': day.isoformat(), 'hour': h, 'base': base[r],
                'weather': wet[r], 'scenario': scenario[r], 'displaced': displaced.get(r, 0),
                'transferred': transfers.get(r, 0), 'added_vehicles': additions.get(r, 0)})
        hourly.append({'hour': h, 'base': sum(base.values()), 'weather': sum(wet.values()),
            'scenario': sum(scenario.values()), 'displaced': removed, 'redirected': redirected,
            'unmet': unmet, 'unmet_without_reserve': removed-existing_redirected,
            'added_vehicles': sum(additions.values())})
        if h == hour:
            snapshot = [{'route': r, **s} for r, rows in stop_rows.items() for s in rows]
    current = hourly[hour]
    return {'date': day.isoformat(), 'hour': hour, 'records': records, 'hourly': hourly,
        'current': current, 'stops': snapshot, 'recommendations': plans,
        'affected_routes': sorted(affected), 'selected_stop': selected,
        'event': event, 'event_active': event != 'none' and start <= hour < end,
        'event_window': [start, end], 'alternatives': alternatives,
        'parameters': {'headway': headway, 'cycle_minutes': cycle, 'capacity': capacity,
            'reserve': reserve, 'factors': factors, 'capacity_loss': loss*100, 'transfer_percent': transfer*100},
        'model': {'name': model['name'], 'as_of': model['as_of'], 'method': 'supplied_weather_ensemble' if model.get('runtime') else 'legacy_profiles',
            'weather_method': ('weather_ensemble_counterfactual' if model.get('runtime') else 'legacy_ridge') if weather == 'rain' else 'archived_era5',
            'incident_method': 'context_weighted_scenario_unvalidated',
            'geometry_method': 'later_reference_snapshot_not_2025_asof',
            'cold_start_routes': [5], 'weather_available': weather_effect is not None},
        'notice': 'Спрос — обученная модель. Переток и выпуск — расчётный сценарий: ' 
                  'допущения о доступности вагонов, вместимости и доле пересадок. ' 
                  'Связность путей, выходы пассажиров и фактическое расписание не известны. ' 
                  'Геометрия — поздний справочник, сценарий не является историческим backtest.'}

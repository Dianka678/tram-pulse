"""Small dependency-free read-only forecast service for the hackathon demo."""
import csv
import hashlib
import hmac
import io
import json
import os
import re
import time
from collections import defaultdict
from datetime import date, datetime, timedelta, timezone
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer as BaseThreadingHTTPServer

class ThreadingHTTPServer(BaseThreadingHTTPServer):
    request_queue_size = 128
    daemon_threads = True

from pathlib import Path
from urllib.parse import parse_qs, urlsplit
from .model_runtime import model_card, day_predictions
from .analytics import aggregate, export_csv, query_values, create_job, JOBS, JOB_LOCK, frontier
from .data_quality import evaluate_csv
from .planning import calculate, parameters, read_context, stop_estimates
from .simulation import simulate, load_model as load_passenger_model
from .external_effect import load_effect, rain_factor, rain_mm
from .dispatch import scenario as dispatch_scenario

ROOT = Path(__file__).resolve().parents[1]
ROUTES = (1, 5, 7, 11, 12, 17, 25, 26, 28, 50)
ROUTE_SET = set(ROUTES)
START, END = date(2025, 11, 1), date(2025, 12, 31)
MAX_BODY = 2048
SCENARIO_MAX_BODY = 65536
MONTHS_RU = {'января': 1, 'февраля': 2, 'марта': 3, 'апреля': 4,
             'мая': 5, 'июня': 6, 'июля': 7, 'августа': 8,
             'сентября': 9, 'октября': 10, 'ноября': 11, 'декабря': 12}


def read_forecast(path):
    """Reject incomplete and malformed submissions instead of displaying wrong totals."""
    result = defaultdict(dict)
    with open(path, newline='', encoding='utf-8-sig') as stream:
        reader = csv.DictReader(stream, delimiter=';')
        if reader.fieldnames != ['route', 'date', 'hour', 'prediction']:
            raise ValueError('Expected route;date;hour;prediction')
        for row in reader:
            route, day, hour = int(row['route']), date.fromisoformat(row['date']), int(row['hour'])
            value = float(row['prediction'])
            if route not in ROUTE_SET or not START <= day <= END or not 0 <= hour < 24:
                raise ValueError('Forecast key outside supported range')
            if not (0 <= value < 1e9):
                raise ValueError('Forecast must be finite and nonnegative')
            key = (day.isoformat(), hour)
            if key in result[route]:
                raise ValueError(f'Duplicate forecast: {route} {key}')
            result[route][key] = round(value)
    if len(result) != len(ROUTES) or any(len(result[r]) != 61 * 24 for r in ROUTES):
        raise ValueError('Forecast must contain the complete 10 × 61 × 24 grid')
    return result


def load_state():
    auth_file = Path(os.environ.get('AUTH_FILE', ROOT / 'secrets' / 'auth.json'))
    auth = json.loads(auth_file.read_text(encoding='utf-8'))
    for key in ('username', 'salt', 'password_hash', 'session_key'):
        if not auth.get(key):
            raise ValueError(f'Missing auth key: {key}')
    forecast = defaultdict(dict)
    for n in range(61):
        day = START + timedelta(days=n)
        for (r,h), values in day_predictions(day).items():
            forecast[r][(day.isoformat(),h)] = values['prediction']
    routes_path = ROOT / 'data' / 'routes.json'
    geometry = json.loads(routes_path.read_text(encoding='utf-8')) if routes_path.exists() else {}
    extra_path = ROOT / 'data' / 'geometry_extra.json'
    if extra_path.exists():
        extra = json.loads(extra_path.read_text(encoding='utf-8'))
        for route, shape in extra.items():
            if int(route) not in ROUTE_SET or route in geometry or len(shape.get('points', [])) < 2:
                raise ValueError('Invalid or duplicate extra route geometry')
            geometry[route] = shape
    quality_path = ROOT / 'data' / 'quality.json'
    quality = (json.loads(quality_path.read_text(encoding='utf-8')) if quality_path.exists()
               else {'routes': [], 'gaps': [], 'definition': 'Историческая диагностика ещё не подключена'})
    actual = read_actual(ROOT / 'data' / 'actual.csv')
    events_path = ROOT / 'data' / 'events.json'
    events = json.loads(events_path.read_text(encoding='utf-8')) if events_path.exists() else []
    weather = read_weather(ROOT / 'data' / 'moscow_forecast_runs_sept2025.csv')
    context_weather, poi = read_context(ROOT)
    effect = load_effect(ROOT / 'data' / 'weather_effect.json')
    backtest_path = ROOT / 'data' / 'backtest_summary.json'
    backtest = json.loads(backtest_path.read_text(encoding='utf-8')) if backtest_path.exists() else None
    backtest = model_card()
    return auth, forecast, geometry, quality, actual, events, weather, context_weather, poi, effect, backtest


def read_weather(path):
    """Archive of weather forecasts with explicit release time, not observations."""
    if not path.exists():
        return {}
    result = defaultdict(list)
    with path.open(newline='', encoding='utf-8-sig') as stream:
        reader = csv.DictReader(stream)
        expected = ['run_utc', 'available_at_utc', 'forecast_hour_moscow',
                    'temperature_2m', 'precipitation', 'snowfall']
        if reader.fieldnames != expected:
            raise ValueError('Unexpected weather forecast schema')
        for row in reader:
            run = datetime.strptime(row['run_utc'], '%Y-%m-%d %H:%M:%S UTC').replace(tzinfo=timezone.utc)
            available = datetime.strptime(row['available_at_utc'], '%Y-%m-%d %H:%M:%S UTC').replace(tzinfo=timezone.utc)
            target = datetime.strptime(row['forecast_hour_moscow'], '%Y-%m-%d %H:%M')
            if available < run or not 0 <= (target.replace(tzinfo=timezone(timedelta(hours=3))) - run).total_seconds() <= 8 * 86400:
                raise ValueError('Invalid weather forecast times')
            result[target.strftime('%Y-%m-%d %H:%M')].append({
                'run_utc': run.isoformat(), 'available_at_utc': available.isoformat(),
                'temperature_2m': float(row['temperature_2m']),
                'precipitation': float(row['precipitation']),
                'snowfall': float(row['snowfall'])})
    return result


def event_context(intent, events, weather):
    """Expose only source announcements and weather runs available before onset."""
    start = date.fromisoformat(intent['from_date'])
    end = date.fromisoformat(intent['to_date_inclusive'])
    cutoff = datetime.combine(start, datetime.min.time(), timezone(timedelta(hours=3))).astimezone(timezone.utc)
    matches = []
    for event in events:
        if (intent['event_type'] == 'roadworks') and (
            event.get('route') is None or intent['route'] is None or event['route'] == intent['route']) and (
            event['from_date'] <= end.isoformat() and event['to_date_inclusive'] >= start.isoformat()) and (
            date.fromisoformat(event['published_date']) < start):
            matches.append(event)
    hours = []
    if intent['event_type'] == 'rain':
        day = start
        while day <= end:
            for hour in range(intent['from_hour'], intent['to_hour']):
                key = f'{day.isoformat()} {hour:02d}:00'
                candidates = [v for v in weather.get(key, []) if datetime.fromisoformat(v['available_at_utc']) <= cutoff]
                if candidates:
                    best = max(candidates, key=lambda v: v['available_at_utc'])
                    hours.append({'hour_moscow': key, **best})
            day += timedelta(days=1)
    return {'official_events': matches, 'weather_forecast': hours,
            'weather_cutoff_utc': cutoff.isoformat(),
            'weather_note': 'Архивный прогноз из файла пользователя; происхождение и единицы осадков не подтверждены, эффект на пассажиропоток не оценён.'}


def read_actual(path):
    """Optional observed facts; a missing hour must never be treated as zero."""
    if not path.exists():
        return {}
    result = {}
    with path.open(newline='', encoding='utf-8-sig') as stream:
        reader = csv.DictReader(stream, delimiter=';')
        if reader.fieldnames != ['route', 'date', 'hour', 'actual', 'status', 'available_at']:
            raise ValueError('actual.csv must have route;date;hour;actual;status;available_at')
        for row in reader:
            route, day, hour = int(row['route']), date.fromisoformat(row['date']), int(row['hour'])
            value = int(row['actual'])
            if route not in ROUTE_SET or not START <= day <= END or not 0 <= hour < 24 or value < 0:
                raise ValueError('Actual key/value outside supported range')
            if row['status'] not in ('complete', 'partial', 'corrected'):
                raise ValueError('Invalid actual status')
            if not re.fullmatch(r'20\d\d-\d\d-\d\dT\d\d:\d\d:\d\d\+03:00', row['available_at']):
                raise ValueError('available_at must be ISO Moscow time')
            key = (route, day.isoformat(), hour)
            if key in result:
                raise ValueError('Duplicate actual key')
            result[key] = {'actual': value, 'status': row['status'],
                           'available_at': row['available_at']}
    return result


def parse_scenario(text, default_date):
    """Restricted natural language: route, one date, hour interval and manual percent."""
    if not isinstance(text, str) or not 0 < len(text) <= 500:
        raise ValueError('Опишите сценарий текстом до 500 символов')
    if re.search(r'\b(сегодня|завтра|послезавтра)\b', text, re.I):
        raise ValueError('Укажите точную дату из 2025 года: относительные даты недоступны для архивного прогноза')
    route_match = re.search(r'маршрут(?:а|е|у|ом)?\s*№?\s*(\d{1,3})', text, re.I)
    if not route_match:
        raise ValueError('Укажите номер маршрута, например «маршрут 11»')
    route = int(route_match.group(1))
    if route not in ROUTE_SET:
        raise ValueError('Такого маршрута нет в прогнозе')
    iso = re.search(r'\b(20\d{2}-\d{2}-\d{2})\b', text)
    ru = re.search(r'\b(\d{1,2})\.(\d{1,2})\.(20\d{2})\b', text)
    day = date.fromisoformat(iso.group(1)) if iso else (
        date(int(ru.group(3)), int(ru.group(2)), int(ru.group(1))) if ru else
        date.fromisoformat(default_date))
    if not START <= day <= END:
        raise ValueError('Сценарии доступны только на 01.11–31.12.2025')
    hours = re.search(r'(?<![\d.-])(?:с\s*)?(\d{1,2})(?::00)?\s*(?:-|–|—|до)\s*(\d{1,2})(?::00)?(?![\d.-])', text, re.I)
    if hours:
        start_hour, end_hour = map(int, hours.groups())
    else:
        start_hour, end_hour = 0, 24
    if not 0 <= start_hour < end_hour <= 24:
        raise ValueError('Укажите часы от 00:00 до 24:00, конец интервала не включается')
    signed = re.search(r'(?<!\d)([+−-])\s*(\d{1,3})\s*%', text)
    direction = re.search(r'(снижен|уменьш|сократ|паден|минус|увелич|повыс|рост|добав|плюс)', text, re.I)
    percent = int(signed.group(2)) if signed else (
        int(re.search(r'\b(\d{1,3})\s*%', text).group(1))
        if direction and re.search(r'\b(\d{1,3})\s*%', text) else None)
    if percent is None:
        raise ValueError('Укажите ручной эффект, например «−30%». Причину события модель пока не оценивает')
    if not 0 <= percent <= 50:
        raise ValueError('Для демонстрации допустима поправка от −50% до +50%')
    negative = (signed and signed.group(1) in '-−') or (
        not signed and direction and direction.group(1).lower().startswith(
            ('снижен', 'уменьш', 'сократ', 'паден', 'минус')))
    factor = 1 + (-percent if negative else percent) / 100
    event = ('repair' if re.search(r'ремонт', text, re.I) else
             'weather' if re.search(r'дожд|снег|погод', text, re.I) else
             'closure' if re.search(r'перекры|закрыт', text, re.I) else 'manual')
    return {'route': route, 'date': day.isoformat(), 'from_hour': start_hour,
            'to_hour': end_hour, 'factor': factor, 'event_type': event,
            'effect_source': 'user_assumption'}


def interpret_event(text, selected_date):
    """Normalize an event request; never infer an untrained causal effect."""
    if not isinstance(text, str) or not 0 < len(text) <= 500:
        raise ValueError('Опишите событие текстом до 500 символов')
    selected = date.fromisoformat(selected_date)
    event_type = ('rain' if re.search(r'дожд|ливень|осадк', text, re.I) else
                  'roadworks' if re.search(r'дорожн\w*\s+работ|ремонт|перекрыт', text, re.I)
                  else None)
    if event_type is None:
        raise ValueError('Пока распознаются дождь и дорожные работы')
    month_words = '|'.join(MONTHS_RU)
    span = re.search(rf'(?<!\d)(\d{{1,2}})\s*[-–—]\s*(\d{{1,2}})\s+({month_words})(?:\s+(20\d{{2}}))?', text, re.I)
    single = re.search(rf'(?<!\d)(\d{{1,2}})\s+({month_words})(?:\s+(20\d{{2}}))?', text, re.I)
    if span:
        first, last, month_word, year_text = span.groups()
        from_day = date(int(year_text or selected.year), MONTHS_RU[month_word.lower()], int(first))
        to_day = date(from_day.year, from_day.month, int(last))
        date_text_removed = text[:span.start()] + text[span.end():]
    elif single:
        first, month_word, year_text = single.groups()
        from_day = to_day = date(int(year_text or selected.year),
                                 MONTHS_RU[month_word.lower()], int(first))
        date_text_removed = text[:single.start()] + text[single.end():]
    else:
        raise ValueError('Укажите дату: например «18 сентября 2025» или «12–14 сентября 2025»')
    if to_day < from_day or (to_day - from_day).days > 30:
        raise ValueError('Интервал события должен быть от 1 до 31 дня')
    hours = re.search(r'\b(?:с|в)\s*(\d{1,2})(?::00)?\s*(?:-|–|—|до)\s*(\d{1,2})(?::00)?', date_text_removed, re.I)
    from_hour, to_hour = map(int, hours.groups()) if hours else (0, 24)
    if not 0 <= from_hour < to_hour <= 24:
        raise ValueError('Часы задаются интервалом, например «с 12 до 13»')
    route_match = re.search(r'маршрут(?:а|е|у|ом)?\s*№?\s*(\d{1,3})', text, re.I)
    route = int(route_match.group(1)) if route_match else None
    if route is not None and route not in ROUTE_SET:
        raise ValueError('Такого маршрута нет в прогнозе')
    intent = {'event_type': event_type, 'from_date': from_day.isoformat(),
              'to_date_inclusive': to_day.isoformat(), 'from_hour': from_hour,
              'to_hour': to_hour, 'route': route, 'year_inferred': not bool(
                  span.group(4) if span else single.group(3)),
              'effect_source': 'model_required'}
    if event_type == 'roadworks' and route is None:
        return {'intent': intent, 'status': 'needs_location',
                'message': 'Укажите маршрут или геопривязанное место работ; без этого нельзя определить затронутый транспорт.'}
    if from_day <= date(2025, 10, 31):
        return {'intent': intent, 'status': 'needs_historical_backtest',
                'message': 'Для этой архивной даты нужна модель с отсечкой до начала события. Прогноз от 31.10.2025 использовать нельзя.'}
    if from_day < START or to_day > END:
        return {'intent': intent, 'status': 'needs_baseline',
                'message': 'На этот период нет базового прогноза в сервисе. Сначала DS должен рассчитать маршрутно-часовую сетку.'}
    return {'intent': intent, 'status': 'needs_event_model',
            'message': 'Базовый прогноз есть, но модель эффекта события ещё не обучена и не проверена. Ручной процент можно задать отдельно.'}


class Handler(BaseHTTPRequestHandler):
    auth = None
    forecast = None
    geometry = None
    quality = None
    actual = None
    events = None
    weather = None
    context_weather = None
    poi = None
    weather_effect = None
    backtest = None
    server_version = 'TramForecast/1.0'

    def respond(self, code, body, content_type='application/json; charset=utf-8', headers=None):
        payload = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(payload)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Referrer-Policy', 'no-referrer')
        for key, value in (headers or {}).items():
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(payload)

    def error(self, status, code, message):
        self.respond(status, {'error': {'code': code, 'message': message}})

    def authenticated(self):
        cookie = SimpleCookie()
        try:
            cookie.load(self.headers.get('Cookie', ''))
            token = cookie['tram_session'].value
            timestamp, signature = token.split('.', 1)
            ts = int(timestamp)
            if abs(time.time() - ts) > 12 * 3600:
                return False
            key = bytes.fromhex(self.auth['session_key'])
            expected = hmac.new(key, timestamp.encode(), hashlib.sha256).hexdigest()
            return hmac.compare_digest(signature, expected)
        except (KeyError, ValueError, OverflowError):
            return False

    def do_POST(self):
        if self.path in ('/api/dispatch/scenario', '/api/scenario/model', '/api/scenario/preview'):
            if not self.authenticated(): return self.error(401, 'unauthorized', 'Войдите в систему')
            return self.error(410, 'retired_model', 'Прежний ML-контур отключён. Используйте /api/simulation с новым WeatherEnsemble.')
        if self.path in ('/api/analysis/jobs', '/api/reserve-frontier', '/api/evaluate', '/api/analysis', '/api/report.pdf', '/api/quality-experiment'):
            if not self.authenticated(): return self.error(401, 'unauthorized', 'Войдите в систему')
            origin = self.headers.get('Origin')
            if origin and urlsplit(origin).netloc != self.headers.get('Host'):
                return self.error(403, 'origin', 'Недопустимый источник запроса')
            try:
                length = int(self.headers.get('Content-Length', '0'))
                limit = 2100000 if self.path in ('/api/evaluate', '/api/quality-experiment') else 65536
                if not 0 < length <= limit: raise ValueError('Некорректный размер запроса')
                values = json.loads(self.rfile.read(length))
                if not isinstance(values, dict): raise ValueError('Ожидается объект')
                if self.path == '/api/quality-experiment':
                    from .quality_experiment import experiment
                    return self.respond(200, experiment(values))
                if self.path == '/api/report.pdf':
                    from .reports import make_report
                    payload = make_report(values, self.geometry, self.poi)
                    return self.respond(200, payload, 'application/pdf', {'Content-Disposition': 'attachment; filename="tram-pulse-report.pdf"'})
                if self.path == '/api/analysis': return self.respond(200, aggregate(values, self.geometry, self.poi))
                if self.path == '/api/evaluate': return self.respond(200, evaluate_csv(values.get('csv', '')))
                if self.path == '/api/analysis/jobs': return self.respond(202, create_job(values, self.geometry, self.poi))
                model = load_passenger_model(str(ROOT / 'model/model.local.pkl'))
                return self.respond(200, frontier(values, self.geometry, self.poi, self.weather_effect, model))
            except (ValueError, KeyError, TypeError, OverflowError, IndexError) as exc:
                return self.error(400, 'bad_request', str(exc))
        if self.path == '/api/logout':
            if not self.authenticated():
                return self.error(401, 'unauthorized', 'Войдите в систему')
            return self.respond(200, {'ok': True}, headers={
                'Set-Cookie': 'tram_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'})
        if self.path == '/api/simulation':
            if not self.authenticated():
                return self.error(401, 'unauthorized', 'Войдите в систему')
            origin = self.headers.get('Origin')
            if origin and urlsplit(origin).netloc != self.headers.get('Host'):
                return self.error(403, 'origin', 'Недопустимый источник запроса')
            try:
                length = int(self.headers.get('Content-Length', '0'))
                if not 0 < length <= SCENARIO_MAX_BODY:
                    raise ValueError('Некорректный размер запроса')
                values = json.loads(self.rfile.read(length))
                model = load_passenger_model(str(ROOT / 'model' / 'model.local.pkl'))
                return self.respond(200, simulate(values, self.geometry, self.poi,
                                                  self.weather_effect, model))
            except FileNotFoundError:
                return self.error(503, 'model_unavailable', 'Артефакт ML-модели отсутствует')
            except (ValueError, KeyError, TypeError, OverflowError) as exc:
                return self.error(400, 'bad_simulation', str(exc))
        if self.path != '/api/login':
            if self.path == '/api/dispatch/scenario':
                if not self.authenticated():
                    return self.error(401, 'unauthorized', 'Войдите в систему')
                try:
                    length = int(self.headers.get('Content-Length', '0'))
                    if not 0 < length <= SCENARIO_MAX_BODY:
                        raise ValueError('Слишком длинный запрос')
                    values = json.loads(self.rfile.read(length))
                    return self.respond(200, dispatch_scenario(values, self.forecast,
                                                               self.geometry, self.weather_effect))
                except (ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
                    return self.error(400, 'bad_dispatch_scenario', str(exc))
            if self.path == '/api/scenario/model':
                if not self.authenticated():
                    return self.error(401, 'unauthorized', 'Войдите в систему')
                try:
                    length = int(self.headers.get('Content-Length', '0'))
                    if not 0 < length <= SCENARIO_MAX_BODY:
                        raise ValueError('Слишком длинный запрос')
                    values = json.loads(self.rfile.read(length))
                    answer = interpret_event(values['text'], values.get('date', START.isoformat()))
                    intent = answer['intent']
                    route = intent['route'] or int(values.get('route', 0))
                    if route not in ROUTE_SET:
                        return self.respond(200, {**answer, 'status': 'needs_route',
                            'message': 'Выберите маршрут или укажите его в сообщении.'})
                    if route == 5:
                        return self.respond(200, {**answer, 'status': 'no_route_history',
                            'message': 'Для маршрута 5 в исторических метках нет обучающих наблюдений; автоматическая поправка отключена.'})
                    if intent['event_type'] == 'roadworks':
                        study = ROOT / 'data' / 'works_case_study.json'
                        context = json.loads(study.read_text(encoding='utf-8')) if study.exists() else None
                        return self.respond(200, {**answer, 'status': 'insufficient_repair_data',
                            'message': 'По одному изменению трассы нельзя обучить переносимый эффект дорожных работ. Прогноз не пересчитан.',
                            'repair_case_study': context})
                    first = date.fromisoformat(intent['from_date'])
                    last = date.fromisoformat(intent['to_date_inclusive'])
                    if first < START or last > END:
                        return self.respond(200, {**answer, 'status': 'needs_baseline',
                            'message': 'Обученная поправка есть, но базовый прогноз в сервисе доступен только на ноябрь–декабрь 2025.'})
                    if not self.weather_effect:
                        return self.error(503, 'model_unavailable', 'Артефакт погодной модели отсутствует')
                    amount = rain_mm(values['text'])
                    records = []
                    day = first
                    while day <= last:
                        for hour in range(intent['from_hour'], intent['to_hour']):
                            base = self.forecast[route][(day.isoformat(), hour)]
                            factor = rain_factor(self.weather_effect, route, hour, amount)
                            records.append({'route': route, 'date': day.isoformat(), 'hour': hour,
                                            'base': base, 'scenario': round(base * factor), 'factor': factor})
                        day += timedelta(days=1)
                    return self.respond(200, {**answer, 'status': 'experimental_prediction',
                        'route': route, 'rain_mm_per_hour': amount, 'records': records,
                        'model_version': self.weather_effect['version'],
                        'validation_folds': self.weather_effect['folds'],
                        'message': 'Условное сравнение с сухим часом; историческая погодная связь, не подтверждённый причинный эффект. В двух из четырёх контрольных месяцев погодная модель уступила календарной, причём суммарно ухудшила проверку.'})
                except (ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
                    return self.error(400, 'bad_event', str(exc))
            if self.path == '/api/scenario/interpret':
                if not self.authenticated():
                    return self.error(401, 'unauthorized', 'Войдите в систему')
                try:
                    length = int(self.headers.get('Content-Length', '0'))
                    if not 0 < length <= SCENARIO_MAX_BODY:
                        raise ValueError('Слишком длинный запрос')
                    values = json.loads(self.rfile.read(length))
                    answer = interpret_event(values['text'], values.get('date', date.today().isoformat()))
                    answer['context'] = event_context(answer['intent'], self.events or [], self.weather or {})
                    return self.respond(200, answer)
                except (ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
                    return self.error(400, 'bad_event', str(exc))
            if self.path == '/api/scenario/preview':
                if not self.authenticated():
                    return self.error(401, 'unauthorized', 'Войдите в систему')
                try:
                    length = int(self.headers.get('Content-Length', '0'))
                    if not 0 < length <= SCENARIO_MAX_BODY:
                        raise ValueError('Слишком длинный запрос')
                    values = json.loads(self.rfile.read(length))
                    selected = date.fromisoformat(values.get('date', '2025-11-01'))
                    if not START <= selected <= END:
                        raise ValueError('Дата вне прогнозного периода')
                    scenario = parse_scenario(values['text'], selected.isoformat())
                    return self.respond(200, {'scenario': scenario,
                        'records': [{'hour': h,
                            'base': self.forecast[scenario['route']][(scenario['date'], h)],
                            'scenario': round(self.forecast[scenario['route']][(scenario['date'], h)] *
                                              scenario['factor']) if scenario['from_hour'] <= h <
                                              scenario['to_hour'] else
                                              self.forecast[scenario['route']][(scenario['date'], h)]}
                            for h in range(24)]})
                except (ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
                    return self.error(400, 'bad_scenario', str(exc))
            return self.error(404, 'not_found', 'Ресурс не найден')
        origin = self.headers.get('Origin')
        host = self.headers.get('Host')
        if origin and urlsplit(origin).netloc != host:
            return self.error(403, 'origin', 'Недопустимый источник запроса')
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if not 0 < length <= MAX_BODY:
                raise ValueError()
            values = json.loads(self.rfile.read(length))
            username, password = values['username'], values['password']
            if not isinstance(username, str) or not isinstance(password, str):
                raise ValueError()
        except (ValueError, KeyError, TypeError, json.JSONDecodeError):
            return self.error(400, 'bad_request', 'Некорректные учётные данные')
        digest = hashlib.pbkdf2_hmac('sha256', password.encode(), bytes.fromhex(self.auth['salt']), 260_000)
        if not (hmac.compare_digest(username, self.auth['username']) and
                hmac.compare_digest(digest.hex(), self.auth['password_hash'])):
            return self.error(401, 'unauthorized', 'Неверный логин или пароль')
        ts = str(int(time.time()))
        key = bytes.fromhex(self.auth['session_key'])
        signature = hmac.new(key, ts.encode(), hashlib.sha256).hexdigest()
        secure = '; Secure' if os.environ.get('COOKIE_SECURE', 'false').lower() == 'true' else ''
        cookie = f'tram_session={ts}.{signature}; HttpOnly; SameSite=Strict; Path=/; Max-Age=43200{secure}'
        self.respond(200, {'ok': True}, headers={'Set-Cookie': cookie})

    def do_GET(self):
        url = urlsplit(self.path)
        if url.path == '/health':
            return self.respond(200, {'status': 'ok', 'routes': len(self.forecast)})
        if url.path == '/api/me':
            authenticated = self.authenticated()
            return self.respond(200, {'authenticated': authenticated,
                                      'username': self.auth['username'] if authenticated else None})
        if url.path == '/':
            return self.serve_static('index.html')
        if url.path.startswith('/static/'):
            name = url.path.removeprefix('/static/')
            if not re.fullmatch(r'[a-zA-Z0-9_.-]+', name):
                return self.error(404, 'not_found', 'Ресурс не найден')
            return self.serve_static(name)
        if not self.authenticated():
            return self.error(401, 'unauthorized', 'Войдите в систему')
        try:
            params = parse_qs(url.query, strict_parsing=False)
            if url.path == '/api/developments/catalog': return self.respond(200, json.loads((ROOT/'data/development_catalog.json').read_text()))
            if url.path == '/api/model': return self.respond(200, model_card())
            if url.path == '/api/sources':
                return self.respond(200, json.loads((ROOT/'data/context_sources.json').read_text()))
            if url.path.startswith('/api/analysis/jobs/'):
                key = url.path.rsplit('/',1)[-1]
                with JOB_LOCK: job = dict(JOBS.get(key, {}))
                if not job: return self.error(404, 'not_found', 'Задача не найдена или истекла')
                return self.respond(200, job)
            if url.path in ('/api/analysis', '/api/analysis/export'):
                values = query_values(params)
                if values.get('period') == 'year': raise ValueError('Годовой расчёт: POST /api/analysis/jobs')
                result = aggregate(values, self.geometry, self.poi)
                if url.path.endswith('/export'):
                    return self.respond(200, export_csv(result), 'text/csv; charset=utf-8', {'Content-Disposition':'attachment; filename="forecast.csv"'})
                return self.respond(200, result)
            if url.path == '/api/routes':
                return self.respond(200, {'routes': [
                    {'id': r, 'has_geometry': str(r) in self.geometry, 'data_warning':
                     'Маршрут 5 отсутствует в исторической разметке' if r == 5 else None}
                    for r in ROUTES
                ], 'source': os.environ.get('FORECAST_LABEL', 'WeatherEnsemble · model/model.local.pkl')})
            if url.path == '/api/geometry':
                return self.respond(200, {'routes': self.geometry,
                    'notice': 'Геометрия маршрутов справочная; значения посадок относятся к маршруту, а не остановкам'})
            if url.path == '/api/quality':
                return self.respond(200, self.quality)
            if url.path == '/api/events':
                return self.respond(200, {'events': self.events})
            if url.path in ('/api/planning', '/api/planning/export'):
                return self.planning_response(params, url.path.endswith('/export'))
            if url.path == '/api/actual':
                return self.actual_response(params)
            if url.path == '/api/backtest':
                return self.respond(200, self.backtest or {'available': False})
            if url.path in ('/api/forecast', '/api/export'):
                return self.forecast_response(params, url.path == '/api/export')
        except (ValueError, KeyError) as exc:
            return self.error(400, 'bad_request', str(exc))
        return self.error(404, 'not_found', 'Ресурс не найден')

    def serve_static(self, name):
        path = ROOT / 'app' / 'static' / name
        if not path.is_file():
            return self.error(404, 'not_found', 'Ресурс не найден')
        media = {'.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
                 '.js': 'text/javascript; charset=utf-8'}
        self.respond(200, path.read_bytes(), media.get(path.suffix, 'application/octet-stream'))

    def planning_response(self, params, export):
        route = int(params.get('route', ['0'])[0])
        if route not in ROUTE_SET:
            raise ValueError('Выберите маршрут для планирования')
        day = date.fromisoformat(params.get('date', ['2025-11-01'])[0])
        hour = int(params.get('hour', ['8'])[0])
        if not START <= day <= END or not 0 <= hour < 24:
            raise ValueError('Дата или час вне конкурсного периода')
        values = parameters(params)
        demand = self.forecast[route][(day.isoformat(), hour)]
        plan = calculate(demand, **values)
        geometry = self.geometry.get(str(route), {})
        stops = stop_estimates(geometry.get('stops', []), demand, self.poi, day, hour)
        weather = self.context_weather.get((day.isoformat(), hour))
        if export:
            output = io.StringIO()
            fields = ['route', 'date', 'hour', 'stop_id', 'stop_name', 'estimated_validations',
                      'estimation_method', 'activity_index', 'context_source', 'metro_400m',
                      'schools_400m', 'hospitals_400m', 'offices_400m']
            writer = csv.DictWriter(output, fields, delimiter=';', lineterminator='\n')
            writer.writeheader()
            for stop in stops:
                poi = stop['poi'] or {}
                writer.writerow({'route': route, 'date': day.isoformat(), 'hour': hour,
                    'stop_id': stop['stop_id'], 'stop_name': stop['name'],
                    'estimated_validations': stop['estimate'],
                    'estimation_method': 'uniform_unvalidated',
                    'activity_index': stop['activity_index'], 'context_source': stop['context_source'],
                    'metro_400m': poi.get('metro_400m', ''),
                    'schools_400m': poi.get('schools_400m', ''),
                    'hospitals_400m': poi.get('hospitals_400m') if poi.get('hospitals_400m') is not None else '',
                    'offices_400m': poi.get('offices_400m') if poi.get('offices_400m') is not None else ''})
            return self.respond(200, output.getvalue().encode('utf-8-sig'),
                                'text/csv; charset=utf-8',
                                {'Content-Disposition': 'attachment; filename="tram_stop_estimates.csv"'})
        return self.respond(200, {'route': route, 'date': day.isoformat(), 'hour': hour,
            'forecast_validations': demand, 'parameters': values, 'plan': plan,
            'weather': weather, 'weather_source': 'Open-Meteo historical reanalysis, retrospective' if weather else None,
            'stops': stops, 'stop_method': 'uniform_unvalidated' if stops else 'unavailable',
            'poi_available': bool(self.poi),
            'activity_method': 'category_hours_proxy_unvalidated',
            'limitations': 'Индекс окружения использует предположения о часах работы; это не модель посадок. Оценки валидаций по остановкам равномерные и не подтверждены фактом.'})

    def forecast_response(self, params, export):
        route_param = params.get('route', ['all'])[0]
        route = None if route_param == 'all' else int(route_param)
        if route is not None and route not in ROUTE_SET:
            raise ValueError('Неизвестный маршрут')
        day = date.fromisoformat(params.get('date', ['2025-11-01'])[0])
        if not START <= day <= END:
            raise ValueError('Доступны даты с 2025-11-01 по 2025-12-31')
        period = params.get('period', ['day'])[0]
        if period not in ('day', 'week', 'month'):
            raise ValueError('period должен быть day, week или month')
        factor = float(params.get('factor', ['1'])[0])
        if not .5 <= factor <= 1.5:
            raise ValueError('factor должен быть от 0.5 до 1.5')
        chosen = ROUTES if route is None else (route,)
        dates = ([day.isoformat()] if period == 'day' else
                 [(day + timedelta(days=n)).isoformat() for n in range(7)
                  if day + timedelta(days=n) <= END] if period == 'week' else
                 [f'2025-{day.month:02d}-{n:02d}' for n in range(1, 32)
                  if valid_day(day.month, n)])
        records = []
        base_total = 0
        for r in chosen:
            for d in dates:
                if period == 'day':
                    base_total += sum(self.forecast[r][(d, h)] for h in range(24))
                    records.extend({'route': r, 'date': d, 'hour': h,
                                    'prediction': round(self.forecast[r][(d, h)] * factor)}
                                   for h in range(24))
                else:
                    total = sum(self.forecast[r][(d, h)] for h in range(24))
                    base_total += total
                    records.append({'route': r, 'date': d, 'prediction': round(total * factor)})
        if export:
            output = io.StringIO()
            fields = ['route', 'date'] + (['hour'] if period == 'day' else []) + ['prediction']
            writer = csv.DictWriter(output, fields, delimiter=';', lineterminator='\n')
            writer.writeheader()
            writer.writerows(records)
            return self.respond(200, output.getvalue().encode('utf-8-sig'),
                                'text/csv; charset=utf-8',
                                {'Content-Disposition': 'attachment; filename="tram_forecast.csv"'})
        return self.respond(200, {'route': route_param, 'period': period, 'date': day.isoformat(),
            'from': dates[0], 'to': dates[-1], 'base_total': base_total,
            'timezone': 'Europe/Moscow', 'unit': 'successful validations / boardings',
            'granularity': 'route', 'factor': factor,
            'source': os.environ.get('FORECAST_LABEL', 'WeatherEnsemble · model/model.local.pkl'),
            'records': records})

    def actual_response(self, params):
        route = params.get('route', ['all'])[0]
        if route != 'all' and int(route) not in ROUTE_SET:
            raise ValueError('Неизвестный маршрут')
        day = date.fromisoformat(params.get('date', ['2025-11-01'])[0])
        if not START <= day <= END:
            raise ValueError('Дата вне прогнозного периода')
        period = params.get('period', ['day'])[0]
        if period not in ('day', 'week', 'month'):
            raise ValueError('Неверный период')
        days = {day.isoformat()} if period == 'day' else (
            {(day + timedelta(days=n)).isoformat() for n in range(7) if day + timedelta(days=n) <= END}
            if period == 'week' else
            {f'2025-{day.month:02d}-{n:02d}' for n in range(1, 32) if valid_day(day.month, n)})
        records = []
        for (r, d, h), a in sorted(self.actual.items()):
            if d not in days or (route != 'all' and r != int(route)):
                continue
            pred = self.forecast[r][(d, h)]
            records.append({'route': r, 'date': d, 'hour': h, 'actual': a['actual'],
                'prediction': pred, 'status': a['status'], 'available_at': a['available_at'],
                'delta': a['actual'] - pred if a['status'] != 'partial' else None})
        complete = [r for r in records if r['status'] != 'partial']
        alerts = []
        for r in complete:
            if abs(r['delta']) >= max(50, .3 * max(r['prediction'], 1)):
                alerts.append({**r, 'rule': 'demo_30pct_50'})
        return self.respond(200, {'records': records, 'alerts': alerts,
            'threshold_note': 'Демо-правило: ≥30% и ≥50 валидаций; пороги не калиброваны DS',
            'available': bool(self.actual)})


def valid_day(month, number):
    try:
        date(2025, month, number)
        return True
    except ValueError:
        return False


def main():
    (Handler.auth, Handler.forecast, Handler.geometry, Handler.quality,
     Handler.actual, Handler.events, Handler.weather,
     Handler.context_weather, Handler.poi, Handler.weather_effect, Handler.backtest) = load_state()
    port = int(os.environ.get('PORT', '8080'))
    server = ThreadingHTTPServer(('0.0.0.0', port), Handler)
    server.daemon_threads = True
    print(f'Tram service listening on {port}', flush=True)
    server.serve_forever()


if __name__ == '__main__':
    main()

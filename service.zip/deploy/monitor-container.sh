#!/usr/bin/env bash
# Run in parallel with the benchmark. Evidence contains no credentials.
set -euo pipefail
cd "$(dirname "$0")/.."
out="${1:-../reports/evidence/container}"
mkdir -p "$out"
container_id=$(docker compose --env-file deploy/.env -f deploy/compose.production.yaml ps -q tram)
[ -n "$container_id" ] || { echo 'Start the service first'; exit 1; }
docker inspect --format '{{json .HostConfig}}' "$container_id" > "$out/host_config.json"
docker version --format '{{json .}}' > "$out/docker_version.json"
for iteration in $(seq 1 120); do
  docker stats --no-stream --format '{{json .}}' "$container_id" >> "$out/stats.jsonl"
  docker exec "$container_id" python -c 'import json,time; from pathlib import Path; names=["memory.current","memory.max","memory.swap.current","memory.events","cpu.stat","cpu.max"]; print(json.dumps({"timestamp":time.time(),**{n:Path("/sys/fs/cgroup",n).read_text() if Path("/sys/fs/cgroup",n).exists() else None for n in names}}))' >> "$out/cgroup.jsonl"
  sleep 1
done

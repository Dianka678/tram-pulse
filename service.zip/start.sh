#!/bin/sh
set -eu
cd "$(dirname "$0")"
if [ ! -f secrets/auth.json ]; then
  if [ -d secrets/auth.json ]; then
    echo 'secrets/auth.json is a directory; rename it before creating credentials.' >&2
    exit 1
  fi
  python3 scripts/create_auth.py
fi
docker compose up --build --force-recreate -d
docker compose ps
echo 'Open http://127.0.0.1:8080/health, then http://127.0.0.1:8080/'

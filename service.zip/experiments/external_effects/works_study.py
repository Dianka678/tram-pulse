"""Official route change case study; not a generic roadwork effect."""
import csv,json,statistics,os
from datetime import date,timedelta
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
REPO=Path(__file__).resolve().parent
LABELS=Path(os.environ.get('TRAM_LABELS_DIR',ROOT.parent/'upload'))
series={}
for p in [LABELS/'labels_day_train(1).csv',LABELS/'labels_day_test(1).csv']:
 with p.open(encoding='utf-8-sig',newline='') as f:
  for row in csv.DictReader(f,delimiter=';'):
   if 6 <= int(row['hour']) < 23:
    key=(int(row['route']),row['date'])
    series[key]=series.get(key,0)+int(row['boardings'])

def mean(route,start,end):
 s=date.fromisoformat(start);e=date.fromisoformat(end);v=[]
 while s<=e:
  if (route,s.isoformat()) in series:v.append(series[route,s.isoformat()])
  s+=timedelta(days=1)
 return statistics.mean(v),len(v)
control=(1,11,12,17,25,26,28)
before=('2025-06-10','2025-07-09'); during=('2025-07-10','2025-08-10')
C1=sum(mean(r,*before)[0] for r in control);C2=sum(mean(r,*during)[0] for r in control)
rows=[]
for route in (7,50):
 p,n1=mean(route,*before);q,n2=mean(route,*during)
 effect=q/p/(C2/C1)-1
 rows.append({'route':route,'before_daily':round(p),'during_daily':round(q),'control_ratio':round(C2/C1,4),'relative_change':round(effect,4),'sample_days':[n1,n2]})
result={'event':'Temporary re-routing July 10-August 10 2025','event_source':'https://transport.mos.ru/mostrans/all_news/125272','end_source':'https://www.mosmetro.ru/news/details/7570','controls':control,'method':'ratio-of-ratios on observed daytime route validations, unadjusted for season/day-of-week','routes':rows,'restriction':'single episode, rerouting and repair confounded; no general roadworks coefficient'}
(REPO/'works_case_study.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(rows,ensure_ascii=False))

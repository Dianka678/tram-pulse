"""Explainable multi-location scenarios. No causal or occupancy claims."""
import calendar
import math
from collections import defaultdict
from datetime import date,timedelta
from .simulation import number
from .planning import stop_estimates
from .dispatch import _distance
from .model_runtime import day_predictions,rain_predictions,model_card,ROUTES


def allocate(total, weights):
    """Largest remainders: nonnegative integer allocation conserves total."""
    if not weights:return []
    den=sum(weights) or len(weights);raw=[total*(w if sum(weights) else 1)/den for w in weights]
    vals=[math.floor(v) for v in raw]
    for i in sorted(range(len(raw)),key=lambda i:(-(raw[i]-vals[i]),i))[:total-sum(vals)]: vals[i]+=1
    return vals


def validate(values,geometry):
    if not isinstance(values,dict):raise ValueError('Ожидается объект параметров')
    day=date.fromisoformat(values.get('date','2025-11-18'))
    if not date(2025,11,1)<=day<=date(2027,12,31):raise ValueError('Поддержаны даты 01.11.2025–31.12.2027; после 2025 — экстраполяция')
    route=str(values.get('route','all'))
    if route!='all' and route not in map(str,ROUTES):raise ValueError('Неизвестный маршрут')
    p={k:number(values,k,*args) for k,args in {'hour':(8,0,23,True),'headway':(10,2,60),'cycle_minutes':(90,15,300),'capacity':(120,1,500),'reserve':(4,0,30,True),'transfer_percent':(60,0,100),'rain_mm':(1,.1,20),'weather_factor':(1,.5,1.5),'event_factor':(1,.5,1.5),'season_factor':(1,.5,1.5)}.items()}
    p['weather']=values.get('weather','dry')
    if p['weather'] not in ('dry','rain'):raise ValueError('Неизвестная погода')
    events=values.get('events',[])
    if not isinstance(events,list) or len(events)>12:raise ValueError('Не более 12 событий')
    events=list(events)
    if not events and values.get('event','none')!='none':events=[{'type':values['event'],'stop_id':values.get('stop_id',''),'route':route,'start_date':str(day),'end_date':str(day),'start_hour':values.get('start_hour',p['hour']),'end_hour':values.get('end_hour',min(24,p['hour']+2)),'capacity_loss':values.get('capacity_loss',100)}]
    normalized=[]
    for i,e in enumerate(events):
        if not isinstance(e,dict):raise ValueError('Неверное событие')
        kind=e.get('type','accident');er=str(e.get('route','all'));sid=str(e.get('stop_id',''))
        if kind not in ('accident','works'):raise ValueError('Событие: accident или works')
        stop=next((s for r,g in geometry.items() if er in ('all',r) for s in g.get('stops',[]) if str(s['id'])==sid),None)
        if not stop:raise ValueError('Остановка события не найдена на указанном маршруте')
        start=date.fromisoformat(e.get('start_date',str(day)));end=date.fromisoformat(e.get('end_date',str(start)))
        h1=number(e,'start_hour',0,0,23,True);h2=number(e,'end_hour',24,1,24,True)
        if start>end or (end-start).days>730 or h1>=h2:raise ValueError('Проверьте даты и часы события (интервал действует ежедневно)')
        normalized.append({'id':str(i+1),'type':kind,'name':str(e.get('name') or ('Авария' if kind=='accident' else 'Работы'))[:100],'stop_id':sid,'stop':stop,'route':er,'start_date':str(start),'end_date':str(end),'start_hour':h1,'end_hour':h2,'capacity_loss':number(e,'capacity_loss',100,0,100)})
    projects=values.get('developments',[])
    if not isinstance(projects,list) or len(projects)>20:raise ValueError('Не более 20 объектов застройки')
    developments=[]
    for i,d in enumerate(projects):
        if not isinstance(d,dict):raise ValueError('Неверный объект застройки')
        r=int(d.get('route',0));sid=str(d.get('stop_id',''));kind=d.get('kind','residential')
        stop=next((s for s in geometry.get(str(r),{}).get('stops',[]) if str(s['id'])==sid),None)
        if not stop or r==5 or kind not in ('residential','office'):raise ValueError('Для застройки нужен маршрут с историей, остановка и тип residential/office')
        opening=date.fromisoformat(d.get('opening_date',''));source=str(d.get('source','')).strip()
        if not source.startswith(('https://','http://')) or len(source)>1000:raise ValueError('Укажите ссылку на источник проекта')
        developments.append({'id':str(i+1),'name':str(d.get('name','Новый объект'))[:100],'kind':kind,'route':r,'stop_id':sid,'stop':stop,'source':source,'opening_date':str(opening),'people':number(d,'people',0,0,100000,True),'tram_share':number(d,'tram_share',10,0,100),'trips':number(d,'trips',1,0,4),'occupancy':number(d,'occupancy',80,0,100),'ramp_months':number(d,'ramp_months',6,1,36),'net_new_share':number(d,'net_new_share',50,0,100),'assumption_notice':'Дата, число жителей/работников и транспортные доли заданы пользователем; источник не проверяется автоматически.'})
    return day,p,normalized,developments


def project_demand(project,day):
    elapsed=(day-date.fromisoformat(project['opening_date'])).days
    if elapsed<0:return [0]*24
    ramp=min(1,(elapsed+1)/(project['ramp_months']*30))
    weekend=(.2 if project['kind']=='office' else .85) if day.weekday()>=5 else 1
    total=round(project['people']*project['occupancy']/100*project['tram_share']/100*project['trips']*project['net_new_share']/100*ramp*weekend)
    profile=({6:5,7:18,8:23,9:12,10:4,16:5,17:8,18:10,19:10,20:5} if project['kind']=='residential' else {7:3,8:5,9:5,12:8,13:9,16:10,17:20,18:22,19:12,20:6})
    return allocate(total,[profile.get(h,0) for h in range(24)])


def simulate_multi(values,geometry,poi,prepared=None,details=True):
    day,p,events,projects=prepared or validate(values,geometry)
    predictions=day_predictions(day);weather_available=predictions[1,0]['weather_available']
    rain=rain_predictions(day,p['rain_mm']) if p['weather']=='rain' and weather_available else None
    factor=math.prod(p[k] for k in ('weather_factor','event_factor','season_factor'))
    growth={d['id']:project_demand(d,day) for d in projects}
    records=[];hourly=[];all_flows=[];event_totals={e['id']:{'displaced':0,'redirected':0,'unmet':0} for e in events}
    event_hourly={e['id']:[{'displaced':0,'redirected':0,'unmet':0} for _ in range(24)] for e in events}
    plans=[];snapshot=[];current_events=[]
    for h in range(24):
        base={r:predictions[r,h]['prediction'] for r in ROUTES}
        adjusted={r:round((rain[r,h] if rain is not None else base[r])*factor) for r in ROUTES}
        added={r:sum(growth[d['id']][h] for d in projects if d['route']==r) for r in ROUTES}
        demand={r:adjusted[r]+added[r] for r in ROUTES};scenario=dict(demand)
        active=[e for e in events if e['start_date']<=str(day)<=e['end_date'] and e['start_hour']<=h<e['end_hour'] and e['capacity_loss']>0]
        stop_rows={};cohorts=[];affected=set();displaced=defaultdict(int)
        for r,g in geometry.items():
            ri=int(r);rows=stop_estimates(g.get('stops',[]),adjusted[ri],poi,day,h)
            counts=allocate(adjusted[ri],[s['activity_index'] for s in rows])
            for row,value in zip(rows,counts):
                value+=sum(growth[d['id']][h] for d in projects if d['route']==ri and d['stop_id']==row['stop_id'])
                candidates=[e for e in active if _distance(row,e['stop'])<=.08]
                ev=max(candidates,key=lambda e:(e['capacity_loss'],-int(e['id']))) if candidates else None
                removed=round(value*ev['capacity_loss']/100) if ev else 0
                row.update(context_estimate=value,scenario_share=value/max(1,demand[ri]),affected=bool(ev),removed=removed)
                if ev:affected.add(ri)
                if removed:
                    displaced[ri]+=removed;scenario[ri]-=removed
                    cohorts.append({'event_id':ev['id'],'from_route':ri,'from_stop':row['name'],'from_stop_id':row['stop_id'],'stop':row,'displaced':removed})
            stop_rows[ri]=rows
        cohorts.sort(key=lambda c:(int(c['event_id']),c['from_route'],c['from_stop_id']))
        spare={r:max(0,math.floor(60/p['headway']*p['capacity']*.8-demand[r])) for r in ROUTES}
        extra=defaultdict(int);transfers=defaultdict(int);reserve=p['reserve'];flows=[];existing=0
        unit=60/p['cycle_minutes']*p['capacity']*.8
        max_extra=max(0,math.floor(p['cycle_minutes']/2)-math.ceil(p['cycle_minutes']/p['headway']))
        for cohort in cohorts:
            left=round(cohort['displaced']*p['transfer_percent']/100);redirected=0
            alternatives=[]
            for r,g in geometry.items():
                ri=int(r)
                if ri in affected or ri==5 or not g.get('stops'):continue
                stop=min(g['stops'],key=lambda s:_distance(s,cohort['stop']));km=_distance(stop,cohort['stop'])
                if km<=.8:alternatives.append((km,ri,stop))
            alternatives.sort(key=lambda a:(a[0],a[1]))
            for stage in ('existing','reserve'):
                for km,r,stop in alternatives:
                    if not left:break
                    vehicles=0
                    if stage=='reserve' and spare[r]<left:
                        vehicles=min(reserve,max_extra-extra[r],math.ceil((left-spare[r])/unit))
                        if vehicles>0:
                            before=math.floor(extra[r]*unit);extra[r]+=vehicles
                            spare[r]+=math.floor(extra[r]*unit)-before;reserve-=vehicles
                    accepted=min(left,spare[r])
                    if accepted:
                        spare[r]-=accepted;left-=accepted;redirected+=accepted;transfers[r]+=accepted;scenario[r]+=accepted
                        if stage=='existing':existing+=accepted
                        flows.append({**{k:v for k,v in cohort.items() if k!='stop'},'date':str(day),'hour':h,'to_route':r,'to_stop':stop['name'],'to_stop_id':str(stop['id']),'distance_m':round(km*1000),'count':accepted,'allocated_vehicles':vehicles,'stage':stage})
            et=event_totals[cohort['event_id']];et['displaced']+=cohort['displaced'];et['redirected']+=redirected;et['unmet']+=cohort['displaced']-redirected
            eh=event_hourly[cohort['event_id']][h];eh['displaced']+=cohort['displaced'];eh['redirected']+=redirected;eh['unmet']+=cohort['displaced']-redirected
        removed=sum(displaced.values());redirected=sum(transfers.values());unmet=removed-redirected
        assert sum(scenario.values())+unmet==sum(demand.values())
        assert sum(extra.values())<=p['reserve']
        for r in ROUTES:records.append({'route':r,'date':str(day),'hour':h,'base':base[r],'adjusted':adjusted[r],'development':added[r],'weather':demand[r],'scenario':scenario[r],'displaced':displaced[r],'transferred':transfers[r],'added_vehicles':extra[r],'weather_available':weather_available})
        hourly.append({'hour':h,'base':sum(base.values()),'weather':sum(demand.values()),'development':sum(added.values()),'scenario':sum(scenario.values()),'displaced':removed,'redirected':redirected,'unmet':unmet,'unmet_without_reserve':removed-existing,'added_vehicles':sum(extra.values())})
        if details:all_flows.extend(flows)
        if h==p['hour']:
            current_events=active;snapshot=[{'route':r,**row} for r,rows in stop_rows.items() for row in rows]
            for r,count in transfers.items():
                if not count:continue
                ff=[f for f in flows if f['to_route']==r];vehicles=extra[r]
                plans.append({'route':r,'stop':ff[0]['to_stop'],'stop_id':ff[0]['to_stop_id'],'distance_m':max(f['distance_m'] for f in ff),'added_vehicles':vehicles,'transferred':count,'current_headway':p['headway'],'proposed_headway':round(p['cycle_minutes']/(math.ceil(p['cycle_minutes']/p['headway'])+vehicles),1) if vehicles else p['headway'],'operationally_verified':False})
    selected=current_events[0]['stop'] if current_events else (events[0]['stop'] if events else None)
    return {'date':str(day),'hour':p['hour'],'records':records,'hourly':hourly,'current':hourly[p['hour']],'stops':snapshot,'recommendations':plans,'events':[{**e,**event_totals[e['id']],'hourly':event_hourly[e['id']]} for e in events],'flows':all_flows,'developments':[{**d,'daily_added':sum(growth[d['id']])} for d in projects],'affected_routes':sorted({s['route'] for s in snapshot if s['affected']}),'selected_stop':selected,'event':'multi' if events else 'none','event_active':bool(current_events),'event_window':[min((e['start_hour'] for e in events),default=0),max((e['end_hour'] for e in events),default=24)],'alternatives':plans,'parameters':p,'model':{'name':'WeatherEnsemble','as_of':'2025-10-31','method':'multi_event_shared_reserve','weather_available':weather_available},'notice':'Единица — валидации, не уникальные люди или заполненность. Остановочные доли — оценки по окружению. Пересадки выбираются в радиусе 800 м по прямой, путь и движение не проверены. Общий резерв един для всех событий в каждом часу; при перекрытии ограничений применяется максимальное, а не сумма. Порядок распределения — порядок событий. Застройка — пользовательский сценарий; после 2025 модель экстраполируется.'}


def horizon(values,geometry,poi):
    day,p,events,projects=validate(values,geometry);period=values.get('period','day')
    if period not in ('day','week','month','year'):raise ValueError('Неизвестный период')
    n={'day':1,'week':7,'month':calendar.monthrange(day.year,day.month)[1],'year':365}[period]
    start=day.replace(day=1) if period=='month' else day
    if start+timedelta(days=n-1)>date(2027,12,31):raise ValueError('Конец горизонта не должен превышать 31.12.2027')
    lo=number(values,'hour_from',0,0,23,True);hi=number(values,'hour_to',24,1,24,True)
    if lo>=hi:raise ValueError('Начальный час должен быть меньше конечного')
    routes=ROUTES if str(values.get('route','all'))=='all' else (int(values['route']),)
    granularity=values.get('granularity','route');chosen=None
    if granularity not in ('route','stop','section'):raise ValueError('Неверная агрегация')
    if granularity!='route':
        if len(routes)!=1:raise ValueError('Выберите один маршрут')
        ids=[str(s['id']) for s in geometry.get(str(routes[0]),{}).get('stops',[])]
        first=str(values.get('stop_id',''));last=str(values.get('end_stop_id',first)) if granularity=='section' else first
        if first not in ids or last not in ids:raise ValueError('Остановка не принадлежит маршруту')
        a,b=sorted((ids.index(first),ids.index(last)));chosen=set(ids[a:b+1])
    rows=[];network=[];flow_summary={};peak={};event_summary={};growth_summary={};first_day=None
    for offset in range(n):
        d=start+timedelta(days=offset)
        result=simulate_multi({**values,'date':str(d)},geometry,poi,prepared=(d,p,events,projects),details=True)
        if offset==0:first_day=result
        preds=day_predictions(d)
        for x in result['records']:
            if x['route'] not in routes or not lo<=x['hour']<hi:continue
            r=x['route'];h=x['hour'];row={'route':r,'date':str(d),'hour':h if period=='day' else None,'prediction':x['base'],'reference':preds[r,h]['reference'],'calendar':preds[r,h]['calendar'],'adjusted':x['weather'],'scenario':x['scenario'],'development':x['development'],'displaced':x['displaced'],'transferred':x['transferred'],'added_vehicles':x['added_vehicles'],'weather_available':x['weather_available'],'stop_id':str(values.get('stop_id','')) if chosen else '', 'end_stop_id':str(values.get('end_stop_id','')) if chosen and granularity=='section' else ''}
            if chosen:
                # Selected-stop UI remains descriptive: no fictional stop-level transfer outcomes.
                shape=geometry[str(r)]['stops']
                for key in ['prediction','reference','calendar','adjusted','scenario','development','displaced','transferred']:
                    allocations=stop_estimates(shape,row[key],poi,d,h);row[key]=sum(v['estimate'] for v in allocations if v['stop_id'] in chosen)
            rows.append(row)
            if r not in peak or x['scenario']>peak[r]['scenario']:peak[r]=dict(x)
        network.append({'date':str(d),**{k:sum(x[k] for x in result['hourly'] if lo<=x['hour']<hi) for k in ['base','weather','development','scenario','displaced','redirected','unmet']},'max_reserve':max(x['added_vehicles'] for x in result['hourly'] if lo<=x['hour']<hi)})
        for f in result['flows']:
            if not lo<=f['hour']<hi:continue
            key=(f['event_id'],f['from_route'],f['from_stop_id'],f['to_route'],f['to_stop_id'])
            if key not in flow_summary:flow_summary[key]={**f,'count':0,'first_date':str(d),'last_date':str(d)}
            flow_summary[key]['count']+=f['count'];flow_summary[key]['last_date']=str(d)
        for e in result['events']:
            if e['id'] not in event_summary:event_summary[e['id']]={**{k:v for k,v in e.items() if k!='hourly'},'displaced':0,'redirected':0,'unmet':0}
            for key in ['displaced','redirected','unmet']:event_summary[e['id']][key]+=sum(x[key] for x in e['hourly'][lo:hi])
        for item in result['developments']:
            if item['id'] not in growth_summary:growth_summary[item['id']]={**item,'total_added':0}
            growth_summary[item['id']]['total_added']+=sum(project_demand(item,d)[lo:hi])
    if period!='day':
        bins={}
        for row in rows:
            key=(row['route'],row['date']);target=bins.setdefault(key,{**row,**{k:0 for k in ['prediction','reference','calendar','adjusted','scenario','development','displaced','transferred','added_vehicles']}})
            for k in ['prediction','reference','calendar','adjusted','scenario','development','displaced','transferred']:target[k]+=row[k]
            target['added_vehicles']=max(target['added_vehicles'],row['added_vehicles'])
        rows=list(bins.values())
    advisories=[]
    for r,x in peak.items():
        threshold=60/p['headway']*p['capacity']*.8;ratio=x['scenario']/max(1,threshold)
        required=math.ceil(x['scenario']*p['cycle_minutes']/(60*p['capacity']*.8))
        advisories.append({'route':r,'date':x['date'],'hour':x['hour'],'peak':x['scenario'],'ratio':round(ratio,3),'indicative_extra':max(0,required-math.ceil(p['cycle_minutes']/p['headway'])),'action':'Проверить фактическую загрузку и рассмотреть усиление' if ratio>1 else 'Сохранить выпуск и наблюдать','note':'Индикатор валидаций на расчётный выпуск, не измеренная заполненность. Эти потребности не выделены из общего резерва.'})
    return {'records':rows,'period':period,'granularity':granularity,'from':str(start),'to':str(start+timedelta(days=n-1)),'hour_from':lo,'hour_to':hi,'parameters':p,'events':list(event_summary.values()),'developments':list(growth_summary.values()),'flows':list(flow_summary.values()),'network':network,'advisories':advisories,'total':sum(r['scenario'] for r in rows),'model_version':model_card()['version'],'timezone':'Europe/Moscow','unit':'валидации','notice':first_day['notice']+(' Выбранные остановки/участки в графике — равномерная иллюстративная доля маршрутных итогов; детальный план пересадок и его баланс остаются общесетевыми.' if chosen else ''),'route_filter':str(values.get('route','all'))}

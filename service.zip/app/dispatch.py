"""Transparent, bounded dispatcher what-if calculations over the frozen forecast."""
import math
import re
from datetime import date

from .external_effect import rain_factor, rain_mm

MONTHS = {'ноября': 11, 'декабря': 12}
TYPES = re.compile(r'дожд|ливень|осадк|дорожн\w*\s+работ|ремонт|техосмотр|поломк|авари|нагрузк', re.I)
ROUTE = re.compile(r'(?:маршрут(?:а|е|у|ом)?\s*№?\s*|по\s+номер[уу]?\s*№?\s*|№\s*)(\d{1,3})', re.I)
PERCENT = re.compile(r'([+\-−]?\s*\d{1,2}(?:[.,]\d+)?)\s*%')


def _distance(a, b):
    lat1, lon1, lat2, lon2 = map(math.radians, (a['lat'], a['lon'], b['lat'], b['lon']))
    v = math.sin((lat2-lat1)/2)**2 + math.cos(lat1)*math.cos(lat2)*math.sin((lon2-lon1)/2)**2
    return 12742 * math.asin(min(1, math.sqrt(v)))


def _stop(text, geometry):
    match = re.search(r'(?:возле|у|около)\s+остановк[иые]\s+[«"“]?([^,+;]+)', text, re.I)
    if not match:
        return None
    name = re.split(r'\s+(?:[+\-−]?\d+(?:[.,]\d+)?\s*%|с\s+\d|на\s+маршрут|дожд|авари|ремонт|техосмотр)',
                    match.group(1), maxsplit=1, flags=re.I)[0].strip(' «». ')
    matches = [(int(route), stop) for route, shape in geometry.items()
               for stop in shape.get('stops', []) if stop['name'].casefold() == name.casefold()]
    if not matches:
        raise ValueError(f'Остановка «{name}» отсутствует на карте. Выберите название с карты (маршруты 1, 5, 7, 11, 12).')
    return {'name': matches[0][1]['name'], 'point': matches[0][1],
            'routes': sorted(set(route for route, _ in matches))}


def scenario(values, forecast, geometry, weather_effect):
    text = values.get('text', '')
    if not isinstance(text, str) or not 0 < len(text) <= 500:
        raise ValueError('Опишите событие, не более 500 символов')
    day = date.fromisoformat(values.get('date', '2025-11-01'))
    match = re.search(r'\b(\d{1,2})\s+(ноября|декабря)(?:\s+2025)?\b', text, re.I)
    if match:
        day = date(2025, MONTHS[match.group(2).lower()], int(match.group(1)))
        text = text[:match.start()] + ' ' + text[match.end():]
    if not date(2025, 11, 1) <= day <= date(2025, 12, 31):
        raise ValueError('Сценарий доступен на ноябрь–декабрь 2025')
    hours = re.search(r'\b(?:с|в)\s*(\d{1,2})(?::00)?\s*(?:-|–|—|до)\s*(\d{1,2})(?::00)?', text, re.I)
    start, end = map(int, hours.groups()) if hours else (6, 23)
    if not 6 <= start < end <= 23:
        raise ValueError('Для работы трамвая задайте часы с 06:00 до 23:00')
    text = re.sub(r'\b(?:с|в)\s*\d{1,2}(?::00)?\s*(?:-|–|—|до)\s*\d{1,2}(?::00)?', ' ', text, count=1, flags=re.I)
    positions = list(TYPES.finditer(text))
    if not positions:
        raise ValueError('Добавьте дождь, работы, техосмотр, аварию или изменение нагрузки')
    impact = values.get('impact_percent')
    if impact not in (None, ''):
        impact = float(impact)
        if not math.isfinite(impact) or not -50 <= impact <= 50:
            raise ValueError('Изменение нагрузки: от −50 до +50%')
    events = []
    for idx, pos in enumerate(positions):
        segment = text[pos.start():positions[idx+1].start() if idx+1 < len(positions) else len(text)]
        preamble = text[positions[idx-1].end():pos.start()] if idx else text[:pos.start()]
        clause = preamble + ' ' + segment
        word = pos.group().lower()
        kind = ('rain' if re.search('дожд|ливень|осадк', word) else
                'works' if re.search('работ|ремонт', word) else
                'inspection' if 'техосмотр' in word else
                'accident' if re.search('авари|поломк', word) else 'load')
        route_match = ROUTE.search(clause)
        route = int(route_match.group(1)) if route_match else None
        if route is not None and route not in forecast:
            raise ValueError(f'Маршрута №{route} нет в прогнозе. Доступны: {", ".join(map(str, sorted(forecast)))}.')
        location = _stop(clause, geometry) if kind == 'accident' else None
        if kind in ('works', 'inspection', 'accident') and route is None and location is None:
            raise ValueError('Укажите номер маршрута или остановку для события')
        routes = sorted(forecast) if kind == 'rain' else ([route] if route else location['routes'])
        percent_match = PERCENT.search(clause)
        percent = float(percent_match.group(1).replace('−', '-').replace(' ', '').replace(',', '.')) if percent_match else impact
        if kind != 'rain' and percent is None:
            return {'status': 'needs_impact', 'message': 'Введите изменение нагрузки, %: это оценка диспетчера.',
                    'event': kind, 'date': day.isoformat()}
        if percent is not None and not -50 <= percent <= 50:
            raise ValueError('Изменение нагрузки: от −50 до +50%')
        if kind == 'rain':
            if not weather_effect:
                raise ValueError('Погодная модель не загружена')
            amount = rain_mm(clause)
        else:
            amount = None
        events.append({'type': kind, 'routes': routes, 'percent': percent, 'rain_mm': amount,
                       'stop': location['name'] if location else None,
                       'point': location['point'] if location else None})
    rows = []
    for route in sorted(forecast):
        for hour in range(24):
            base = forecast[route][(day.isoformat(), hour)]
            factor = 1.0
            for event in events:
                if route in event['routes'] and start <= hour < end:
                    factor *= (rain_factor(weather_effect, route, hour, event['rain_mm'])
                               if event['type'] == 'rain' else 1 + event['percent']/100)
            rows.append({'route': route, 'date': day.isoformat(), 'hour': hour,
                         'base': base, 'scenario': max(0, round(base * factor))})
    totals = []
    for route in sorted(forecast):
        relevant = [r for r in rows if r['route'] == route]
        base, changed = sum(r['base'] for r in relevant), sum(r['scenario'] for r in relevant)
        if base != changed:
            totals.append({'route': route, 'base': base, 'scenario': changed, 'delta': changed-base})
    recommendations = []
    affected = {r for event in events if event['type'] in ('works', 'inspection', 'accident')
                and event['percent'] < 0 for r in event['routes']}
    for route in sorted(affected):
        shape = geometry.get(str(route))
        if not shape or not shape.get('stops'):
            continue
        incident = next((e['point'] for e in events if e['point'] and route in e['routes']), None)
        anchors = [incident] if incident else shape['stops']
        near = []
        for other, geo in geometry.items():
            number = int(other)
            if number in affected or number == 5 or not geo.get('stops'):
                continue
            distance = min(_distance(a, b) for a in anchors for b in geo['stops'])
            near.append((distance, number))
        if near:
            distance, alternative = min(near)
            recommendations.append({'route': route, 'alternative': alternative,
                                    'distance_km': round(distance, 2),
                                    'message': f'Проверить резерв на №{alternative} рядом с №{route}; расстояние до остановок {distance:.1f} км. Перед выпуском подтвердить трассу, вместимость и доступные вагоны.'})
    return {'status': 'ready', 'date': day.isoformat(), 'from_hour': start, 'to_hour': end,
            'events': [{k: v for k, v in event.items() if k != 'point'} for event in events],
            'routes': totals, 'records': rows, 'recommendations': recommendations,
            'note': 'Дождь: экспериментальная историческая связь, не причинный эффект. Проценты других событий задаёт диспетчер. Пересадка на соседние маршруты и число нужных вагонов без факта загрузки и расписания не известны.'}
